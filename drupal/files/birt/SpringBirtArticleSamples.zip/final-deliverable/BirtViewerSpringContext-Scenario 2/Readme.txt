1 - Download Spring and BIRT runtime
2 - copy 
�	cglib-nodep-2.2.2.jar
�	org.springframework.aop-3.1.0.RELEASE.jar
�	org.springframework.asm-3.1.0.RELEASE.jar
�	org.springframework.beans-3.1.0.RELEASE.jar
�	org.springframework.context.support-3.1.0.RELEASE.jar
�	org.springframework.context-3.1.0.RELEASE.jar
�	org.springframework.core-3.1.0.RELEASE.jar
�	org.springframework.expression-3.1.0.RELEASE.jar
�	org.springframework.web.servlet-3.1.0.RELEASE.jar
�	org.springframework.web-3.1.0.RELEASE.jar
to the lib directory of this project.
3 - Run and Deploy.
4 - This will create the springandbirtwebviewer.jar
5 - Deploy the BIRT Viewer as described at www.eclipse.org/birt
http://www.eclipse.org/birt/phoenix/deploy/viewerSetup.php
6 - Copy the above Spring Jars and the springandbirtwebviewer.jar to the WEB-INF/lib directory of the 
deployed Viewer.
7 - Make the changes to Web.xml of the viewer as discussed in the article.  See included web.xml for reference.
8 - Restart Tomcat and run included test report.  (Copy test report to deployed Viewer)
