package org.eclipse.birt.spring.webviewer.example;
import java.util.*;

public interface CarService {

public List<Car> getAllCars();
}
