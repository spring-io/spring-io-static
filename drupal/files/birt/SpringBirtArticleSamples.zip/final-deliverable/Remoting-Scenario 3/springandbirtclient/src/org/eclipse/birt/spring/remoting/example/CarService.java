package org.eclipse.birt.spring.remoting.example;

import java.util.*;

import org.eclipse.birt.spring.remoting.example.Car;

public interface CarService {

public List<Car> getAllCars();
}
