package org.eclipse.birt.spring.remoting.example;
import java.io.Serializable;

public interface ICar extends Serializable{

public String getMake(); 
public String getModel();
public String getYear();
public String toString();
}
