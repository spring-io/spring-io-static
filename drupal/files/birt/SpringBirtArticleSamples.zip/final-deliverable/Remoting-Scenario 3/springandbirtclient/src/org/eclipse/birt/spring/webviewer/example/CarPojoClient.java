package org.eclipse.birt.spring.webviewer.example;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.birt.spring.remoting.example.Car;
import org.eclipse.birt.spring.remoting.example.CarService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class CarPojoClient{   
	private final CarService carPojoService;

	public CarPojoClient(){
		final ApplicationContext context = new AnnotationConfigApplicationContext( ContextConfig.class);      
		this.carPojoService = (CarService) context.getBean("client");      

	}
	public static void main(final String[] arguments)   
	{      
		CarPojoClient tst = new CarPojoClient();
		System.out.println(tst.getMake());
	}
	public String getMake(){
		return carPojoService.getAllCars().get(0).getMake();
	}
	public String getModel(){
		return carPojoService.getAllCars().get(0).getModel();	
	}
	public String getYear(){
		return carPojoService.getAllCars().get(0).getYear();	
	}  
	public List<Car> getAllCars(){
		return carPojoService.getAllCars();	
	}

}
