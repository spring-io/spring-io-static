1 - copy servlet-api.jar to the appserverjar directory
2 - Download Spring and BIRT runtime.
3 - Copy Spring jars 
�	aopalliance.jar
�	cglib-nodep-2.2.2.jar
�	org.springframework.aop-3.1.0.RELEASE.jar
�	org.springframework.asm-3.1.0.RELEASE.jar
�	org.springframework.beans-3.1.0.RELEASE.jar
�	org.springframework.context.support-3.1.0.RELEASE.jar
�	org.springframework.context-3.1.0.RELEASE.jar
�	org.springframework.core-3.1.0.RELEASE.jar
�	org.springframework.expression-3.1.0.RELEASE.jar
�	org.springframework.web.servlet-3.1.0.RELEASE.jar
�	org.springframework.web-3.1.0.RELEASE.jar
two war/web-inf/lib
5 - Run ant deploy.

This will create 
springandbirtremote.war  
Deploy this war and then create client.