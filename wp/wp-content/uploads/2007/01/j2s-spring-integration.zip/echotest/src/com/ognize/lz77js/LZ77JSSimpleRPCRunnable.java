package com.ognize.lz77js;

import net.sf.j2s.ajax.SimpleRPCRunnable;

/**
 * @author josson smith
 *
 * 2006-10-10
 */
public class LZ77JSSimpleRPCRunnable extends SimpleRPCRunnable {
	private transient SomeServicesLayer servicesLayer;
	public String jsContent;
	public String result;

	public void setServicesLayer(SomeServicesLayer servicesLayer) {
		this.servicesLayer = servicesLayer;
	}

	public String getHttpURL() {
		/*
		 * In JavaScript, this url must NOT be cross site URL!
		 */
		return "http://localhost:8080/echotest/simplerpc"; /* this url doesn't work yet! */
	}

	public void ajaxRun() {
		System.out.println("ajaxRun");
		result = servicesLayer.computeTheAnswer(jsContent);
		jsContent = null;
	}

}
