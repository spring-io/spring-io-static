package com.ognize.lz77js;

public class SomeServicesLayer {
	public String computeTheAnswer(String input) {
		return "/* from the server's SomeServicesLayer */ " + input;
	}
}
