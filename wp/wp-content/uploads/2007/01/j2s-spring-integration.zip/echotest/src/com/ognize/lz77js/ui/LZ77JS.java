package com.ognize.lz77js.ui;

import net.sf.j2s.ajax.SimpleRPCRequest;
import net.sf.j2s.ajax.SimpleRPCSWTRequest;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Link;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import com.ognize.lz77js.LZ77JSSimpleRPCRunnable;

public class LZ77JS {

	final static String LZ77_JS_URL = "http://bl.ognize.com/lz77js/lz77js";
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final Display display = new Display();
		final Shell shell = new Shell(display);
		//shell.setMaximized(true);
		shell.setText("LZ77 JavaScript Compressor");
		shell.setLayout(new FillLayout());
		SashForm form = new SashForm(shell, SWT.VERTICAL);
		form.setLayout(new FillLayout());

		Composite outlinePanel = new Composite(form, SWT.NONE);
		outlinePanel.setLayout(new GridLayout());
		new Label(outlinePanel, SWT.NONE).setText("JavaScript Source:");
		final Text sourceText = new Text(outlinePanel, SWT.BORDER | SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL);
		sourceText.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		Composite optionPanel = new Composite(outlinePanel, SWT.NONE);
		optionPanel.setLayout(new GridLayout(3, true));
		optionPanel.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		// Button not working with J2S browser target (BPA 22/1/07)
		//Button lz77Button = new Button(optionPanel, SWT.PUSH);
		Link lz77Button = new Link(optionPanel, SWT.YES);
		lz77Button.setText("<a href=\"select\">LZ77 Compress</a>");
		
		final Composite contentPanel = new Composite(form, SWT.NONE);
		contentPanel.setLayout(new GridLayout());
		new Label(contentPanel, SWT.NONE).setText("LZ77 Compressed JavaScript:");
		final Text resultText = new Text(contentPanel, SWT.BORDER | SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL);
		resultText.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		final Label ratioLabel = new Label(contentPanel, SWT.BORDER);
		ratioLabel.setText("Input source JavaScript and then press \"LZ77 Compress\" link.");
		ratioLabel.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		form.setWeights(new int[] { 68, 32 });
		
		lz77Button.addSelectionListener(new SelectionAdapter () {
			public void widgetSelected(SelectionEvent e) {
				String jsContent = sourceText.getText();
				String trimJS = jsContent.trim();
				if (trimJS.length() == 0) {
					MessageBox messageBox = new MessageBox(shell, SWT.RESIZE | SWT.ICON_INFORMATION);
					messageBox.setMessage("Source JavaScript can not be empty!");
					messageBox.open();
				} else {
					ratioLabel.setText("Start JavaScript lz77 compressing to server, please wait ...");
					SimpleRPCSWTRequest.switchToAJAXMode();
					SimpleRPCSWTRequest.swtRequest(new LZ77JSSimpleRPCRunnable() {
						public void ajaxIn() {
							System.out.println("ajaxIn");
							jsContent = sourceText.getText();
						}
						
						public void ajaxOut() {
							System.out.println("ajaxOut");
							resultText.setText(result);
							ratioLabel.setText("Compressed Ratio: " + result.length() + " / " + sourceText.getText().length() + " = " + (100.0 * result.length() / sourceText.getText().length()) + "%");
						}
						
					});
				}
			}
		});

		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}

}
