/* Copyright 2007 Interface21
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.remoting.j2s;

import javax.servlet.ServletException;

import net.sf.j2s.ajax.SimpleRPCHttpServlet;
import net.sf.j2s.ajax.SimpleRPCRunnable;
import net.sf.j2s.ajax.SimpleRPCSWTRequest;

import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Extends Java2Script Pacemaker's SimpleRPCHttpServlet class to obtain SimpleRPCRunnable
 * instances from a Spring application context.
 * 
 * <p>
 * Unlike SimpleRPCHttpServlet, there is no need to define allowable classes as a servlet
 * initialization parameter. SpringRcpHttpServlet instead relies on the Spring application
 * context to obtain suitable instances of SimpleRPCRunnable.
 * 
 * <p>
 * Security is provided in two ways. First, only prototype beans defined in the application
 * context which are assignable to SimpleRPCRunnable are returned. Simply do not register
 * SimpleRPCRunnable instances in the application context if it is not secure to do so.
 * Second, a SimpleRPCRunnable proxy object may be returned which has had its 
 * {@link SimpleRPCRunnable#ajaxRun()} method authorized using Acegi Security (the latter
 * has not been tested as {@link SimpleRPCSWTRequest#swtRequest(SimpleRPCRunnable)} does not
 * currently provide a mechanism to present BASIC authentication credentials).
 * 
 * <p>
 * Ensure the beans have prototype scope in the application context. A new instance is
 * required for every request!
 * 
 * <p>
 * This class attempts to hide the internal design of the system. It only returns exceptions
 * if there are genuine problems with the bean configuration of a valid SimpleRPCRunnable.
 * It does not throw exceptions for requests for non-existing classes, classes that are not
 * SimpleRPCRunnable assignable, or SimpleRPCRunnable instances not defined in the application
 * context. These problems will appear to the user agent as a 404 (not found) result instead.
 * 
 * @author Ben Alex
 */
public class SpringRpcHttpServlet extends SimpleRPCHttpServlet {
	private WebApplicationContext context;
	private static final long serialVersionUID = 75923875L;

	protected SimpleRPCRunnable getRunnableByRequest(String request) {
		// -- Begin copied directly from superclass method of same name
		if (request == null) return null;
		int length = request.length();
		if (length <= 7 || !request.startsWith("WLL")) return null;
		int index = request.indexOf('#');
		if (index == -1) return null;
		String clazzName = request.substring(6, index);
		// -- End copied directly from superclass method of same name
		
		// Obtain reference to the requested java.lang.Class object
		Class clazz = null;
		try {
			clazz = ClassUtils.forName(clazzName);
		} catch (ClassNotFoundException notFound) {
			return null;
		}
		
		// Ensure the requested class is compatible with desired return type
		if (!SimpleRPCRunnable.class.isAssignableFrom(clazz)) {
			return null;
		}
		
		// Look in the Spring application context for the requested java.lang.Class
		String[] beanIds = context.getBeanNamesForType(clazz);
		if (beanIds.length == 0) {
			// No instances of the requested class were found, so silently fail
			return null;
		} else if (beanIds.length > 1) {
			// There were too many of the requested classes found, which is a config error
			StringBuffer sb = new StringBuffer();
			sb.append("There are more than one '");
			sb.append(clazz.getName());
			sb.append("' instances in the application context [");
			for (int i = 0; i < beanIds.length; i++) {
				if (i > 0) {
					sb.append(", ");
				}
				sb.append(beanIds[i]);
			}
			sb.append("] - there should only be one");
			throw new IllegalStateException(sb.toString());
		}
		
		// Check the requested bean is of prototype scope
		Assert.state(!context.isSingleton(beanIds[0]), "Bean id '" + beanIds[0] + "' must be a prototype to be used with this class");
		
		// Return the bean (we already know it's a SimpleRPCRunnable from above, but use the overloaded method anyway for good measure)
		return (SimpleRPCRunnable) context.getBean(beanIds[0], SimpleRPCRunnable.class);
	}
	
	public void init() throws ServletException {
		super.init();
		context = WebApplicationContextUtils.getRequiredWebApplicationContext(super.getServletContext());
	}
}
