﻿$_L(["java.io.InputStream"],"java.io.ByteArrayInputStream",["java.lang.IndexOutOfBoundsException","$.NullPointerException"],function(){
c$=$_C(function(){
this.buf=null;
this.pos=0;
this.$mark=0;
this.count=0;
$_Z(this,arguments);
},java.io,"ByteArrayInputStream",java.io.InputStream);
$_K(c$,
function(buf){
$_R(this,java.io.ByteArrayInputStream,[]);
this.buf=buf;
this.pos=0;
this.count=buf.length;
},"~A");
$_K(c$,
function(buf,offset,length){
$_R(this,java.io.ByteArrayInputStream,[]);
this.buf=buf;
this.pos=offset;
this.count=Math.min(offset+length,buf.length);
this.$mark=offset;
},"~A,~N,~N");
$_M(c$,"read",
function(){
return(this.pos<this.count)?(this.buf[this.pos++]&0xff):-1;
});
$_M(c$,"read",
function(b,off,len){
if(b==null){
throw new NullPointerException();
}else if((off<0)||(off>b.length)||(len<0)||((off+len)>b.length)||((off+len)<0)){
throw new IndexOutOfBoundsException();
}if(this.pos>=this.count){
return-1;
}if(this.pos+len>this.count){
len=this.count-this.pos;
}if(len<=0){
return 0;
}System.arraycopy(this.buf,this.pos,b,off,len);
this.pos+=len;
return len;
},"~A,~N,~N");
$_V(c$,"skip",
function(n){
if(this.pos+n>this.count){
n=this.count-this.pos;
}if(n<0){
return 0;
}this.pos+=n;
return n;
},"~N");
$_V(c$,"available",
function(){
return this.count-this.pos;
});
$_V(c$,"markSupported",
function(){
return true;
});
$_V(c$,"mark",
function(readAheadLimit){
this.$mark=this.pos;
},"~N");
$_V(c$,"reset",
function(){
this.pos=this.$mark;
});
$_V(c$,"close",
function(){
});
});
