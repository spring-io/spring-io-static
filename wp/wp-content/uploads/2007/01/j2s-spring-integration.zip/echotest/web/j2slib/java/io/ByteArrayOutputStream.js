﻿$_L(["java.io.OutputStream"],"java.io.ByteArrayOutputStream",["java.lang.IllegalArgumentException","$.IndexOutOfBoundsException"],function(){
c$=$_C(function(){
this.buf=null;
this.count=0;
$_Z(this,arguments);
},java.io,"ByteArrayOutputStream",java.io.OutputStream);
$_K(c$,
function(){
this.construct(32);
});
$_K(c$,
function(size){
$_R(this,java.io.ByteArrayOutputStream,[]);
if(size<0){
throw new IllegalArgumentException("Negative initial size: "+size);
}this.buf=$_A(size,0);
},"~N");
$_M(c$,"write",
function(b){
var newcount=this.count+1;
if(newcount>this.buf.length){
var newbuf=$_A(Math.max(this.buf.length<<1,newcount),0);
System.arraycopy(this.buf,0,newbuf,0,this.count);
this.buf=newbuf;
}this.buf[this.count]=b;
this.count=newcount;
},"~N");
$_M(c$,"write",
function(b,off,len){
if((off<0)||(off>b.length)||(len<0)||((off+len)>b.length)||((off+len)<0)){
throw new IndexOutOfBoundsException();
}else if(len==0){
return;
}var newcount=this.count+len;
if(newcount>this.buf.length){
var newbuf=$_A(Math.max(this.buf.length<<1,newcount),0);
System.arraycopy(this.buf,0,newbuf,0,this.count);
this.buf=newbuf;
}System.arraycopy(b,off,this.buf,this.count,len);
this.count=newcount;
},"~A,~N,~N");
$_M(c$,"writeTo",
function(out){
out.write(this.buf,0,this.count);
},"java.io.OutputStream");
$_M(c$,"reset",
function(){
this.count=0;
});
$_M(c$,"toByteArray",
function(){
var newbuf=$_A(this.count,0);
System.arraycopy(this.buf,0,newbuf,0,this.count);
return newbuf;
});
$_M(c$,"size",
function(){
return this.count;
});
$_M(c$,"toString",
function(){
return String.instantialize(this.buf,0,this.count);
});
$_M(c$,"toString",
function(enc){
return String.instantialize(this.buf,0,this.count,enc);
},"~S");
$_M(c$,"toString",
function(hibyte){
return String.instantialize(this.buf,hibyte,0,this.count);
},"~N");
$_V(c$,"close",
function(){
});
});
