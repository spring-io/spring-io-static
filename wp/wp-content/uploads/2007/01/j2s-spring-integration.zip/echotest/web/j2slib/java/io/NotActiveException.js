﻿$_L(["java.io.ObjectStreamException"],"java.io.NotActiveException",null,function(){
c$=$_T(java.io,"NotActiveException",java.io.ObjectStreamException);
});
