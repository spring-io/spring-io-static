﻿$_L(null,"java.io.OutputStream",["java.lang.IndexOutOfBoundsException","$.NullPointerException"],function(){
c$=$_T(java.io,"OutputStream");
$_M(c$,"write",
function(b){
this.write(b,0,b.length);
},"~A");
$_M(c$,"write",
function(b,off,len){
if(b==null){
throw new NullPointerException();
}else if((off<0)||(off>b.length)||(len<0)||((off+len)>b.length)||((off+len)<0)){
throw new IndexOutOfBoundsException();
}else if(len==0){
return;
}for(var i=0;i<len;i++){
this.write(b[off+i]);
}
},"~A,~N,~N");
$_M(c$,"flush",
function(){
});
$_M(c$,"close",
function(){
});
});
