﻿$_L(null,"java.io.Reader",["java.io.IOException","java.lang.IllegalArgumentException","$.NullPointerException"],function(){
c$=$_C(function(){
this.lock=null;
this.skipBuffer=null;
$_Z(this,arguments);
},java.io,"Reader");
$_K(c$,
function(){
this.lock=this;
});
$_K(c$,
function(lock){
if(lock==null){
throw new NullPointerException();
}this.lock=lock;
},"~O");
$_M(c$,"read",
function(){
var cb=$_A(1,'\0');
if(this.read(cb,0,1)==-1)return-1;
else return cb[0];
});
$_M(c$,"read",
function(cbuf){
return this.read(cbuf,0,cbuf.length);
},"~A");
$_M(c$,"skip",
function(n){
if(n<0)throw new IllegalArgumentException("skip value is negative");
var nn=Math.min(n,8192);
{
if((this.skipBuffer==null)||(this.skipBuffer.length<nn))this.skipBuffer=$_A(nn,'\0');
var r=n;
while(r>0){
var nc=this.read(this.skipBuffer,0,Math.min(r,nn));
if(nc==-1)break;
r-=nc;
}
return n-r;
}},"~N");
$_M(c$,"ready",
function(){
return false;
});
$_M(c$,"markSupported",
function(){
return false;
});
$_M(c$,"mark",
function(readAheadLimit){
throw new java.io.IOException("mark() not supported");
},"~N");
$_M(c$,"reset",
function(){
throw new java.io.IOException("reset() not supported");
});
$_S(c$,
"maxSkipBufferSize",8192);
});
