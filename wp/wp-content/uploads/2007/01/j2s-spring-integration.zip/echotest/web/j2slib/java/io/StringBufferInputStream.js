﻿$_L(["java.io.InputStream"],"java.io.StringBufferInputStream",["java.lang.IndexOutOfBoundsException","$.NullPointerException"],function(){
c$=$_C(function(){
this.buffer=null;
this.pos=0;
this.count=0;
$_Z(this,arguments);
},java.io,"StringBufferInputStream",java.io.InputStream);
$_K(c$,
function(s){
$_R(this,java.io.StringBufferInputStream,[]);
this.buffer=s;
this.count=s.length;
},"~S");
$_M(c$,"read",
function(){
return(this.pos<this.count)?((this.buffer.charAt(this.pos++)).charCodeAt(0)&0xFF):-1;
});
$_M(c$,"read",
function(b,off,len){
if(b==null){
throw new NullPointerException();
}else if((off<0)||(off>b.length)||(len<0)||((off+len)>b.length)||((off+len)<0)){
throw new IndexOutOfBoundsException();
}if(this.pos>=this.count){
return-1;
}if(this.pos+len>this.count){
len=this.count-this.pos;
}if(len<=0){
return 0;
}var s=this.buffer;
var cnt=len;
while(--cnt>=0){
b[off++]=(s.charAt(this.pos++)).charCodeAt(0);
}
return len;
},"~A,~N,~N");
$_V(c$,"skip",
function(n){
if(n<0){
return 0;
}if(n>this.count-this.pos){
n=this.count-this.pos;
}this.pos+=n;
return n;
},"~N");
$_V(c$,"available",
function(){
return this.count-this.pos;
});
$_V(c$,"reset",
function(){
this.pos=0;
});
});
