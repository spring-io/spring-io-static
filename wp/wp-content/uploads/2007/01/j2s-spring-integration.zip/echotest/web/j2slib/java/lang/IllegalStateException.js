﻿$_L(["java.lang.RuntimeException"],"java.lang.IllegalStateException",null,function(){
c$=$_T(java.lang,"IllegalStateException",RuntimeException);
$_K(c$,
function(cause){
$_R(this,IllegalStateException,[(cause==null?null:cause.toString()),cause]);
},"Throwable");
});
