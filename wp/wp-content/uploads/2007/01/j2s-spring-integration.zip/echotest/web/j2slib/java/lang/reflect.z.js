﻿c$=$_T(java.lang,"Void");
$_S(c$,
"TYPE",null);
{
java.lang.Void.TYPE=java.lang.Void;
}$_L(null,"java.lang.reflect.AccessibleObject",["java.lang.SecurityException"],function(){
c$=$_C(function(){
this.securityCheckCache=null;
this.override=false;
$_Z(this,arguments);
},reflect,"AccessibleObject");
c$.setAccessible=$_M(c$,"setAccessible",
function(array,flag){
for(var i=0;i<array.length;i++){
java.lang.reflect.AccessibleObject.setAccessible0(array[i],flag);
}
},"~A,~B");
$_M(c$,"setAccessible",
function(flag){
java.lang.reflect.AccessibleObject.setAccessible0(this,flag);
},"~B");
c$.setAccessible0=$_M(c$,"setAccessible0",
($fz=function(obj,flag){
if($_O(obj,java.lang.reflect.Constructor)&&flag==true){
var c=obj;
if(c.getDeclaringClass()==Class){
throw new SecurityException("Can not make a java.lang.Class"+" constructor accessible");
}}obj.override=flag;
},$fz.isPrivate=true,$fz),"java.lang.reflect.AccessibleObject,~B");
$_M(c$,"isAccessible",
function(){
return this.override;
});
$_K(c$,
function(){
});
});
$_I(reflect,"InvocationHandler");
c$=$_I(reflect,"Member");
$_S(c$,
"PUBLIC",0,
"DECLARED",1);
$_L(null,"java.lang.reflect.Modifier",["java.lang.reflect.Method"],function(){
c$=$_T(reflect,"Modifier");
c$.isPublic=$_M(c$,"isPublic",
function(mod){
return(mod&1)!=0;
},"~N");
c$.isPrivate=$_M(c$,"isPrivate",
function(mod){
return(mod&2)!=0;
},"~N");
c$.isProtected=$_M(c$,"isProtected",
function(mod){
return(mod&4)!=0;
},"~N");
c$.isStatic=$_M(c$,"isStatic",
function(mod){
return(mod&8)!=0;
},"~N");
c$.isFinal=$_M(c$,"isFinal",
function(mod){
return(mod&16)!=0;
},"~N");
c$.isSynchronized=$_M(c$,"isSynchronized",
function(mod){
return(mod&32)!=0;
},"~N");
c$.isVolatile=$_M(c$,"isVolatile",
function(mod){
return(mod&64)!=0;
},"~N");
c$.isTransient=$_M(c$,"isTransient",
function(mod){
return(mod&128)!=0;
},"~N");
c$.isNative=$_M(c$,"isNative",
function(mod){
return(mod&256)!=0;
},"~N");
c$.isInterface=$_M(c$,"isInterface",
function(mod){
return(mod&512)!=0;
},"~N");
c$.isAbstract=$_M(c$,"isAbstract",
function(mod){
return(mod&1024)!=0;
},"~N");
c$.isStrict=$_M(c$,"isStrict",
function(mod){
return(mod&2048)!=0;
},"~N");
c$.toString=$_M(c$,"toString",
function(mod){
var sb=new Array(0);
if((mod&1)!=0)sb[sb.length]="public";
if((mod&4)!=0)sb[sb.length]="protected";
if((mod&2)!=0)sb[sb.length]="private";
if((mod&1024)!=0)sb[sb.length]="abstract";
if((mod&8)!=0)sb[sb.length]="static";
if((mod&16)!=0)sb[sb.length]="final";
if((mod&128)!=0)sb[sb.length]="transient";
if((mod&64)!=0)sb[sb.length]="volatile";
if((mod&32)!=0)sb[sb.length]="synchronized";
if((mod&256)!=0)sb[sb.length]="native";
if((mod&2048)!=0)sb[sb.length]="strictfp";
if((mod&512)!=0)sb[sb.length]="interface";
if(sb.length>0){
return sb.join(" ");
}return"";
},"~N");
$_S(c$,
"PUBLIC",0x00000001,
"PRIVATE",0x00000002,
"PROTECTED",0x00000004,
"STATIC",0x00000008,
"FINAL",0x00000010,
"SYNCHRONIZED",0x00000020,
"VOLATILE",0x00000040,
"TRANSIENT",0x00000080,
"NATIVE",0x00000100,
"INTERFACE",0x00000200,
"ABSTRACT",0x00000400,
"STRICT",0x00000800);
});
$_L(["java.lang.reflect.AccessibleObject","$.Member","java.lang.Void"],"java.lang.reflect.Constructor",["java.lang.reflect.Field","$.Method","$.Modifier"],function(){
c$=$_C(function(){
this.clazz=null;
this.slot=0;
this.parameterTypes=null;
this.exceptionTypes=null;
this.modifiers=0;
this.constructorAccessor=null;
this.root=null;
$_Z(this,arguments);
},reflect,"Constructor",java.lang.reflect.AccessibleObject,java.lang.reflect.Member);
$_K(c$,
function(declaringClass,parameterTypes,checkedExceptions,modifiers,slot){
$_R(this,java.lang.reflect.Constructor,[]);
this.clazz=declaringClass;
this.parameterTypes=parameterTypes;
this.exceptionTypes=checkedExceptions;
this.modifiers=modifiers;
this.slot=slot;
},"Class,~A,~A,~N,~N");
$_M(c$,"copy",
function(){
var res=new java.lang.reflect.Constructor(this.clazz,this.parameterTypes,this.exceptionTypes,this.modifiers,this.slot);
res.root=this;
res.constructorAccessor=this.constructorAccessor;
return res;
});
$_V(c$,"getDeclaringClass",
function(){
return this.clazz;
});
$_V(c$,"getName",
function(){
return this.getDeclaringClass().getName();
});
$_V(c$,"getModifiers",
function(){
return this.modifiers;
});
$_M(c$,"getParameterTypes",
function(){
return java.lang.reflect.Method.copy(this.parameterTypes);
});
$_M(c$,"getExceptionTypes",
function(){
return java.lang.reflect.Method.copy(this.exceptionTypes);
});
$_V(c$,"equals",
function(obj){
if(obj!=null&&$_O(obj,java.lang.reflect.Constructor)){
var other=obj;
if(this.getDeclaringClass()==other.getDeclaringClass()){
var params1=this.parameterTypes;
var params2=other.parameterTypes;
if(params1.length==params2.length){
for(var i=0;i<params1.length;i++){
if(params1[i]!=params2[i])return false;
}
return true;
}}}return false;
},"~O");
$_V(c$,"hashCode",
function(){
return this.getDeclaringClass().getName().hashCode();
});
$_M(c$,"toString",
function(){
try{
var sb=new Array(0);
var mod=this.getModifiers();
if(mod!=0){
sb[sb.length]=java.lang.reflect.Modifier.toString(mod)+" ";
}sb[sb.length]=java.lang.reflect.Field.getTypeName(this.getDeclaringClass());
sb[sb.length]="(";
var params=this.parameterTypes;
for(var j=0;j<params.length;j++){
sb[sb.length]=java.lang.reflect.Field.getTypeName(params[j]);
if(j<(params.length-1))sb[sb.length]=",";
}
sb[sb.length]=")";
var exceptions=this.exceptionTypes;
if(exceptions.length>0){
sb[sb.length]=" throws ";
for(var k=0;k<exceptions.length;k++){
sb[sb.length]=exceptions[k].getName();
if(k<(exceptions.length-1))sb[sb.length]=",";
}
}{
return sb.join('');
}return sb.toString();
}catch(e){
if($_O(e,Exception)){
return"<"+e+">";
}else{
throw e;
}
}
});
$_M(c$,"newInstance",
function(initargs){
var instance=new this.clazz($_G);
$_Z(instance,initargs);
return instance;
},"~A");
});
$_L(["java.lang.reflect.AccessibleObject","$.Member"],"java.lang.reflect.Field",["java.lang.reflect.Modifier"],function(){
c$=$_C(function(){
this.clazz=null;
this.slot=0;
this.name=null;
this.type=null;
this.modifiers=0;
this.fieldAccessor=null;
this.root=null;
this.securityCheckTargetClassCache=null;
$_Z(this,arguments);
},reflect,"Field",java.lang.reflect.AccessibleObject,java.lang.reflect.Member);
$_K(c$,
function(declaringClass,name,type,modifiers,slot){
$_R(this,java.lang.reflect.Field,[]);
this.clazz=declaringClass;
this.name=name;
this.type=type;
this.modifiers=modifiers;
this.slot=slot;
},"Class,~S,Class,~N,~N");
$_M(c$,"copy",
function(){
var res=new java.lang.reflect.Field(this.clazz,this.name,this.type,this.modifiers,this.slot);
res.root=this;
res.fieldAccessor=this.fieldAccessor;
return res;
});
$_V(c$,"getDeclaringClass",
function(){
return this.clazz;
});
$_V(c$,"getName",
function(){
return this.name;
});
$_V(c$,"getModifiers",
function(){
return this.modifiers;
});
$_M(c$,"getType",
function(){
return this.type;
});
$_V(c$,"equals",
function(obj){
if(obj!=null&&$_O(obj,java.lang.reflect.Field)){
var other=obj;
return(this.getDeclaringClass()==other.getDeclaringClass())&&(this.getName()==other.getName())&&(this.getType()==other.getType());
}return false;
},"~O");
$_V(c$,"hashCode",
function(){
return this.getDeclaringClass().getName().hashCode()^this.getName().hashCode();
});
$_M(c$,"toString",
function(){
var mod=this.getModifiers();
return(((mod==0)?"":(java.lang.reflect.Modifier.toString(mod)+" "))+java.lang.reflect.Field.getTypeName(this.getType())+" "+java.lang.reflect.Field.getTypeName(this.getDeclaringClass())+"."+this.getName());
});
$_M(c$,"get",
function(obj){
return this.getFieldAccessor(obj).get(obj);
},"~O");
$_M(c$,"getBoolean",
function(obj){
return this.getFieldAccessor(obj).getBoolean(obj);
},"~O");
$_M(c$,"getByte",
function(obj){
return this.getFieldAccessor(obj).getByte(obj);
},"~O");
$_M(c$,"getChar",
function(obj){
return this.getFieldAccessor(obj).getChar(obj);
},"~O");
$_M(c$,"getShort",
function(obj){
return this.getFieldAccessor(obj).getShort(obj);
},"~O");
$_M(c$,"getInt",
function(obj){
return this.getFieldAccessor(obj).getInt(obj);
},"~O");
$_M(c$,"getLong",
function(obj){
return this.getFieldAccessor(obj).getLong(obj);
},"~O");
$_M(c$,"getFloat",
function(obj){
return this.getFieldAccessor(obj).getFloat(obj);
},"~O");
$_M(c$,"getDouble",
function(obj){
return this.getFieldAccessor(obj).getDouble(obj);
},"~O");
$_M(c$,"set",
function(obj,value){
this.getFieldAccessor(obj).set(obj,value);
},"~O,~O");
$_M(c$,"setBoolean",
function(obj,z){
this.getFieldAccessor(obj).setBoolean(obj,z);
},"~O,~B");
$_M(c$,"setByte",
function(obj,b){
this.getFieldAccessor(obj).setByte(obj,b);
},"~O,~N");
$_M(c$,"setChar",
function(obj,c){
this.getFieldAccessor(obj).setChar(obj,c);
},"~O,~N");
$_M(c$,"setShort",
function(obj,s){
this.getFieldAccessor(obj).setShort(obj,s);
},"~O,~N");
$_M(c$,"setInt",
function(obj,i){
this.getFieldAccessor(obj).setInt(obj,i);
},"~O,~N");
$_M(c$,"setLong",
function(obj,l){
this.getFieldAccessor(obj).setLong(obj,l);
},"~O,~N");
$_M(c$,"setFloat",
function(obj,f){
this.getFieldAccessor(obj).setFloat(obj,f);
},"~O,~N");
$_M(c$,"setDouble",
function(obj,d){
this.getFieldAccessor(obj).setDouble(obj,d);
},"~O,~N");
$_M(c$,"acquireFieldAccessor",
($fz=function(){
var tmp=null;
if(this.root!=null)tmp=this.root.getFieldAccessor();
if(tmp!=null){
this.fieldAccessor=tmp;
return;
}},$fz.isPrivate=true,$fz));
c$.getTypeName=$_M(c$,"getTypeName",
function(type){
if(type.isArray()){
try{
var cl=type;
var dimensions=0;
while(cl.isArray()){
dimensions++;
cl=cl.getComponentType();
}
var sb=new Array(0);
sb[sb.length]=cl.getName();
for(var i=0;i<dimensions;i++){
sb[sb.length]="[]";
}
{
return sb.join('');
}return sb.toString();
}catch(e){
if($_O(e,Throwable)){
}else{
throw e;
}
}
}return type.getName();
},"Class");
});
$_L(["java.lang.reflect.AccessibleObject","$.Member","java.lang.Void"],"java.lang.reflect.Method",["java.lang.reflect.Field","$.Modifier"],function(){
c$=$_C(function(){
this.clazz=null;
this.slot=0;
this.name=null;
this.returnType=null;
this.parameterTypes=null;
this.exceptionTypes=null;
this.modifiers=0;
this.methodAccessor=null;
this.root=null;
this.securityCheckTargetClassCache=null;
$_Z(this,arguments);
},reflect,"Method",java.lang.reflect.AccessibleObject,java.lang.reflect.Member);
$_K(c$,
function(declaringClass,name,parameterTypes,returnType,checkedExceptions,modifiers,slot){
$_R(this,java.lang.reflect.Method,[]);
this.clazz=declaringClass;
this.name=name;
this.parameterTypes=parameterTypes;
this.returnType=returnType;
this.exceptionTypes=checkedExceptions;
this.modifiers=modifiers;
this.slot=slot;
},"Class,~S,~A,Class,~A,~N,~N");
$_M(c$,"copy",
function(){
var res=new java.lang.reflect.Method(this.clazz,this.name,this.parameterTypes,this.returnType,this.exceptionTypes,this.modifiers,this.slot);
res.root=this;
res.methodAccessor=this.methodAccessor;
return res;
});
$_V(c$,"getDeclaringClass",
function(){
return this.clazz;
});
$_V(c$,"getName",
function(){
return this.name;
});
$_V(c$,"getModifiers",
function(){
return this.modifiers;
});
$_M(c$,"getReturnType",
function(){
return this.returnType;
});
$_M(c$,"getParameterTypes",
function(){
return java.lang.reflect.Method.copy(this.parameterTypes);
});
$_M(c$,"getExceptionTypes",
function(){
return java.lang.reflect.Method.copy(this.exceptionTypes);
});
$_V(c$,"equals",
function(obj){
if(obj!=null&&$_O(obj,java.lang.reflect.Method)){
var other=obj;
if((this.getDeclaringClass()==other.getDeclaringClass())&&(this.getName()==other.getName())){
var params1=this.parameterTypes;
var params2=other.parameterTypes;
if(params1.length==params2.length){
for(var i=0;i<params1.length;i++){
if(params1[i]!=params2[i])return false;
}
return true;
}}}return false;
},"~O");
$_V(c$,"hashCode",
function(){
return this.getDeclaringClass().getName().hashCode()^this.getName().hashCode();
});
$_M(c$,"toString",
function(){
try{
var sb=new Array(0);
var mod=this.getModifiers();
if(mod!=0){
sb[sb.length]=java.lang.reflect.Modifier.toString(mod)+" ";
}sb[sb.length]=java.lang.reflect.Field.getTypeName(this.getReturnType())+" ";
sb[sb.length]=java.lang.reflect.Field.getTypeName(this.getDeclaringClass())+".";
sb[sb.length]=this.getName()+"(";
var params=this.parameterTypes;
for(var j=0;j<params.length;j++){
sb[sb.length]=java.lang.reflect.Field.getTypeName(params[j]);
if(j<(params.length-1))sb[sb.length]=",";
}
sb[sb.length]=")";
var exceptions=this.exceptionTypes;
if(exceptions.length>0){
sb[sb.length]=" throws ";
for(var k=0;k<exceptions.length;k++){
sb[sb.length]=exceptions[k].getName();
if(k<(exceptions.length-1))sb[sb.length]=",";
}
}{
return sb.join('');
}return sb.toString();
}catch(e){
if($_O(e,Exception)){
return"<"+e+">";
}else{
throw e;
}
}
});
$_M(c$,"invoke",
function(obj,args){
var m=this.clazz.prototype[this.name];
if(m==null){
m=this.clazz[this.name];
}
if(m!=null){
m.apply(obj,args);
}else{

}
},"~O,~A");
c$.copy=$_M(c$,"copy",
function($in){
var l=$in.length;
if(l==0)return $in;
var out=new Array(l);
for(var i=0;i<l;i++)out[i]=$in[i];

return out;
},"~A");
});
