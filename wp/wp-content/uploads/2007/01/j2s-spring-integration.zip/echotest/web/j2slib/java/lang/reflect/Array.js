﻿Array.getComponentType=function(){
return Object;
};c$=$_T(reflect,"Array");
c$.newInstance=$_M(c$,"newInstance",
function(componentType,length){
return $_A(length);

},"Class,~N");
