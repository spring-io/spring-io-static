﻿$_L(["java.util.HashMap","$.Iterator"],"java.util.LinkedHashMap",["java.lang.IllegalStateException","java.util.ConcurrentModificationException","$.NoSuchElementException"],function(){
c$=$_C(function(){
this.header=null;
this.accessOrder=false;
if(!$_D("java.util.LinkedHashMap.LinkedHashIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.$nextEntry=null;
this.lastReturned=null;
this.expectedModCount=0;
$_Z(this,arguments);
},java.util.LinkedHashMap,"LinkedHashIterator",null,java.util.Iterator);
$_Y(c$,function(){
this.$nextEntry=this.b$["java.util.LinkedHashMap"].header.after;
this.expectedModCount=this.b$["java.util.LinkedHashMap"].modCount;
});
$_V(c$,"hasNext",
function(){
return this.$nextEntry!=this.b$["java.util.LinkedHashMap"].header;
});
$_V(c$,"remove",
function(){
if(this.lastReturned==null)throw new IllegalStateException();
if(this.b$["java.util.LinkedHashMap"].modCount!=this.expectedModCount)throw new java.util.ConcurrentModificationException();
this.b$["java.util.LinkedHashMap"].remove(this.lastReturned.key);
this.lastReturned=null;
this.expectedModCount=this.b$["java.util.LinkedHashMap"].modCount;
});
$_M(c$,"nextEntry",
function(){
if(this.b$["java.util.LinkedHashMap"].modCount!=this.expectedModCount)throw new java.util.ConcurrentModificationException();
if(this.$nextEntry==this.b$["java.util.LinkedHashMap"].header)throw new java.util.NoSuchElementException();
var a=this.lastReturned=this.$nextEntry;
this.$nextEntry=a.after;
return a;
});
c$=$_P();
}
if(!$_D("java.util.LinkedHashMap.KeyIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.LinkedHashMap,"KeyIterator",java.util.LinkedHashMap.LinkedHashIterator,null,$_N(java.util.LinkedHashMap.LinkedHashIterator,this,null,$_G));
$_V(c$,"next",
function(){
return this.nextEntry().getKey();
});
c$=$_P();
}
if(!$_D("java.util.LinkedHashMap.ValueIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.LinkedHashMap,"ValueIterator",java.util.LinkedHashMap.LinkedHashIterator,null,$_N(java.util.LinkedHashMap.LinkedHashIterator,this,null,$_G));
$_V(c$,"next",
function(){
return this.nextEntry().value;
});
c$=$_P();
}
if(!$_D("java.util.LinkedHashMap.EntryIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.LinkedHashMap,"EntryIterator",java.util.LinkedHashMap.LinkedHashIterator,null,$_N(java.util.LinkedHashMap.LinkedHashIterator,this,null,$_G));
$_V(c$,"next",
function(){
return this.nextEntry();
});
c$=$_P();
}
$_Z(this,arguments);
},java.util,"LinkedHashMap",java.util.HashMap);
$_H();
c$=$_C(function(){
this.before=null;
this.after=null;
$_Z(this,arguments);
},java.util.LinkedHashMap,"Entry",java.util.HashMap.Entry);
$_M(c$,"remove",
($fz=function(){
this.before.after=this.after;
this.after.before=this.before;
},$fz.isPrivate=true,$fz));
$_M(c$,"addBefore",
($fz=function(a){
this.after=a;
this.before=a.before;
this.before.after=this;
this.after.before=this;
},$fz.isPrivate=true,$fz),"java.util.LinkedHashMap.Entry");
$_V(c$,"recordAccess",
function(a){
var b=a;
if(b.accessOrder){
b.modCount++;
this.remove();
this.addBefore(b.header);
}},"java.util.HashMap");
$_V(c$,"recordRemoval",
function(a){
this.remove();
},"java.util.HashMap");
c$=$_P();
$_K(c$,
function(initialCapacity,loadFactor){
$_R(this,java.util.LinkedHashMap,[initialCapacity,loadFactor]);
this.accessOrder=false;
},"~N,~N");
$_K(c$,
function(initialCapacity){
$_R(this,java.util.LinkedHashMap,[initialCapacity]);
this.accessOrder=false;
},"~N");
$_K(c$,
function(){
$_R(this,java.util.LinkedHashMap);
this.accessOrder=false;
});
$_K(c$,
function(m){
$_R(this,java.util.LinkedHashMap,[m]);
this.accessOrder=false;
},"java.util.Map");
$_K(c$,
function(initialCapacity,loadFactor,accessOrder){
$_R(this,java.util.LinkedHashMap,[initialCapacity,loadFactor]);
this.accessOrder=accessOrder;
},"~N,~N,~B");
$_V(c$,"init",
function(){
this.header=new java.util.LinkedHashMap.Entry(-1,null,null,null);
this.header.before=this.header.after=this.header;
});
$_V(c$,"transfer",
function(newTable){
var newCapacity=newTable.length;
for(var e=this.header.after;e!=this.header;e=e.after){
var index=java.util.HashMap.indexFor(e.hash,newCapacity);
e.next=newTable[index];
newTable[index]=e;
}
},"~A");
$_V(c$,"containsValue",
function(value){
if(value==null){
for(var e=this.header.after;e!=this.header;e=e.after)if(e.value==null)return true;

}else{
for(var e=this.header.after;e!=this.header;e=e.after)if(value.equals(e.value))return true;

}return false;
},"~O");
$_V(c$,"get",
function(key){
var e=this.getEntry(key);
if(e==null)return null;
e.recordAccess(this);
return e.value;
},"~O");
$_M(c$,"clear",
function(){
$_U(this,java.util.LinkedHashMap,"clear",[]);
this.header.before=this.header.after=this.header;
});
$_V(c$,"newKeyIterator",
function(){
return $_N(java.util.LinkedHashMap.KeyIterator,this,null);
});
$_V(c$,"newValueIterator",
function(){
return $_N(java.util.LinkedHashMap.ValueIterator,this,null);
});
$_V(c$,"newEntryIterator",
function(){
return $_N(java.util.LinkedHashMap.EntryIterator,this,null);
});
$_V(c$,"addEntry",
function(hash,key,value,bucketIndex){
this.createEntry(hash,key,value,bucketIndex);
var eldest=this.header.after;
if(this.removeEldestEntry(eldest)){
this.removeEntryForKey(eldest.key);
}else{
if(this.$size>=this.threshold)this.resize(2*this.table.length);
}},"~N,~O,~O,~N");
$_V(c$,"createEntry",
function(hash,key,value,bucketIndex){
var e=new java.util.LinkedHashMap.Entry(hash,key,value,this.table[bucketIndex]);
this.table[bucketIndex]=e;
e.addBefore(this.header);
this.$size++;
},"~N,~O,~O,~N");
$_M(c$,"removeEldestEntry",
function(eldest){
return false;
},"java.util.Map.Entry");
});
