﻿$_L(["java.util.AbstractSequentialList","$.List","$.ListIterator"],"java.util.LinkedList",["java.io.IOException","java.lang.IllegalStateException","$.IndexOutOfBoundsException","$.InternalError","java.lang.reflect.Array","java.util.ConcurrentModificationException","$.NoSuchElementException"],function(){
c$=$_C(function(){
this.header=null;
this.$size=0;
if(!$_D("java.util.LinkedList.ListItr")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.lastReturned=null;
this.$next=null;
this.$nextIndex=0;
this.expectedModCount=0;
$_Z(this,arguments);
},java.util.LinkedList,"ListItr",null,java.util.ListIterator);
$_Y(c$,function(){
this.lastReturned=this.b$["java.util.LinkedList"].header;
this.expectedModCount=this.b$["java.util.LinkedList"].modCount;
});
$_K(c$,
function(a){
if(a<0||a>this.b$["java.util.LinkedList"].$size)throw new IndexOutOfBoundsException("Index: "+a+", Size: "+this.b$["java.util.LinkedList"].$size);
if(a<(this.b$["java.util.LinkedList"].$size>>1)){
this.$next=this.b$["java.util.LinkedList"].header.next;
for(this.$nextIndex=0;this.$nextIndex<a;this.$nextIndex++)this.$next=this.$next.next;

}else{
this.$next=this.b$["java.util.LinkedList"].header;
for(this.$nextIndex=this.b$["java.util.LinkedList"].$size;this.$nextIndex>a;this.$nextIndex--)this.$next=this.$next.previous;

}},"~N");
$_V(c$,"hasNext",
function(){
return this.$nextIndex!=this.b$["java.util.LinkedList"].$size;
});
$_V(c$,"next",
function(){
this.checkForComodification();
if(this.$nextIndex==this.b$["java.util.LinkedList"].$size)throw new java.util.NoSuchElementException();
this.lastReturned=this.$next;
this.$next=this.$next.next;
this.$nextIndex++;
return this.lastReturned.element;
});
$_V(c$,"hasPrevious",
function(){
return this.$nextIndex!=0;
});
$_V(c$,"previous",
function(){
if(this.$nextIndex==0)throw new java.util.NoSuchElementException();
this.lastReturned=this.$next=this.$next.previous;
this.$nextIndex--;
this.checkForComodification();
return this.lastReturned.element;
});
$_V(c$,"nextIndex",
function(){
return this.$nextIndex;
});
$_V(c$,"previousIndex",
function(){
return this.$nextIndex-1;
});
$_V(c$,"remove",
function(){
this.checkForComodification();
try{
this.b$["java.util.LinkedList"].remove(this.lastReturned);
}catch(e){
if($_O(e,java.util.NoSuchElementException)){
throw new IllegalStateException();
}else{
throw e;
}
}
if(this.$next==this.lastReturned)this.$next=this.lastReturned.next;
else this.$nextIndex--;
this.lastReturned=this.b$["java.util.LinkedList"].header;
this.expectedModCount++;
});
$_V(c$,"set",
function(a){
if(this.lastReturned==this.b$["java.util.LinkedList"].header)throw new IllegalStateException();
this.checkForComodification();
this.lastReturned.element=a;
},"~O");
$_V(c$,"add",
function(a){
this.checkForComodification();
this.lastReturned=this.b$["java.util.LinkedList"].header;
this.b$["java.util.LinkedList"].addBefore(a,this.$next);
this.$nextIndex++;
this.expectedModCount++;
},"~O");
$_M(c$,"checkForComodification",
function(){
if(this.b$["java.util.LinkedList"].modCount!=this.expectedModCount)throw new java.util.ConcurrentModificationException();
});
c$=$_P();
}
$_Z(this,arguments);
},java.util,"LinkedList",java.util.AbstractSequentialList,[java.util.List,Cloneable,java.io.Serializable]);
$_H();
c$=$_C(function(){
this.element=null;
this.next=null;
this.previous=null;
$_Z(this,arguments);
},java.util.LinkedList,"Entry");
$_K(c$,
function(a,b,c){
this.element=a;
this.next=b;
this.previous=c;
},"~O,java.util.LinkedList.Entry,java.util.LinkedList.Entry");
c$=$_P();
$_Y(c$,function(){
this.header=new java.util.LinkedList.Entry(null,null,null);
});
$_K(c$,
function(){
$_R(this,java.util.LinkedList,[]);
this.header.next=this.header.previous=this.header;
});
$_K(c$,
function(c){
this.construct();
this.addAll(c);
},"java.util.Collection");
$_M(c$,"getFirst",
function(){
if(this.$size==0)throw new java.util.NoSuchElementException();
return this.header.next.element;
});
$_M(c$,"getLast",
function(){
if(this.$size==0)throw new java.util.NoSuchElementException();
return this.header.previous.element;
});
$_M(c$,"removeFirst",
function(){
var first=this.header.next.element;
this.remove(this.header.next);
return first;
});
$_M(c$,"removeLast",
function(){
var last=this.header.previous.element;
this.remove(this.header.previous);
return last;
});
$_M(c$,"addFirst",
function(o){
this.addBefore(o,this.header.next);
},"~O");
$_M(c$,"addLast",
function(o){
this.addBefore(o,this.header);
},"~O");
$_V(c$,"contains",
function(o){
return this.indexOf(o)!=-1;
},"~O");
$_V(c$,"size",
function(){
return this.$size;
});
$_M(c$,"add",
function(o){
this.addBefore(o,this.header);
return true;
},"~O");
$_M(c$,"remove",
function(o){
if(o==null){
for(var e=this.header.next;e!=this.header;e=e.next){
if(e.element==null){
this.remove(e);
return true;
}}
}else{
for(var e=this.header.next;e!=this.header;e=e.next){
if(o.equals(e.element)){
this.remove(e);
return true;
}}
}return false;
},"~O");
$_M(c$,"addAll",
function(c){
return this.addAll(this.$size,c);
},"java.util.Collection");
$_M(c$,"addAll",
function(index,c){
var a=c.toArray();
var numNew=a.length;
if(numNew==0)return false;
this.modCount++;
var successor=(index==this.$size?this.header:this.entry(index));
var predecessor=successor.previous;
for(var i=0;i<numNew;i++){
var e=new java.util.LinkedList.Entry(a[i],successor,predecessor);
predecessor.next=e;
predecessor=e;
}
successor.previous=predecessor;
this.$size+=numNew;
return true;
},"~N,java.util.Collection");
$_V(c$,"clear",
function(){
this.modCount++;
this.header.next=this.header.previous=this.header;
this.$size=0;
});
$_V(c$,"get",
function(index){
return this.entry(index).element;
},"~N");
$_V(c$,"set",
function(index,element){
var e=this.entry(index);
var oldVal=e.element;
e.element=element;
return oldVal;
},"~N,~O");
$_M(c$,"add",
function(index,element){
this.addBefore(element,(index==this.$size?this.header:this.entry(index)));
},"~N,~O");
$_M(c$,"remove",
function(index){
var e=this.entry(index);
this.remove(e);
return e.element;
},"~N");
$_M(c$,"entry",
($fz=function(index){
if(index<0||index>=this.$size)throw new IndexOutOfBoundsException("Index: "+index+", Size: "+this.$size);
var e=this.header;
if(index<(this.$size>>1)){
for(var i=0;i<=index;i++)e=e.next;

}else{
for(var i=this.$size;i>index;i--)e=e.previous;

}return e;
},$fz.isPrivate=true,$fz),"~N");
$_V(c$,"indexOf",
function(o){
var index=0;
if(o==null){
for(var e=this.header.next;e!=this.header;e=e.next){
if(e.element==null)return index;
index++;
}
}else{
for(var e=this.header.next;e!=this.header;e=e.next){
if(o.equals(e.element))return index;
index++;
}
}return-1;
},"~O");
$_V(c$,"lastIndexOf",
function(o){
var index=this.$size;
if(o==null){
for(var e=this.header.previous;e!=this.header;e=e.previous){
index--;
if(e.element==null)return index;
}
}else{
for(var e=this.header.previous;e!=this.header;e=e.previous){
index--;
if(o.equals(e.element))return index;
}
}return-1;
},"~O");
$_M(c$,"listIterator",
function(index){
return $_N(java.util.LinkedList.ListItr,this,null,index);
},"~N");
$_M(c$,"addBefore",
($fz=function(o,e){
var newEntry=new java.util.LinkedList.Entry(o,e,e.previous);
newEntry.previous.next=newEntry;
newEntry.next.previous=newEntry;
this.$size++;
this.modCount++;
return newEntry;
},$fz.isPrivate=true,$fz),"~O,java.util.LinkedList.Entry");
$_M(c$,"remove",
($fz=function(e){
if(e==this.header)throw new java.util.NoSuchElementException();
e.previous.next=e.next;
e.next.previous=e.previous;
this.$size--;
this.modCount++;
},$fz.isPrivate=true,$fz),"java.util.LinkedList.Entry");
$_M(c$,"clone",
function(){
var clone=null;
try{
clone=$_U(this,java.util.LinkedList,"clone",[]);
}catch(e){
if($_O(e,CloneNotSupportedException)){
throw new InternalError();
}else{
throw e;
}
}
clone.header=new java.util.LinkedList.Entry(null,null,null);
clone.header.next=clone.header.previous=clone.header;
clone.$size=0;
clone.modCount=0;
for(var e=this.header.next;e!=this.header;e=e.next)clone.add(e.element);

return clone;
});
$_M(c$,"toArray",
function(){
var result=new Array(this.$size);
var i=0;
for(var e=this.header.next;e!=this.header;e=e.next)result[i++]=e.element;

return result;
});
$_M(c$,"toArray",
function(a){
if(a.length<this.$size)a=java.lang.reflect.Array.newInstance(a.getClass().getComponentType(),this.$size);
var i=0;
for(var e=this.header.next;e!=this.header;e=e.next)a[i++]=e.element;

if(a.length>this.$size)a[this.$size]=null;
return a;
},"~A");
});
