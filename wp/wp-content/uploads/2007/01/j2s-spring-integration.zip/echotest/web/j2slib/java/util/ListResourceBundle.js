﻿$_L(["java.util.ResourceBundle"],"java.util.ListResourceBundle",["java.lang.NullPointerException","java.util.HashMap","$.ResourceBundleEnumeration"],function(){
c$=$_C(function(){
this.lookup=null;
$_Z(this,arguments);
},java.util,"ListResourceBundle",java.util.ResourceBundle);
$_K(c$,
function(){
$_R(this,java.util.ListResourceBundle,[]);
});
$_V(c$,"handleGetObject",
function(key){
if(this.lookup==null){
this.loadLookup();
}if(key==null){
throw new NullPointerException();
}return this.lookup.get(key);
},"~S");
$_M(c$,"getKeys",
function(){
if(this.lookup==null){
this.loadLookup();
}var parent=this.parent;
return new java.util.ResourceBundleEnumeration(this.lookup.keySet(),(parent!=null)?parent.getKeys():null);
});
$_M(c$,"loadLookup",
($fz=function(){
if(this.lookup!=null)return;
var contents=this.getContents();
var temp=new java.util.HashMap(contents.length);
for(var i=0;i<contents.length;++i){
var key=contents[i][0];
var value=contents[i][1];
if(key==null||value==null){
throw new NullPointerException();
}temp.put(key,value);
}
this.lookup=temp;
},$fz.isPrivate=true,$fz));
});
