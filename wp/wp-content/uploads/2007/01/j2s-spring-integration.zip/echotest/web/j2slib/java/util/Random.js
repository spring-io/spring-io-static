﻿$_L(null,"java.util.Random",["java.lang.IllegalArgumentException"],function(){
c$=$_C(function(){
this.seed=null;
this.nextNextGaussian=0;
this.haveNextNextGaussian=false;
$_Z(this,arguments);
},java.util,"Random",null,java.io.Serializable);
$_K(c$,
function(){
this.construct(System.currentTimeMillis());
});
$_K(c$,
function(seed){
{
}this.setSeed(seed);
},"~N");
$_M(c$,"setSeed",
function(seed){
seed=(seed^25214903917)&281474976710655;
{
}this.haveNextNextGaussian=false;
},"~N");
$_M(c$,"nextBytes",
function(bytes){
for(var i=0;i<bytes.length;i++){
bytes[i]=Math.round(0x100*Math.random());
}
},"~A");
$_M(c$,"nextInt",
function(){
return Math.ceil(0xffff*Math.random())-0x8000;
});
$_M(c$,"nextInt",
function(n){
if(n<=0)throw new IllegalArgumentException("n must be positive");
if((n&-n)==n)return((n*this.next(31))>>31);
var bits;
var val;
do{
bits=this.next(31);
val=bits%n;
}while(bits-val+(n-1)<0);
return val;
},"~N");
$_M(c$,"nextLong",
function(){
return((this.next(32))<<32)+this.next(32);
});
$_M(c$,"nextBoolean",
function(){
return this.next(1)!=0;
});
$_M(c$,"nextFloat",
function(){
return Math.random();
});
$_M(c$,"nextDouble",
function(){
return Math.random();
});
$_M(c$,"nextGaussian",
function(){
if(this.haveNextNextGaussian){
this.haveNextNextGaussian=false;
return this.nextNextGaussian;
}else{
var v1;
var v2;
var s;
do{
v1=2*this.nextDouble()-1;
v2=2*this.nextDouble()-1;
s=v1*v1+v2*v2;
}while(s>=1||s==0);
var multiplier=Math.sqrt(-2*Math.log(s)/s);
this.nextNextGaussian=v2*multiplier;
this.haveNextNextGaussian=true;
return v1*multiplier;
}});
$_S(c$,
"multiplier",0x5DEECE66D,
"addend",0xB,
"mask",281474976710655,
"BITS_PER_BYTE",8,
"BYTES_PER_INT",4);
});
