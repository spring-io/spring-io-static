﻿$_L(["java.lang.ref.WeakReference","java.util.AbstractCollection","$.AbstractMap","$.AbstractSet","$.Iterator","$.Map","java.lang.ref.ReferenceQueue"],"java.util.WeakHashMap",["java.lang.Float","$.IllegalArgumentException","$.IllegalStateException","java.util.ArrayList","$.ConcurrentModificationException","$.HashMap","$.NoSuchElementException"],function(){
c$=$_C(function(){
this.table=null;
this.$size=0;
this.threshold=0;
this.loadFactor=0;
this.queue=null;
this.modCount=0;
if(!$_D("java.util.WeakHashMap.HashIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.index=0;
this.entry=null;
this.lastReturned=null;
this.expectedModCount=0;
this.nextKey=null;
this.currentKey=null;
$_Z(this,arguments);
},java.util.WeakHashMap,"HashIterator",null,java.util.Iterator);
$_Y(c$,function(){
this.expectedModCount=this.b$["java.util.WeakHashMap"].modCount;
});
$_K(c$,
function(){
this.index=(this.b$["java.util.WeakHashMap"].size()!=0?this.b$["java.util.WeakHashMap"].table.length:0);
});
$_V(c$,"hasNext",
function(){
var a=this.b$["java.util.WeakHashMap"].table;
while(this.nextKey==null){
var b=this.entry;
var c=this.index;
while(b==null&&c>0)b=a[--c];

this.entry=b;
this.index=c;
if(b==null){
this.currentKey=null;
return false;
}this.nextKey=b.get();
if(this.nextKey==null)this.entry=this.entry.$next;
}
return true;
});
$_M(c$,"nextEntry",
function(){
if(this.b$["java.util.WeakHashMap"].modCount!=this.expectedModCount)throw new java.util.ConcurrentModificationException();
if(this.nextKey==null&&!this.hasNext())throw new java.util.NoSuchElementException();
this.lastReturned=this.entry;
this.entry=this.entry.$next;
this.currentKey=this.nextKey;
this.nextKey=null;
return this.lastReturned;
});
$_V(c$,"remove",
function(){
if(this.lastReturned==null)throw new IllegalStateException();
if(this.b$["java.util.WeakHashMap"].modCount!=this.expectedModCount)throw new java.util.ConcurrentModificationException();
this.b$["java.util.WeakHashMap"].remove(this.currentKey);
this.expectedModCount=this.b$["java.util.WeakHashMap"].modCount;
this.lastReturned=null;
this.currentKey=null;
});
c$=$_P();
}
if(!$_D("java.util.WeakHashMap.ValueIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.WeakHashMap,"ValueIterator",java.util.WeakHashMap.HashIterator,null,$_N(java.util.WeakHashMap.HashIterator,this,null,$_G));
$_V(c$,"next",
function(){
return this.nextEntry().value;
});
c$=$_P();
}
if(!$_D("java.util.WeakHashMap.KeyIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.WeakHashMap,"KeyIterator",java.util.WeakHashMap.HashIterator,null,$_N(java.util.WeakHashMap.HashIterator,this,null,$_G));
$_V(c$,"next",
function(){
return this.nextEntry().getKey();
});
c$=$_P();
}
if(!$_D("java.util.WeakHashMap.EntryIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.WeakHashMap,"EntryIterator",java.util.WeakHashMap.HashIterator,null,$_N(java.util.WeakHashMap.HashIterator,this,null,$_G));
$_V(c$,"next",
function(){
return this.nextEntry();
});
c$=$_P();
}
this.$entrySet=null;
if(!$_D("java.util.WeakHashMap.KeySet")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.WeakHashMap,"KeySet",java.util.AbstractSet);
$_V(c$,"iterator",
function(){
return $_N(java.util.WeakHashMap.KeyIterator,this,null);
});
$_V(c$,"size",
function(){
return this.b$["java.util.WeakHashMap"].size();
});
$_V(c$,"contains",
function(a){
return this.b$["java.util.WeakHashMap"].containsKey(a);
},"~O");
$_V(c$,"remove",
function(a){
if(this.b$["java.util.WeakHashMap"].containsKey(a)){
this.b$["java.util.WeakHashMap"].remove(a);
return true;
}else return false;
},"~O");
$_V(c$,"clear",
function(){
this.b$["java.util.WeakHashMap"].clear();
});
$_M(c$,"toArray",
function(){
var a=new java.util.ArrayList(this.size());
for(var b=this.iterator();b.hasNext();)a.add(b.next());

return a.toArray();
});
$_M(c$,"toArray",
function(a){
var b=new java.util.ArrayList(this.size());
for(var c=this.iterator();c.hasNext();)b.add(c.next());

return b.toArray(a);
},"~A");
c$=$_P();
}
if(!$_D("java.util.WeakHashMap.Values")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.WeakHashMap,"Values",java.util.AbstractCollection);
$_V(c$,"iterator",
function(){
return $_N(java.util.WeakHashMap.ValueIterator,this,null);
});
$_V(c$,"size",
function(){
return this.b$["java.util.WeakHashMap"].size();
});
$_V(c$,"contains",
function(a){
return this.b$["java.util.WeakHashMap"].containsValue(a);
},"~O");
$_V(c$,"clear",
function(){
this.b$["java.util.WeakHashMap"].clear();
});
$_M(c$,"toArray",
function(){
var a=new java.util.ArrayList(this.size());
for(var b=this.iterator();b.hasNext();)a.add(b.next());

return a.toArray();
});
$_M(c$,"toArray",
function(a){
var b=new java.util.ArrayList(this.size());
for(var c=this.iterator();c.hasNext();)b.add(c.next());

return b.toArray(a);
},"~A");
c$=$_P();
}
if(!$_D("java.util.WeakHashMap.EntrySet")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.WeakHashMap,"EntrySet",java.util.AbstractSet);
$_V(c$,"iterator",
function(){
return $_N(java.util.WeakHashMap.EntryIterator,this,null);
});
$_V(c$,"contains",
function(a){
if(!($_O(a,java.util.Map.Entry)))return false;
var b=a;
var c=b.getKey();
var d=this.b$["java.util.WeakHashMap"].getEntry(b.getKey());
return d!=null&&d.equals(b);
},"~O");
$_V(c$,"remove",
function(a){
return this.b$["java.util.WeakHashMap"].removeMapping(a)!=null;
},"~O");
$_V(c$,"size",
function(){
return this.b$["java.util.WeakHashMap"].size();
});
$_V(c$,"clear",
function(){
this.b$["java.util.WeakHashMap"].clear();
});
$_M(c$,"toArray",
function(){
var a=new java.util.ArrayList(this.size());
for(var b=this.iterator();b.hasNext();)a.add(new java.util.AbstractMap.SimpleEntry(b.next()));

return a.toArray();
});
$_M(c$,"toArray",
function(a){
var b=new java.util.ArrayList(this.size());
for(var c=this.iterator();c.hasNext();)b.add(new java.util.AbstractMap.SimpleEntry(c.next()));

return b.toArray(a);
},"~A");
c$=$_P();
}
$_Z(this,arguments);
},java.util,"WeakHashMap",java.util.AbstractMap,java.util.Map);
$_H();
c$=$_C(function(){
this.value=null;
this.hash=0;
this.$next=null;
$_Z(this,arguments);
},java.util.WeakHashMap,"Entry",java.lang.ref.WeakReference,java.util.Map.Entry);
$_K(c$,
function(a,b,c,d,e){
$_R(this,java.util.WeakHashMap.Entry,[a,c]);
this.value=b;
this.hash=d;
this.$next=e;
},"~O,~O,java.lang.ref.ReferenceQueue,~N,java.util.WeakHashMap.Entry");
$_M(c$,"getKey",
function(){
return java.util.WeakHashMap.unmaskNull(this.get());
});
$_M(c$,"getValue",
function(){
return this.value;
});
$_V(c$,"setValue",
function(a){
var b=this.value;
this.value=a;
return b;
},"~O");
$_V(c$,"equals",
function(a){
if(!($_O(a,java.util.Map.Entry)))return false;
var b=a;
var c=this.getKey();
var d=b.getKey();
if(c==d||(c!=null&&c.equals(d))){
var e=this.getValue();
var f=b.getValue();
if(e==f||(e!=null&&e.equals(f)))return true;
}return false;
},"~O");
$_V(c$,"hashCode",
function(){
var a=this.getKey();
var b=this.getValue();
return((a==null?0:a.hashCode())^(b==null?0:b.hashCode()));
});
$_V(c$,"toString",
function(){
return this.getKey()+"="+this.getValue();
});
c$=$_P();
$_Y(c$,function(){
this.queue=new java.lang.ref.ReferenceQueue();
});
$_K(c$,
function(initialCapacity,loadFactor){
$_R(this,java.util.WeakHashMap,[]);
if(initialCapacity<0)throw new IllegalArgumentException("Illegal Initial Capacity: "+initialCapacity);
if(initialCapacity>1073741824)initialCapacity=1073741824;
if(loadFactor<=0||Float.isNaN(loadFactor))throw new IllegalArgumentException("Illegal Load factor: "+loadFactor);
var capacity=1;
while(capacity<initialCapacity)capacity<<=1;

this.table=new Array(capacity);
this.loadFactor=loadFactor;
this.threshold=Math.round((capacity*loadFactor));
},"~N,~N");
$_K(c$,
function(initialCapacity){
this.construct(initialCapacity,0.75);
},"~N");
$_K(c$,
function(){
$_R(this,java.util.WeakHashMap,[]);
this.loadFactor=0.75;
this.threshold=(16);
this.table=new Array(16);
});
$_K(c$,
function(t){
this.construct(Math.max(Math.round((t.size()/0.75))+1,16),0.75);
this.putAll(t);
},"java.util.Map");
c$.maskNull=$_M(c$,"maskNull",
($fz=function(key){
return(key==null?java.util.WeakHashMap.NULL_KEY:key);
},$fz.isPrivate=true,$fz),"~O");
c$.unmaskNull=$_M(c$,"unmaskNull",
($fz=function(key){
return(key==java.util.WeakHashMap.NULL_KEY?null:key);
},$fz.isPrivate=true,$fz),"~O");
c$.eq=$_M(c$,"eq",
function(x,y){
return x==y||x.equals(y);
},"~O,~O");
c$.indexFor=$_M(c$,"indexFor",
function(h,length){
return h&(length-1);
},"~N,~N");
$_M(c$,"expungeStaleEntries",
($fz=function(){
var r;
while((r=this.queue.poll())!=null){
var e=r;
var h=e.hash;
var i=java.util.WeakHashMap.indexFor(h,this.table.length);
var prev=this.table[i];
var p=prev;
while(p!=null){
var next=p.$next;
if(p==e){
if(prev==e)this.table[i]=next;
else prev.$next=next;
e.$next=null;
e.value=null;
this.$size--;
break;
}prev=p;
p=next;
}
}
},$fz.isPrivate=true,$fz));
$_M(c$,"getTable",
($fz=function(){
this.expungeStaleEntries();
return this.table;
},$fz.isPrivate=true,$fz));
$_M(c$,"size",
function(){
if(this.$size==0)return 0;
this.expungeStaleEntries();
return this.$size;
});
$_V(c$,"isEmpty",
function(){
return this.size()==0;
});
$_V(c$,"get",
function(key){
var k=java.util.WeakHashMap.maskNull(key);
var h=java.util.HashMap.hash(k);
var tab=this.getTable();
var index=java.util.WeakHashMap.indexFor(h,tab.length);
var e=tab[index];
while(e!=null){
if(e.hash==h&&java.util.WeakHashMap.eq(k,e.get()))return e.value;
e=e.$next;
}
return null;
},"~O");
$_V(c$,"containsKey",
function(key){
return this.getEntry(key)!=null;
},"~O");
$_M(c$,"getEntry",
function(key){
var k=java.util.WeakHashMap.maskNull(key);
var h=java.util.HashMap.hash(k);
var tab=this.getTable();
var index=java.util.WeakHashMap.indexFor(h,tab.length);
var e=tab[index];
while(e!=null&&!(e.hash==h&&java.util.WeakHashMap.eq(k,e.get())))e=e.$next;

return e;
},"~O");
$_V(c$,"put",
function(key,value){
var k=java.util.WeakHashMap.maskNull(key);
var h=java.util.HashMap.hash(k);
var tab=this.getTable();
var i=java.util.WeakHashMap.indexFor(h,tab.length);
for(var e=tab[i];e!=null;e=e.$next){
if(h==e.hash&&java.util.WeakHashMap.eq(k,e.get())){
var oldValue=e.value;
if(value!=oldValue)e.value=value;
return oldValue;
}}
this.modCount++;
tab[i]=new java.util.WeakHashMap.Entry(k,value,this.queue,h,tab[i]);
if(++this.$size>=this.threshold)this.resize(tab.length*2);
return null;
},"~O,~O");
$_M(c$,"resize",
function(newCapacity){
var oldTable=this.getTable();
var oldCapacity=oldTable.length;
if(oldCapacity==1073741824){
this.threshold=2147483647;
return;
}var newTable=new Array(newCapacity);
this.transfer(oldTable,newTable);
this.table=newTable;
if(this.$size>=Math.floor(this.threshold/2)){
this.threshold=Math.round((newCapacity*this.loadFactor));
}else{
this.expungeStaleEntries();
this.transfer(newTable,oldTable);
this.table=oldTable;
}},"~N");
$_M(c$,"transfer",
($fz=function(src,dest){
for(var j=0;j<src.length;++j){
var e=src[j];
src[j]=null;
while(e!=null){
var next=e.$next;
var key=e.get();
if(key==null){
e.$next=null;
e.value=null;
this.$size--;
}else{
var i=java.util.WeakHashMap.indexFor(e.hash,dest.length);
e.$next=dest[i];
dest[i]=e;
}e=next;
}
}
},$fz.isPrivate=true,$fz),"~A,~A");
$_V(c$,"putAll",
function(m){
var numKeysToBeAdded=m.size();
if(numKeysToBeAdded==0)return;
if(numKeysToBeAdded>this.threshold){
var targetCapacity=Math.round((numKeysToBeAdded/this.loadFactor+1));
if(targetCapacity>1073741824)targetCapacity=1073741824;
var newCapacity=this.table.length;
while(newCapacity<targetCapacity)newCapacity<<=1;

if(newCapacity>this.table.length)this.resize(newCapacity);
}for(var i=m.entrySet().iterator();i.hasNext();){
var e=i.next();
this.put(e.getKey(),e.getValue());
}
},"java.util.Map");
$_V(c$,"remove",
function(key){
var k=java.util.WeakHashMap.maskNull(key);
var h=java.util.HashMap.hash(k);
var tab=this.getTable();
var i=java.util.WeakHashMap.indexFor(h,tab.length);
var prev=tab[i];
var e=prev;
while(e!=null){
var next=e.$next;
if(h==e.hash&&java.util.WeakHashMap.eq(k,e.get())){
this.modCount++;
this.$size--;
if(prev==e)tab[i]=next;
else prev.$next=next;
return e.value;
}prev=e;
e=next;
}
return null;
},"~O");
$_M(c$,"removeMapping",
function(o){
if(!($_O(o,java.util.Map.Entry)))return null;
var tab=this.getTable();
var entry=o;
var k=java.util.WeakHashMap.maskNull(entry.getKey());
var h=java.util.HashMap.hash(k);
var i=java.util.WeakHashMap.indexFor(h,tab.length);
var prev=tab[i];
var e=prev;
while(e!=null){
var next=e.$next;
if(h==e.hash&&e.equals(entry)){
this.modCount++;
this.$size--;
if(prev==e)tab[i]=next;
else prev.$next=next;
return e;
}prev=e;
e=next;
}
return null;
},"~O");
$_V(c$,"clear",
function(){
while(this.queue.poll()!=null);
this.modCount++;
var tab=this.table;
for(var i=0;i<tab.length;++i)tab[i]=null;

this.$size=0;
while(this.queue.poll()!=null);
});
$_V(c$,"containsValue",
function(value){
if(value==null)return this.containsNullValue();
var tab=this.getTable();
for(var i=tab.length;i-->0;)for(var e=tab[i];e!=null;e=e.$next)if(value.equals(e.value))return true;


return false;
},"~O");
$_M(c$,"containsNullValue",
($fz=function(){
var tab=this.getTable();
for(var i=tab.length;i-->0;)for(var e=tab[i];e!=null;e=e.$next)if(e.value==null)return true;


return false;
},$fz.isPrivate=true,$fz));
$_V(c$,"keySet",
function(){
var ks=this.$keySet;
return(ks!=null?ks:(this.$keySet=$_N(java.util.WeakHashMap.KeySet,this,null)));
});
$_V(c$,"values",
function(){
var vs=this.$values;
return(vs!=null?vs:(this.$values=$_N(java.util.WeakHashMap.Values,this,null)));
});
$_M(c$,"entrySet",
function(){
var es=this.$entrySet;
return(es!=null?es:(this.$entrySet=$_N(java.util.WeakHashMap.EntrySet,this,null)));
});
$_S(c$,
"DEFAULT_INITIAL_CAPACITY",16,
"MAXIMUM_CAPACITY",1073741824,
"DEFAULT_LOAD_FACTOR",0.75);
c$.NULL_KEY=c$.prototype.NULL_KEY=new Object();
});
