﻿Clazz.declarePackage ("junit.framework");
Clazz.declareInterface (junit.framework, "Protectable");
