﻿Clazz.declarePackage ("junit.runner");
c$ = Clazz.declareType (junit.runner, "Version");
c$.id = Clazz.defineMethod (c$, "id", 
function () {
return "3.8.1";
});
