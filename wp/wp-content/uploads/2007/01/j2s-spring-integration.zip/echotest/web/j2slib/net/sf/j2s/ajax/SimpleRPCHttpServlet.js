﻿$_J("net.sf.j2s.ajax");
$_L(["javax.servlet.http.HttpServlet","java.util.HashSet"],"net.sf.j2s.ajax.SimpleRPCHttpServlet",["java.io.ByteArrayOutputStream","java.lang.RuntimeException"],function(){
c$=$_C(function(){
this.runnables=null;
$_Z(this,arguments);
},net.sf.j2s.ajax,"SimpleRPCHttpServlet",javax.servlet.http.HttpServlet);
$_Y(c$,function(){
this.runnables=new java.util.HashSet();
});
$_M(c$,"getRunnableByURL",
function(request){
if(request==null)return null;
var length=request.length;
if(length<=7||!request.startsWith("WLL"))return null;
var index=request.indexOf('#');
if(index==-1)return null;
var clazzName=request.substring(6,index);
if(this.runnables.contains(clazzName)){
if(request!=null){
var obj=this.getNewInstanceByClassName(clazzName);
if(obj!=null&&$_O(obj,net.sf.j2s.ajax.SimpleRPCRunnable)){
return obj;
}}}return null;
},"~S");
$_M(c$,"getNewInstanceByClassName",
function(className){
try{
var runnableClass=Class.forName(className);
if(runnableClass!=null){
var constructor=runnableClass.getConstructor(new Array(0));
return constructor.newInstance(new Array(0));
}}catch(e){
if($_O(e,SecurityException)){
e.printStackTrace();
}else if($_O(e,IllegalArgumentException)){
e.printStackTrace();
}else if($_O(e,ClassNotFoundException)){
e.printStackTrace();
}else if($_O(e,NoSuchMethodException)){
e.printStackTrace();
}else if($_O(e,InstantiationException)){
e.printStackTrace();
}else if($_O(e,IllegalAccessException)){
e.printStackTrace();
}else if($_O(e,java.lang.reflect.InvocationTargetException)){
e.printStackTrace();
}else{
throw e;
}
}
return null;
},"~S");
$_M(c$,"readAll",
($fz=function(res){
try{
var baos=new java.io.ByteArrayOutputStream();
var buf=$_A(1024,0);
var read=0;
while((read=res.read(buf))!=-1){
baos.write(buf,0,read);
if(baos.size()>0x1000000){
res.close();
throw new RuntimeException("Data size reaches the limit of Java2Script Simple RPC!");
}}
res.close();
return baos.toString();
}catch(e){
if($_O(e,java.io.IOException)){
e.printStackTrace();
}else{
throw e;
}
}
return null;
},$fz.isPrivate=true,$fz),"java.io.InputStream");
$_M(c$,"init",
function(){
var runnableStr=this.getInitParameter("simple.rpc.runnables");
if(runnableStr!=null){
var splits=runnableStr.trim().$plit("\\s*[,;:]\\s*");
for(var i=0;i<splits.length;i++){
var trim=splits[i].trim();
if(trim.length!=0){
this.runnables.add(trim);
}}
}});
$_V(c$,"doPost",
function(req,resp){
var request=this.readAll(req.getInputStream());
var runnable=this.getRunnableByURL(request);
if(runnable==null){
resp.sendError(404);
return;
}var writer=resp.getWriter();
resp.setContentType("text/plain");
runnable.deserialize(request);
runnable.ajaxRun();
writer.write(runnable.serialize());
},"javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse");
$_V(c$,"doGet",
function(req,resp){
var request=req.getQueryString();
var runnable=this.getRunnableByURL(request);
if(runnable==null){
resp.sendError(404);
return;
}var writer=resp.getWriter();
resp.setContentType("text/plain");
runnable.deserialize(request);
runnable.ajaxRun();
writer.write(runnable.serialize());
},"javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse");
});
