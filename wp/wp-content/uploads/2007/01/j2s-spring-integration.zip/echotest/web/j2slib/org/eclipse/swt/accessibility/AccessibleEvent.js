﻿$_L(["$wt.internal.SWTEventObject"],"$wt.accessibility.AccessibleEvent",null,function(){
c$=$_C(function(){
this.childID=0;
this.result=null;
$_Z(this,arguments);
},$wt.accessibility,"AccessibleEvent",$wt.internal.SWTEventObject);
$_V(c$,"toString",
function(){
return"AccessibleEvent {childID="+this.childID+" result="+this.result+"}";
});
});
