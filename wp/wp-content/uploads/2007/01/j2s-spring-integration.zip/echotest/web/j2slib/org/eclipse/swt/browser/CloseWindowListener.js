﻿$_L(["$wt.internal.SWTEventListener"],"$wt.browser.CloseWindowListener",null,function(){
$_I($wt.browser,"CloseWindowListener",$wt.internal.SWTEventListener);
});
