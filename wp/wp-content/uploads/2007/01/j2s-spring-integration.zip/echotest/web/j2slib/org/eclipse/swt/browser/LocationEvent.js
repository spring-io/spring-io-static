﻿$_L(["$wt.events.TypedEvent"],"$wt.browser.LocationEvent",null,function(){
c$=$_C(function(){
this.location=null;
this.top=false;
this.doit=false;
$_Z(this,arguments);
},$wt.browser,"LocationEvent",$wt.events.TypedEvent);
});
