﻿$_L(["$wt.internal.SWTEventListener"],"$wt.browser.VisibilityWindowListener",null,function(){
$_I($wt.browser,"VisibilityWindowListener",$wt.internal.SWTEventListener);
});
