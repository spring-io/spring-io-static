﻿$_L(["$wt.internal.SWTEventListener"],"$wt.custom.LineStyleListener",null,function(){
$_I($wt.custom,"LineStyleListener",$wt.internal.SWTEventListener);
});
