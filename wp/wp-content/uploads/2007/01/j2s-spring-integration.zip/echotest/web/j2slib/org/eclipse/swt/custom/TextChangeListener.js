﻿$_L(["$wt.internal.SWTEventListener"],"$wt.custom.TextChangeListener",null,function(){
$_I($wt.custom,"TextChangeListener",$wt.internal.SWTEventListener);
});
