﻿c$=$_T($wt.dnd,"Transfer");
c$.registerType=$_M(c$,"registerType",
function(formatName){
return 0;
},"~S");
$_M(c$,"validate",
function(object){
return true;
},"~O");
