﻿$_L(["$wt.internal.SWTEventListener"],"$wt.events.HelpListener",null,function(){
$_I($wt.events,"HelpListener",$wt.internal.SWTEventListener);
});
