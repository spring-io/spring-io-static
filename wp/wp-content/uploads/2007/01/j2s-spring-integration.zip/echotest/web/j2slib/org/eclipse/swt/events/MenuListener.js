﻿$_L(["$wt.internal.SWTEventListener"],"$wt.events.MenuListener",null,function(){
$_I($wt.events,"MenuListener",$wt.internal.SWTEventListener);
});
