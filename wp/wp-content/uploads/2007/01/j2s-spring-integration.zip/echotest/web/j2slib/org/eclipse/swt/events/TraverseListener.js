﻿$_L(["$wt.internal.SWTEventListener"],"$wt.events.TraverseListener",null,function(){
$_I($wt.events,"TraverseListener",$wt.internal.SWTEventListener);
});
