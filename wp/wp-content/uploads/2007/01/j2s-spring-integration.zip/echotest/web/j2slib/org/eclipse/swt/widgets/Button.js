﻿$_L(["$wt.widgets.Control"],"$wt.widgets.Button",["java.lang.Character","$wt.graphics.Color","$.Point","$wt.internal.RunnableCompatibility","$wt.internal.browser.OS","$wt.widgets.TypedListener"],function(){
$WTC$$.registerCSS("$wt.widgets.Button", ".button-default {\nposition:absolute;\nwhite-space:nowrap;\nfont-family:Tahoma, Arial, sans-serif;\nfont-size:8pt;\nmargin:0;\npadding:0;\noverflow:hidden;\n}\n.button-border {\nborder:2px inset white;\n}\n.button-flat .button-push {\nborder:2px solid buttonshadow;\n}\n.button-flat .button-toggle {\nborder:2px solid buttonshadow;\n}\n.button-flat .button-arrow {\nborder:2px solid buttonshadow;\n}\n.button-push, .button-toggle, .button-arrow {\nposition:absolute;\nwhite-space:nowrap;\nfont-family:inherit;\nfont-size:1em;\nfont-size:inherit;\nmargin:0;\npadding:0;\nwidth:100%;\nheight:100%;\n}\n* html .button-push {\nfont-family:Tahoma, Arial, sans-serif;\nfont-size:1em;\n}\n* html .button-toggle {\nfont-family:Tahoma, Arial, sans-serif;\nfont-size:1em;\n}\n@media all and (min-width:0px){/* opera */\n.button-push, .button-toggle, .button-arrow {\nborder-width:2px;\nborder-style:solid;\nbackground-color:buttonface;\nborder-color:#f0f0f0 #303030 #303030 #f0f0f0;\n}\n}\n.button-check, .button-radio {\n}\n.button-check .button-input-wrapper {\nfloat:left;\nposition:relative;\nbottom:-0.5em;\n}\n.button-radio .button-input-wrapper {\nfloat:left;\nposition:relative;\nbottom:-0.5em;\n}\n.button-text {\nposition:relative;\n/*padding-left:2px;*/\ncursor:default;\n}\n* html .button-text {\npadding-left:0;\n}\n.button-disabled .button-text {\ncolor:gray;\n}\n.button-input-wrapper INPUT {\nposition:relative;\ntop:-6px;\nmargin-left:0;\n/*margin-right:0;*/\npadding-left:0;\npadding-right:0;\n}\n* html .button-input-wrapper INPUT {\nleft:-1px;\ntop:-4px;\nwidth:13px;\nheight:13px;\noverflow:hidden;\n}\n@media all and (min-width:0px){/* opera */\n.button-input-wrapper INPUT {\nleft:0;\ntop:-4px;\nwidth:13px;\nheight:13px;\nmargin-right:2px;\noverflow:hidden;\n}\n}\n.button-selected {\nborder-style:inset;\nbackground-color:#eee7e0;\n}\n.button-arrow-left {\nmargin:auto;\nheight:0;\nwidth:0;\nfont-size:0;\nline-height:0;\nborder-style:solid solid solid none;\nborder-color:menu;\nborder-right-color:black;\nborder-left-width:0;\n}\n.button-arrow-right {\nmargin:auto;\nheight:0;\nwidth:0;\nfont-size:0;\nline-height:0;\nborder-style:solid none solid solid;\nborder-color:menu;\nborder-left-color:black;\nborder-right-width:0;\n}\n.button-arrow-up {\nmargin:auto;\nheight:0;\nwidth:0;\nfont-size:0;\nline-height:0;\nborder-style:none solid solid solid;\nborder-color:menu;\nborder-bottom-color:black;\nborder-top-width:0;\n}\n.button-arrow-down {\nmargin:auto;\nheight:0;\nwidth:0;\nfont-size:0;\nline-height:0;\nborder-style:solid solid none solid;\nborder-color:menu;\nborder-top-color:black;\nborder-bottom-width:0;\n}\n.button-disabled .button-arrow-left {\nborder-right-color:gray;\n}\n.button-disabled .button-arrow-right {\nborder-left-color:gray;\n}\n.button-disabled .button-arrow-up {\nborder-bottom-color:gray;\n}\n.button-disabled .button-arrow-down {\nborder-top-color:gray;\n}\n.button-default span {\ncursor:default;\n}\n.button-text-mnemonics {\ntext-decoration:underline;\n}\n.swt-widgets-button {\nwidth:324px;\n}\n");
c$=$_C(function(){
this.text="";
this.textSizeCached=false;
this.textWidthCached=0;
this.textHeightCached=0;
this.lastColor=null;
this.hasImage=false;
this.image=null;
this.image2=null;
this.imageList=null;
this.ignoreMouse=false;
this.btnText=null;
this.btnHandle=null;
$_Z(this,arguments);
},$wt.widgets,"Button",$wt.widgets.Control);
$_K(c$,
function(parent,style){
$_R(this,$wt.widgets.Button,[parent,$wt.widgets.Button.checkStyle(style)]);
},"$wt.widgets.Composite,~N");
$_M(c$,"_setImage",
function(image){
},"$wt.graphics.Image");
$_M(c$,"addSelectionListener",
function(listener){
var typedListener=new $wt.widgets.TypedListener(listener);
this.addListener(13,typedListener);
this.addListener(14,typedListener);
},"$wt.events.SelectionListener");
c$.checkStyle=$_M(c$,"checkStyle",
function(style){
style=$wt.widgets.Widget.checkBits(style,8,4,32,16,2,0);
if((style&(10))!=0){
return $wt.widgets.Widget.checkBits(style,16777216,16384,131072,0,0,0);
}if((style&(48))!=0){
return $wt.widgets.Widget.checkBits(style,16384,131072,16777216,0,0,0);
}if((style&4)!=0){
style|=524288;
return $wt.widgets.Widget.checkBits(style,128,1024,16384,131072,0,0);
}return style;
},"~N");
$_M(c$,"click",
function(){
this.ignoreMouse=true;
this.ignoreMouse=false;
});
$_M(c$,"computeSize",
function(wHint,hHint,changed){
var border=this.getBorderWidth();
var width=0;
var height=0;
if((this.style&4)!=0){
if((this.style&(1152))!=0){
width+=16;
height+=16;
}else{
width+=16;
height+=16;
}if(wHint!=-1)width=wHint;
if(hHint!=-1)height=hHint;
width+=border*2;
height+=border*2;
return new $wt.graphics.Point(width,height);
}var extra=0;
if(!this.hasImage){
if(this.text==null||this.text.length==0){
height+=O$.getStringStyledHeight(".","button-default",null);
}else{
if(!this.textSizeCached||changed){
var string=this.text.replaceAll("[\r\n]+","");
var cssSize=O$.getStringStyledSize(string,"button-default",this.handle.style.cssText);
this.textSizeCached=true;
this.textWidthCached=cssSize.x;
this.textHeightCached=cssSize.y;
}width=this.textWidthCached;
height=this.textHeightCached;
if((this.style&(48))!=0){
width-=5;
}extra=Math.max(8,height);
}}else{
if(this.image!=null){
var imageSize=O$.getImageSize(this.image);
width+=imageSize.x;
height=Math.max(imageSize.y,height);
extra=8;
}}if((this.style&(48))!=0){
width+=13+extra;
height=Math.max(height,16);
}if((this.style&(10))!=0){
width+=12;
height+=10;
}if(wHint!=-1)width=wHint;
if(hHint!=-1)height=hHint;
width+=border*2;
height+=border*2;
return new $wt.graphics.Point(width,height);
},"~N,~N,~B");
$_V(c$,"createHandle",
function(){
this.handle=d$.createElement("DIV");
var cssName="button-default";
if((this.style&2048)!=0){
cssName+=" button-border";
}if((this.style&8388608)!=0){
cssName+=" button-flat";
}this.handle.className=cssName;
if(this.parent!=null){
var parentHandle=this.parent.containerHandle();
if(parentHandle!=null){
parentHandle.appendChild(this.handle);
}}if((this.style&(48))!=0){
var btnEl=d$.createElement("DIV");
this.handle.appendChild(btnEl);
var btnWrapperEl=d$.createElement("DIV");
btnWrapperEl.className="button-input-wrapper";
btnEl.appendChild(btnWrapperEl);
this.btnHandle=d$.createElement("INPUT");
if((this.style&32)!=0){
btnEl.className="button-check";
this.btnHandle.type="checkbox";
}else{
btnEl.className="button-radio";
this.btnHandle.type="radio";
}btnWrapperEl.appendChild(this.btnHandle);
this.btnText=d$.createElement("DIV");
this.btnText.className="button-text";
btnEl.appendChild(this.btnText);
}else{
this.btnHandle=d$.createElement("BUTTON");
this.handle.appendChild(this.btnHandle);
this.btnText=d$.createElement("DIV");
this.btnHandle.appendChild(this.btnText);
if((this.style&2)!=0){
this.btnHandle.className="button-toggle";
}else if((this.style&4)!=0){
this.btnHandle.className="button-arrow";
this.updateArrowStyle();
}else{
this.btnHandle.className="button-push";
}}this.btnHandle.onmouseover=$_Q((function(i$,v$){
if(!$_D("org.eclipse.swt.widgets.Button$1")){
$_H();
c$=$_W($wt.widgets,"Button$1",$wt.internal.RunnableCompatibility);
$_V(c$,"run",
function(){
var cssName=" button-hover";
var idx=this.b$["$wt.widgets.Button"].btnHandle.className.indexOf(cssName);
if(idx==-1){
this.b$["$wt.widgets.Button"].btnHandle.className=this.b$["$wt.widgets.Button"].btnHandle.className+cssName;
}});
c$=$_P();
}
return $_N($wt.widgets.Button$1,i$,v$);
})(this,null));
this.btnHandle.onmouseout=$_Q((function(i$,v$){
if(!$_D("org.eclipse.swt.widgets.Button$2")){
$_H();
c$=$_W($wt.widgets,"Button$2",$wt.internal.RunnableCompatibility);
$_V(c$,"run",
function(){
var cssName=" button-hover";
var idx=this.b$["$wt.widgets.Button"].btnHandle.className.indexOf(cssName);
if(idx!=-1){
this.b$["$wt.widgets.Button"].btnHandle.className=this.b$["$wt.widgets.Button"].btnHandle.className.substring(0,idx)+this.b$["$wt.widgets.Button"].btnHandle.className.substring(cssName.length+idx);
}});
c$=$_P();
}
return $_N($wt.widgets.Button$2,i$,v$);
})(this,null));
this.hookSelection();
});
$_V(c$,"enableWidget",
function(enabled){
this.btnHandle.disabled=!enabled;
O$.updateCSSClass(this.btnHandle,"button-disabled",!enabled);
},"~B");
$_M(c$,"getAlignment",
function(){
if((this.style&4)!=0){
if((this.style&128)!=0)return 128;
if((this.style&1024)!=0)return 1024;
if((this.style&16384)!=0)return 16384;
if((this.style&131072)!=0)return 131072;
return 128;
}if((this.style&16384)!=0)return 16384;
if((this.style&16777216)!=0)return 16777216;
if((this.style&131072)!=0)return 131072;
return 16384;
});
$_V(c$,"getBorderWidth",
function(){
if((this.style&2048)!=0){
return 2;
}return 0;
});
$_M(c$,"getDefault",
function(){
if((this.style&8)==0)return false;
return false;
});
$_M(c$,"getImage",
function(){
return this.image;
});
$_V(c$,"getNameText",
function(){
return this.getText();
});
$_M(c$,"getSelection",
function(){
if((this.style&(50))==0)return false;
if((this.style&2)!=0){
return O$.existedCSSClass(this.btnHandle,"button-selected");
}else if((this.style&(48))!=0){
return this.btnHandle.checked;
}return false;
});
$_M(c$,"getText",
function(){
if((this.style&4)!=0)return"";
return this.text;
});
$_V(c$,"isEnabled",
function(){
return!this.btnHandle.disabled;
});
$_V(c$,"mnemonicHit",
function(ch){
if(!this.setFocus())return false;
if((this.style&16)==0)this.click();
return true;
},"~N");
$_V(c$,"mnemonicMatch",
function(key){
var mnemonic=this.findMnemonic(this.getText());
if((mnemonic).charCodeAt(0)==('\0').charCodeAt(0))return false;
return(Character.toUpperCase(key)).charCodeAt(0)==(Character.toUpperCase(mnemonic)).charCodeAt(0);
},"~N");
$_M(c$,"releaseHandle",
function(){
if(this.btnText!=null){
O$.destroyHandle(this.btnText);
this.btnText=null;
}if(this.btnHandle!=null){
O$.destroyHandle(this.btnHandle);
this.btnHandle=null;
}$_U(this,$wt.widgets.Button,"releaseHandle",[]);
});
$_M(c$,"releaseWidget",
function(){
$_U(this,$wt.widgets.Button,"releaseWidget",[]);
if(this.imageList!=null)this.imageList.dispose();
this.imageList=null;
if(this.image2!=null)this.image2.dispose();
this.image2=null;
this.text=null;
this.image=null;
});
$_M(c$,"removeSelectionListener",
function(listener){
if(this.eventTable==null)return;
this.eventTable.unhook(13,listener);
this.eventTable.unhook(14,listener);
},"$wt.events.SelectionListener");
$_M(c$,"selectRadio",
function(){
var children=this.parent._getChildren();
for(var i=0;i<children.length;i++){
var child=children[i];
if(this!=child)child.setRadioSelection(false);
}
this.setSelection(true);
});
$_M(c$,"setAlignment",
function(alignment){
if((this.style&4)!=0){
if((this.style&(148608))==0)return;
this.style&=-148609;
this.style|=alignment&(148608);
this.updateArrowStyle();
var cx=this.width;
var cy=this.height;
if((this.style&2048)!=0){
cx-=4;
cy-=4;
}O$.updateArrowSize(this.btnText,this.style,cx,cy);
return;
}if((alignment&(16924672))==0)return;
this.style&=-16924673;
this.style|=alignment&(16924672);
if((this.style&(10))!=0){
var handleStyle=null;
if((this.style&(48))!=0){
handleStyle=this.btnText.style;
}else{
handleStyle=this.btnHandle.style;
}if((this.style&16384)!=0){
this.btnText.style.textAlign="left";
handleStyle.backgroundPosition="left center";
}if((this.style&16777216)!=0){
this.btnText.style.textAlign="center";
handleStyle.backgroundPosition="center center";
}else if((this.style&131072)!=0){
this.btnText.style.textAlign="right";
handleStyle.backgroundPosition="right center";
}}},"~N");
$_M(c$,"setDefault",
function(value){
if((this.style&8)==0)return;
if(value){
try{
this.handle.focus();
}catch(e){
if($_O(e,Error)){
}else{
throw e;
}
}
}},"~B");
$_M(c$,"setFixedFocus",
function(){
if((this.style&16)!=0&&!this.getSelection())return false;
return $_U(this,$wt.widgets.Button,"setFixedFocus",[]);
});
$_V(c$,"setForeground",
function(color){
if(color!=null){
this.btnHandle.style.color=color.getCSSHandle();
}else{
this.btnHandle.style.color="";
}if(this.lastColor!=null){
this.lastColor=this.btnHandle.style.color;
}},"$wt.graphics.Color");
$_V(c$,"setBackground",
function(color){
if(color!=null){
this.btnHandle.style.backgroundColor=color.getCSSHandle();
}else{
this.btnHandle.style.backgroundColor="";
}},"$wt.graphics.Color");
$_V(c$,"getBackground",
function(){
var bg=this.btnHandle.style.backgroundColor;
if(bg==null||bg.toString().length==0){
return new $wt.graphics.Color(this.display,"menu");
}return new $wt.graphics.Color(this.display,bg);
});
$_V(c$,"getForeground",
function(){
var fg=this.btnHandle.style.color;
if(fg==null||fg.toString().length==0){
return new $wt.graphics.Color(this.display,"black");
}return new $wt.graphics.Color(this.display,this.handle.style.color);
});
$_M(c$,"setImage",
function(image){
if((this.style&4)!=0)return;
this.image=image;
this.hasImage=true;
if(this.image.handle==null&&this.image.url!=null&&this.image.url.length!=0){
O$.clearChildren(this.btnText);
this.btnText.style.display="";
this.btnText.style.paddingTop="";
this.btnHandle.parentNode.style.bottom="";
this.btnHandle.parentNode.style.top="";
this.btnHandle.style.top="";
this.btnText.parentNode.style.position="";
this.btnText.parentNode.style.top="";
var handleStyle=null;
if((this.style&(48))!=0){
handleStyle=this.btnText.style;
var img=new Image();
img.src=this.image.url;
this.image.width=img.width;
this.image.height=img.height;
handleStyle.display="block";
handleStyle.marginLeft=(16)+"px";
handleStyle.paddingTop=this.image.height+"px";
}else{
handleStyle=this.btnHandle.style;
}if(image.url.toLowerCase().endsWith(".png")&&handleStyle.filter!=null){
handleStyle.filter="progid:DXImageTransform.Microsoft.AlphaImageLoader(src=\"" + this.image.url + "\", sizingMethod=\"image\")";
}else{
handleStyle.backgroundRepeat="no-repeat";
var bgXPos="center";
if((this.style&(48))!=0){
if((this.style&131072)!=0){
bgXPos="right";
}else if((this.style&16777216)!=0){
bgXPos="center";
}else{
bgXPos="left";
}}handleStyle.backgroundPosition=bgXPos+" center";
handleStyle.backgroundImage="url(\"" + this.image.url + "\")";
}}},"$wt.graphics.Image");
$_V(c$,"setRadioFocus",
function(){
if((this.style&16)==0||!this.getSelection())return false;
return this.setFocus();
});
$_M(c$,"setRadioSelection",
function(value){
if((this.style&16)==0)return false;
if(this.getSelection()!=value){
this.setSelection(value);
this.postEvent(13);
}return true;
},"~B");
$_M(c$,"setSavedFocus",
function(){
if((this.style&16)!=0&&!this.getSelection())return false;
return $_U(this,$wt.widgets.Button,"setSavedFocus",[]);
});
$_M(c$,"setSelection",
function(selected){
if((this.style&(50))==0)return;
if((this.style&2)!=0){
O$.updateCSSClass(this.btnHandle,"button-selected",selected);
}else if((this.style&(48))!=0){
this.btnHandle.checked=selected;
}},"~B");
$_M(c$,"setText",
function(string){
if((this.style&4)!=0)return;
if(string!=this.text){
this.textSizeCached=false;
}O$.clearChildren(this.btnText);
if(this.hasImage){
this.btnText.style.backgroundImage="";
if(O$.isIE&&this.image.url!=null&&this.image.url.toLowerCase().endsWith(".png")&&this.btnText.style.filter!=null){
this.btnText.style.filter="";
}}this.text=string;
this.hasImage=false;
string=string.replaceAll("(&(&))|([\r\n]+)","$2");
var idx=string.indexOf('&');
if(idx==-1){
this.btnText.appendChild(d$.createTextNode(string));
}else{
this.btnText.appendChild(d$.createTextNode(string.substring(0,idx)));
var underline=d$.createElement("SPAN");
underline.appendChild(d$.createTextNode(string.substring(idx+1,idx+2)));
underline.className="button-text-mnemonics";
this.btnText.appendChild(underline);
this.btnText.appendChild(d$.createTextNode(string.substring(idx+2)));
}},"~S");
$_V(c$,"SetWindowPos",
function(hWnd,hWndInsertAfter,X,Y,cx,cy,uFlags){
if((this.style&2048)!=0){
cx-=4;
cy-=4;
}if((this.style&4)!=0){
O$.updateArrowSize(this.btnText,this.style,cx,cy);
}if((this.style&(48))!=0){
var h=0;
if(!this.hasImage){
if(this.textSizeCached){
this.btnText.style.display="block";
if(this.textHeightCached<13){
this.btnText.style.paddingTop=(Math.floor((13-this.textHeightCached)/2))+"px";
this.btnHandle.parentNode.style.bottom="0";
this.btnHandle.parentNode.style.top="0";
this.btnHandle.style.top="0";
}else{
this.btnText.style.paddingTop="0";
}}h=this.textHeightCached;
}else{
h=this.image.height;
}h=Math.max(16,h);
if(h<cy){
this.btnText.parentNode.style.position="relative";
this.btnText.parentNode.style.top=(Math.floor((cy-h)/2))+"px";
}}var el=hWnd;
el.style.left=X+"px";
el.style.top=Y+"px";
el.style.width=(cx>0?cx:0)+"px";
el.style.height=(cy>0?cy:0)+"px";
return true;
},"~O,~O,~N,~N,~N,~N,~N");
$_M(c$,"setCursor",
function(cursor){
if(this.handle!=null){
this.handle.style.cursor=cursor.handle;
}},"$wt.graphics.Cursor");
$_M(c$,"updateArrowStyle",
($fz=function(){
if((this.style&16384)!=0){
this.btnText.className="button-arrow-left";
}else if((this.style&131072)!=0){
this.btnText.className="button-arrow-right";
}else if((this.style&128)!=0){
this.btnText.className="button-arrow-up";
}else if((this.style&1024)!=0){
this.btnText.className="button-arrow-down";
}else{
this.btnText.className="button-arrow-up";
}},$fz.isPrivate=true,$fz));
$_V(c$,"hookSelection",
function(){
var eventHandler=$_Q((function(i$,v$){
if(!$_D("org.eclipse.swt.widgets.Button$3")){
$_H();
c$=$_W($wt.widgets,"Button$3",$wt.internal.RunnableCompatibility);
$_V(c$,"run",
function(){
if(!this.b$["$wt.widgets.Button"].isEnabled()){
this.toReturn(false);
return;
}if((this.b$["$wt.widgets.Button"].style&(34))!=0){
var e=this.getEvent();
if((this.b$["$wt.widgets.Button"].style&32)!=0){
if(e.srcElement!=this.b$["$wt.widgets.Button"].btnHandle){
this.b$["$wt.widgets.Button"].setSelection(!this.b$["$wt.widgets.Button"].getSelection());
}}else{
this.b$["$wt.widgets.Button"].setSelection(!this.b$["$wt.widgets.Button"].getSelection());
}}else{
if((this.b$["$wt.widgets.Button"].style&16)!=0){
if((this.b$["$wt.widgets.Button"].parent.getStyle()&4194304)!=0){
this.b$["$wt.widgets.Button"].setSelection(!this.b$["$wt.widgets.Button"].getSelection());
}else{
this.b$["$wt.widgets.Button"].selectRadio();
}}}this.b$["$wt.widgets.Button"].postEvent(13);
});
c$=$_P();
}
return $_N($wt.widgets.Button$3,i$,v$);
})(this,null));
this.handle.onclick=this.handle.ondblclick=eventHandler;
if((this.style&(48))!=0){
this.btnText.onclick=eventHandler;
}this.handle.onkeydown=$_Q((function(i$,v$){
if(!$_D("org.eclipse.swt.widgets.Button$4")){
$_H();
c$=$_W($wt.widgets,"Button$4",$wt.internal.RunnableCompatibility);
$_V(c$,"run",
function(){
var e=this.getEvent();
if(e.keyCode==32||e.keyCode==13){
this.toReturn(false);
}this.toReturn(true);
});
c$=$_P();
}
return $_N($wt.widgets.Button$4,i$,v$);
})(this,null));
});
$_S(c$,
"CHECK_WIDTH",13,
"CHECK_HEIGHT",13,
"ICON_WIDTH",128,
"ICON_HEIGHT",128);
});
