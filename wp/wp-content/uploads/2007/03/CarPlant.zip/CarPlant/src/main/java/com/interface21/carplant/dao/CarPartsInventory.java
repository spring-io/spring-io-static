package com.interface21.carplant.dao;

import java.util.List;

import com.interface21.carplant.domain.CarModel;
import com.interface21.carplant.domain.Part;

public interface CarPartsInventory {
	
	public List<Part> getPartsForModel(CarModel defaultCarModel);
	
	public void updatePartStock(String partNo, int i);
	
	public void addPart(String model, String number, String name);

}