package com.interface21.carplant.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import com.interface21.carplant.domain.CarModel;
import com.interface21.carplant.domain.Part;
import com.interface21.carplant.logic.PartOutOfStockException;

public class CarPartsInventoryImpl implements CarPartsInventory {
	
	private SimpleJdbcTemplate template;
	
	private ParameterizedRowMapper<Part> partMapper = new ParameterizedRowMapper<Part>() {
		public Part mapRow(ResultSet rs, int rowNum) throws SQLException {
			Part p = new Part();
			p.setPartNo(rs.getString("NUMBER"));
			p.setName(rs.getString("NAME"));
			p.setModel(rs.getString("MODEL"));
			return p;
		}
	};
	
	@Required
	public void setDataSource(DataSource ds) {
		template = new SimpleJdbcTemplate(ds);
	}
	
	public List<Part> getPartsForModel(CarModel model) {
		return template.query(
				"select * from t_car_part where model=?",
				partMapper, new Object[] { model.getName() });
	}
	
	public void updatePartStock(String partNo, int i) {
		int currentStock = template.queryForInt("select stock from t_car_part where number=?", new Object[] { partNo });
		if (currentStock < -i) {
			throw new PartOutOfStockException();
		}
		
		int newStock = currentStock + i;
		
		template.update("update t_car_part set STOCK = ? where NUMBER = ?", new Object[] { newStock, partNo });
	}
	
	public void addPart(String model, String number, String name) {
		template.update("insert into t_car_part values (?,?,?,?)", new Object[] { name, number, model , 0});
	}


	

}
