package com.interface21.carplant.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.interface21.carplant.domain.CarModel;
import com.interface21.carplant.domain.Part;

@Repository
public class PlainHibernateCarPartsInventoryImpl extends CarPartsInventoryImpl {
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public void addPart(String model, String number, String name) {
		Part part = new Part();
		part.setModel(model);
		part.setPartNo(number);
		part.setName(name);
		sessionFactory.getCurrentSession().saveOrUpdate(part);
	}
	
	@SuppressWarnings("unchecked")
	public List<Part> getPartsForModel(CarModel model) {
		return (List<Part>)sessionFactory.getCurrentSession().createQuery("from Part p where p.model = ?").setString(0, model.getName()).list();
	}
	
}
