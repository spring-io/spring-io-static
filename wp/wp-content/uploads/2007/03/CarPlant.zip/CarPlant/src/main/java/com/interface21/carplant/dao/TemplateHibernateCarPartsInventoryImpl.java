package com.interface21.carplant.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.interface21.carplant.domain.CarModel;
import com.interface21.carplant.domain.Part;

public class TemplateHibernateCarPartsInventoryImpl extends CarPartsInventoryImpl {
	
	private HibernateTemplate hibernateTemplate;
	
	@Required
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
	}
	
	public void addPart(String model, String number, String name) {
		Part part = new Part();
		part.setName(name);
		part.setPartNo(number);
		part.setModel(model);
		hibernateTemplate.saveOrUpdate(part);
	}
	
	@SuppressWarnings("unchecked")
	public List<Part> getPartsForModel(CarModel carModel) {
		return (List<Part>)hibernateTemplate.find("from Part where model = ?", new Object[] { carModel.getName() });
	}

}
