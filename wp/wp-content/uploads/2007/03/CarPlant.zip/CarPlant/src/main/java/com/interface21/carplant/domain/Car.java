package com.interface21.carplant.domain;

public class Car {
	
	private CarModel modelName;
	
	public void setModelName(CarModel modelName) {
		this.modelName = modelName;
	}
	
	public CarModel getModelName() {
		return modelName;
	}

}
