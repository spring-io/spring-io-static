package com.interface21.carplant.domain;

import java.beans.PropertyEditorSupport;



public class CarModelEditor extends PropertyEditorSupport {
	
	public void setAsText(String text) throws IllegalArgumentException {
		CarModel model = new CarModel();
		model.setName(text);
		setValue(model);
	}

}
