package com.interface21.carplant.domain;

public class Part {
	
	private String partNo;
	private String name;
	private String model;

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}
	
	public String getPartNo() {
		return partNo;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

}
