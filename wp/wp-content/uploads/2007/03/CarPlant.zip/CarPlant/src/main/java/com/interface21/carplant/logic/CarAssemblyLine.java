package com.interface21.carplant.logic;

import java.util.List;

import com.interface21.carplant.domain.Car;
import com.interface21.carplant.domain.CarModel;
import com.interface21.carplant.domain.Part;

public class CarAssemblyLine {
	
	private boolean onStrike;

	public CarAssemblyLine() {
	}
	
	public void setOnStrike(boolean onStrike) {
		this.onStrike = onStrike;
	}
	
	public Car buildCarFromParts(CarModel model, List<Part> parts) 
	throws OnStrikeException {
		if (onStrike) {
			throw new OnStrikeException();
		} else {
			return new Car();
		}
	}

}
