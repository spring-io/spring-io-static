package com.interface21.carplant.logic;

import com.interface21.carplant.domain.Car;
import com.interface21.carplant.domain.CarModel;

/**
 * Interface for the car plant functionality.
 * @author Alef Arendsen
 */
public interface CarPlant {
	
	/**
	 * Manufactures a car, given the car model.
	 */
	public Car manufactureCar(CarModel model);

}
