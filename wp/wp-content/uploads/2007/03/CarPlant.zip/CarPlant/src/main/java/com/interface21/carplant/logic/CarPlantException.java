package com.interface21.carplant.logic;

public class CarPlantException extends RuntimeException {

}
