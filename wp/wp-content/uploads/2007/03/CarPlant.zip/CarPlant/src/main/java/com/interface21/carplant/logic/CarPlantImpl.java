package com.interface21.carplant.logic;

import java.util.Iterator;
import java.util.List;

import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.interface21.carplant.dao.CarPartsInventory;
import com.interface21.carplant.domain.Car;
import com.interface21.carplant.domain.CarModel;
import com.interface21.carplant.domain.Part;
import com.interface21.util.NotNull;

/**
 * Implementation of the {@link CarPlant CarPlant interface}.
 * Uses transactional annotations to ensure transaction boundaries
 * are set. Internally uses a inventory to get car part to create
 * a car and an assembly line to actually manufacture the car.
 * 
 * @author Alef Arendsen
 */
@Transactional
public class CarPlantImpl implements CarPlant {
	
	private CarPartsInventory inventory;
	private CarAssemblyLine assemblyLine;
	private CarModel defaultCarModel;
	
	public CarPlantImpl() {
	}
	
	public void setAssemblyLine(CarAssemblyLine assemblyLine) {
		this.assemblyLine = assemblyLine;
	}
	
	public void setDefaultCarModel(CarModel defaultCarModel) {
		this.defaultCarModel = defaultCarModel;
	}

	public void setInventory(CarPartsInventory inventory) {
		this.inventory = inventory;
	}

	public void check() {
		if (this.inventory == null) {
			throw new IllegalArgumentException("Inventory should not be null");
		}
		Assert.notNull(defaultCarModel);
	}
	
	
	@NotNull
	public Car manufactureCar(CarModel model) { 
		// when not using the NotNull annotion (disable the advice in applicationContext.xml)
		// null models will trigger the defaultCarModel to be manufactured
		if (model == null) {
			model = defaultCarModel;
		}
		try {
			List<Part> parts = inventory.getPartsForModel(model);
			
			if (parts == null) {
				throw new IllegalArgumentException("Cannot manufacture car with null parts");
			}
			
			Iterator it = parts.iterator();
			while (it.hasNext()) {
				Part part = (Part) it.next();
				inventory.updatePartStock(part.getPartNo(), -1);
			}
			
			Car car = assemblyLine.buildCarFromParts(model, parts);
			
			car.setModelName(model);
			return car;
		} catch (CannotGetJdbcConnectionException e) {
			throw new CannotBuildCarException();
		}
	}
}
