package com.interface21.carplant.logic;

public class NoPartsAvailableForModelException extends CarPlantException {

}
