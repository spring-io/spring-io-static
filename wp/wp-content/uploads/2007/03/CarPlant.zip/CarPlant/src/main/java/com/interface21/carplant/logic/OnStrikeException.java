package com.interface21.carplant.logic;

public class OnStrikeException extends CarPlantException {

}
