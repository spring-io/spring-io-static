package com.interface21.carplant.logic;

public class PartOutOfStockException extends CarPlantException {

}
