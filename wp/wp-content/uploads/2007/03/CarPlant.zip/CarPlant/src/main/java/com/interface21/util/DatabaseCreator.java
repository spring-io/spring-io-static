package com.interface21.util;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.interface21.carplant.dao.CarPartsInventoryImpl;

public class DatabaseCreator {
	
	private DataSource ds;
	JdbcTemplate template;
	
	private static final String DDL = 
			"create table T_CAR_PART (" +
			"    NAME VARCHAR(32)," +
			"    NUMBER VARCHAR(32) NOT NULL PRIMARY KEY," +
			"    MODEL VARCHAR(32)," +
			"    STOCK INTEGER)";
	
	public void setDataSource(DataSource ds) {
		this.ds = ds;
		this.template = new JdbcTemplate(ds);
	}
	

	public void drop() {
		try {
			template.update("drop table t_car_part");
		} catch (Exception e) {
			// okay!
		}
	}

	public void create() {
		template.update(DDL);
		CarPartsInventoryImpl impl = new CarPartsInventoryImpl();
		impl.setDataSource(ds);
		impl.addPart("Bratant", "GTYUI-6789", "Bolt");
	}
	
	
}
