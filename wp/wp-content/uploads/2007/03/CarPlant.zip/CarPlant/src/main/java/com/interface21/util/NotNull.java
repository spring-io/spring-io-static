package com.interface21.util;

public @interface NotNull {

}
