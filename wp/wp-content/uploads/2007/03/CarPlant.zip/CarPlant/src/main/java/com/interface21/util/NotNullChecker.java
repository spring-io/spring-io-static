package com.interface21.util;

import org.aspectj.lang.JoinPoint;

public class NotNullChecker {
	
	public void checkForNull(JoinPoint jp) {
		Object[] args = jp.getArgs();
		
		for (int i = 0; i < args.length; i++) {
			if (args[i] == null) {
				throw new IllegalArgumentException("Argument at position " + (i + 1) + " is null");
			}
		}
	}

}
