package com.interface21.carplant.dao;

import java.util.List;

import com.interface21.carplant.domain.CarModel;
import com.interface21.carplant.domain.Part;
import com.interface21.util.AbstractDatabaseTest;

public abstract class CarPartsInventoryTest extends AbstractDatabaseTest {
	
	@Override
	protected String[] getConfigLocations() {
		return new String[] { "applicationContext.xml" };
	}
	
	protected abstract CarPartsInventory getCarPartsInventory();
	
	protected abstract void flush();
	
	public void testAddPart() {
		int oldCount = countParts();		
		getCarPartsInventory().addPart("SuperHummer", "GTYUI-1234788", "Nut");
		flush();
		assertEquals(oldCount + 1, countParts());
		assertEquals("Nut", jdbcTemplate.queryForObject("select name from t_car_part where number = ?", new Object[] { "GTYUI-1234788" }, String.class));
		assertEquals(0, jdbcTemplate.queryForInt("select stock from t_car_part where number = ?", new Object[] { "GTYUI-1234788" }));
	}
	
	public void testUpdateStock() {	
		getCarPartsInventory().addPart("SuperHummer", "GTYUI-1234", "Nut");
		flush();
		getCarPartsInventory().updatePartStock("GTYUI-1234", 10);
		flush();
		assertEquals(10, jdbcTemplate.queryForInt("select stock from t_car_part where number = ?", new Object[] { "GTYUI-1234" }));
	}
	
	public void testGetPartsForModel() {
		getCarPartsInventory().addPart("SuperHummer1234", "GTYUI-1238", "Nut");
		getCarPartsInventory().addPart("SuperHummer1234", "GTYUI-1239", "Bolt");
		getCarPartsInventory().addPart("MiniHummer", "GTYUI-1237", "Bolt");
		flush();
		
		CarModel model = new CarModel();
		model.setName("SuperHummer1234");
		List<Part> parts = getCarPartsInventory().getPartsForModel(model);
		
		assertEquals(2, parts.size());
		// both need to be super hummer parts
		Part p = parts.get(0);
		assertEquals("SuperHummer1234", p.getModel());
		p = parts.get(1);
		assertEquals("SuperHummer1234", p.getModel());
	}
	
	private int countParts() {
		return jdbcTemplate.queryForInt("select count(*) from t_car_part");
	}

}
