package com.interface21.carplant.dao;

import javax.sql.DataSource;

public class JdbcCarPartsInventoryTest extends CarPartsInventoryTest {
	
	protected CarPartsInventory getCarPartsInventory() {
		DataSource ds = (DataSource)applicationContext.getBean("dataSource");
		
		CarPartsInventoryImpl impl = new CarPartsInventoryImpl();
		impl.setDataSource(ds);
		
		return impl;
	}
	
	protected void flush() {
	}

}
