package com.interface21.carplant.dao;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;

public class PlainHibernateCarPartsInventoryTest extends CarPartsInventoryTest {
	
	private SessionFactory sessionFactory;
	
	protected CarPartsInventory getCarPartsInventory() {
		SessionFactory factory = (SessionFactory)applicationContext.getBean("sessionFactory");
		DataSource ds = (DataSource)applicationContext.getBean("dataSource");
		
		sessionFactory = factory; 
		
		PlainHibernateCarPartsInventoryImpl impl = new PlainHibernateCarPartsInventoryImpl();
		impl.setDataSource(ds);
		impl.setSessionFactory(factory);
		
		return impl;
	}
	
	@Override
	protected void flush() {
		sessionFactory.getCurrentSession().flush();
	}

}
