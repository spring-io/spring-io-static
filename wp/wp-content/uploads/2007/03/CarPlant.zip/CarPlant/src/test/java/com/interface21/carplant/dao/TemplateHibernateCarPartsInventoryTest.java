package com.interface21.carplant.dao;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class TemplateHibernateCarPartsInventoryTest extends CarPartsInventoryTest {
	
	private HibernateTemplate template;
	
	protected CarPartsInventory getCarPartsInventory() {
		SessionFactory factory = (SessionFactory)applicationContext.getBean("sessionFactory");
		DataSource ds = (DataSource)applicationContext.getBean("dataSource");
		
		template = new HibernateTemplate(factory);
		
		TemplateHibernateCarPartsInventoryImpl impl = new TemplateHibernateCarPartsInventoryImpl();
		impl.setDataSource(ds);
		impl.setSessionFactory(factory);
		
		return impl;
	}
	
	@Override
	protected void flush() {
		template.flush();
	}

}
