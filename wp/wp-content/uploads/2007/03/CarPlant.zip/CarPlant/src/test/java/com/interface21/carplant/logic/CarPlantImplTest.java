package com.interface21.carplant.logic;

import static org.easymock.classextension.EasyMock.*;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.interface21.carplant.dao.CarPartsInventory;
import com.interface21.carplant.domain.Car;
import com.interface21.carplant.domain.CarModel;
import com.interface21.carplant.domain.Part;

public class CarPlantImplTest extends TestCase {
	
	private CarPartsInventory carInventory;
	private CarAssemblyLine assemblyLine;
	private CarPlantImpl carPlant;
	
	public void setUp() {
		carInventory = createMock(CarPartsInventory.class);
		assemblyLine = createMock(CarAssemblyLine.class);
		carPlant = new CarPlantImpl();
		carPlant.setInventory(carInventory);
		carPlant.setAssemblyLine(assemblyLine);
	}
	
	public void testPassThroughCorrectModel() {
		
		CarModel model = new CarModel();
		model.setName("SuperBummer");
		
		List<Part> parts = new ArrayList<Part>();
		
		expect(carInventory.getPartsForModel(model)).andReturn(parts);
		expect(assemblyLine.buildCarFromParts(model, parts)).andReturn(new Car());
		
		replay(carInventory);
		replay(assemblyLine);
		
		carPlant.manufactureCar(model);
	}
	
	public void testUpdateStock() {
		CarModel model = new CarModel();
		model.setName("SuperBummer");
		
		
		List<Part> parts = new ArrayList<Part>();
		Part nut = new Part();
		nut.setModel("SuperBummer");
		nut.setName("Nut");
		nut.setPartNo("RTYU-1234");
		
		Part bolt = new Part();
		bolt.setModel("SuperBummer");
		nut.setName("Bolt");
		nut.setPartNo("RTYU-1235");
		
		parts.add(nut);
		parts.add(bolt);
		
		expect(carInventory.getPartsForModel(model)).andReturn(parts);
		carInventory.updatePartStock(nut.getPartNo(), -1);
		carInventory.updatePartStock(bolt.getPartNo(), -1);
		
		expect(assemblyLine.buildCarFromParts(model, parts)).andReturn(new Car());
		
		replay(carInventory);
		replay(assemblyLine);
	}
	
	public void testNullModel() {
		
		try {
			carPlant.manufactureCar(null);
			fail("Exception should have been thrown");
		} catch (IllegalArgumentException e) {
			// okay!
		}
		
	}
}
