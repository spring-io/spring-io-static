package com.interface21.carplant.logic;

import com.interface21.carplant.domain.Car;
import com.interface21.carplant.domain.CarModel;
import com.interface21.util.AbstractDatabaseTest;

public class CarPlantIntegrationTest extends  AbstractDatabaseTest {
	
	private CarPlant plant;
	
	public void setPlant(CarPlant plant) {
		this.plant = plant;
	}
	
	@Override
	protected String[] getConfigLocations() {
		return new String[] { "applicationContext.xml" };
	}
	
	public void testNullChecking() {
		try {
			plant.manufactureCar(null);
			fail("This is not good!");
		} catch (IllegalArgumentException e) {
			// okay!
		} catch (Exception e) {
			fail("Should have thrown IllegalArgumentException");
		}
	}
	
	public void testManufacture() {
		jdbcTemplate.update("insert into t_car_part (name,number,model,stock) values (?,?,?,?)",
				new Object[] { "Nut", "BNGKH-112233", "MegaHummer", "10"});
		
		CarModel model = new CarModel();
		model.setName("MegaHummer");
		
		Car car = plant.manufactureCar(model);
		assertEquals(model, car.getModelName());
		
		assertEquals(9, jdbcTemplate.queryForInt("select stock from t_car_part where model='MegaHummer'"));
	}
}
