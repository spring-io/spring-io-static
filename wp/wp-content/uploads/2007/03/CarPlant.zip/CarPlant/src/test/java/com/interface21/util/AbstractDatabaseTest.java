package com.interface21.util;

import org.springframework.test.AbstractTransactionalDataSourceSpringContextTests;

public abstract class AbstractDatabaseTest extends AbstractTransactionalDataSourceSpringContextTests {
	
	private DatabaseCreator creator;
	
	public void setCreator(DatabaseCreator creator) {
		this.creator = creator;
	}
	
	@Override
	protected final void onSetUpBeforeTransaction() throws Exception {
		creator.drop();
		creator.create();
		onSetUpAfterDatabaseCreation();
	}
	
	protected void onSetUpAfterDatabaseCreation() throws Exception {
		
	}

}
