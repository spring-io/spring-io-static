package aop;

public interface HelloService {
	String getHelloMessage(String toAddHello);
}
