package aop;

public class HelloServiceImpl implements HelloService {

	public String getHelloMessage(String toAddHello) {
		return "Hello " + toAddHello + "!";
	}

}
