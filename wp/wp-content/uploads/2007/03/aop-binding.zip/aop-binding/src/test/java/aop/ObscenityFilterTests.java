package aop;

import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

public class ObscenityFilterTests extends AbstractDependencyInjectionSpringContextTests {

	private HelloService helloService;

	public void setHelloMessageService(HelloService helloService) {
		this.helloService = helloService;
	}

	@Override
	protected String[] getConfigLocations() {
		return new String[] { "classpath:aop/config.xml" };
	}

	public void testWithObscenity() {
		try {
			helloService.getHelloMessage("Microsoft");
			fail("Should have thrown an exception");
		} catch (IllegalArgumentException ex) {
		}
	}

	public void testWithoutObscenity() {
		assertEquals("Incorrect message returned", "Hello Seattle!", helloService.getHelloMessage("Seattle"));
	}

}
