package org.springframework.test.factory;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.SingletonBeanRegistry;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.support.AbstractRefreshableApplicationContext;
import org.springframework.util.ReflectionUtils;

/**
 * Utility class for wiring a concrete bean instance (the target) from
 * properties of another object (the source). Also calls bean creation callbacks
 * on the target if appropriate - most notably
 * InitializingBean.afterPropertiesSet(). Very useful in test cases where a bean
 * to be tested can be initialised from the test case itself. If the target
 * changes its implementation so that it implements InitializingBean, then the
 * test will automatically upgrade itself to make the callback, as long as it
 * uses the methods provided here to create the bean.
 * 
 * @author Dave Syer
 * 
 */
public class BeanInitializer {

	/**
	 * Autowire target by type. TODO: maybe expose this - and make methods
	 * non-static?
	 */
	private static int autoWire = AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE;

	private BeanInitializer() {
		// no-op
	}

	/**
	 * Initialize the target, with no properties provided to set, but making
	 * lifecycle callbacks if they are defined.
	 * 
	 * @param target the target bean
	 * @return the target after calling bean lifecycle methods
	 * @throws BeansException if afterPropertiesSet throws an Exception
	 */
	public static Object initialize(Object target) throws BeansException {
		initialize(target, null);
		return target;
	}

	/**
	 * Initialize the target with properties provided in the bean factory, and
	 * making lifecycle callbacks if they are defined. The target will be
	 * autowired by type from the provided bean factory, so duplicate properties
	 * with the same type will cause an error. Also note that primitive and
	 * "simple" types (e.g. String) are ignored by the autowiring mechanisms.
	 * Use the setters directly for these properties.
	 * @param target the target bean
	 * @param beanFactory a BeanFactory
	 * 
	 * @return the target after calling bean lifecycle methods
	 * @throws BeansException if afterPropertiesSet throws an Exception
	 */
	public static Object initialize(Object target, ListableBeanFactory beanFactory) throws BeansException {
		return initialize(target, null, beanFactory);
	}

	/**
	 * Initialize the target with properties provided in the source, and making
	 * lifecycle callbacks if they are defined. The target will be autowired by
	 * type from the fields of the provided source. Also note that primitive and
	 * "simple" types (e.g. String) are ignored by the autowiring mechanisms.
	 * Use the setters directly for these properties.
	 * 
	 * @param source a source object with properties that can satisfy
	 * dependencies in the target
	 * @param target the target bean
	 * @return the target after calling bean lifecycle methods
	 * @throws BeansException if afterPropertiesSet throws an Exception
	 */
	public static Object initialize(Object target, Object source) throws BeansException {
		return initialize(target, source, null);
	}

	/**
	 * Initialize the target with properties provided in the source and the bean
	 * factory, and making lifecycle callbacks if they are defined. The target
	 * will be autowired by type from the fields of the provided source and
	 * beans in the bean factory. Also note that primitive and "simple" types
	 * (e.g. String) are ignored by the autowiring mechanisms. Use the setters
	 * directly for these properties.
	 * @param target the target bean
	 * @param source a source object with properties that can satisfy
	 * dependencies in the target
	 * @param beanFactory a BeanFactory
	 * 
	 * @return the target after calling bean lifecycle methods
	 * @throws BeansException if afterPropertiesSet throws an Exception
	 */
	public static Object initialize(Object target, Object source, ListableBeanFactory beanFactory) throws BeansException {
		return initialize(target, new Object[] { source }, beanFactory);
	}

	/**
	 * Initialize the target with properties provided in the sources and the bean
	 * factory, and making lifecycle callbacks if they are defined. The target
	 * will be autowired by type from the fields of the provided sources and
	 * beans in the bean factory. Also note that primitive and "simple" types
	 * (e.g. String) are ignored by the autowiring mechanisms. Use the setters
	 * directly for these properties.
	 * @param target the target bean
	 * @param sources an array of source objects with properties that can satisfy
	 * dependencies in the target
	 * @param beanFactory a BeanFactory
	 * 
	 * @return the target after calling bean lifecycle methods
	 * @throws BeansException if afterPropertiesSet throws an Exception
	 */
	public static Object initialize(Object target, Object[] sources, ListableBeanFactory beanFactory) throws BeansException {

		InitializerApplicationContext context = new InitializerApplicationContext(sources);
		context.refresh();
		ConfigurableListableBeanFactory childBeanFactory = context.getBeanFactory();

		mergeBeanFactories(beanFactory, childBeanFactory);
		childBeanFactory.autowireBeanProperties(target, autoWire, false);
		childBeanFactory.initializeBean(target, "bean:" + target.hashCode());

		return target;
	}
	
	static private void mergeBeanFactories(ListableBeanFactory parent, ConfigurableListableBeanFactory child) {
		// Instead of just setting the child parent bean factory
		// we add all the beans from parent to child explicitly, 
		// leaving out any beans where child already has beans of the
		// same type.
		if (parent==null) return;
		String[] names = parent.getBeanDefinitionNames();
		merge(parent, child, names);
		if (parent instanceof SingletonBeanRegistry) {
			names = ((SingletonBeanRegistry)parent).getSingletonNames();
			merge(parent, child, names);
		}
	}
	
	static private void merge(ListableBeanFactory parent, ConfigurableListableBeanFactory child, String[] names) {
		for (int i=0; i<names.length; i++) {
			String name = names[i];
			Class type = parent.getType(name);
			Object bean = parent.getBean(name);
			if (child.getBeanNamesForType(type).length==0) {
				child.registerSingleton(name, bean);
			}
		}
	}

	static class InitializerApplicationContext extends AbstractRefreshableApplicationContext {

		Object[] sources;

		public InitializerApplicationContext(Object[] sources) {
			this.sources = sources;
		}

		protected void loadBeanDefinitions(DefaultListableBeanFactory beanFactory) throws IOException, BeansException {

			// If there is no source then load no beans...
			if (sources == null) {
				return;
			}

			final Map fields = new HashMap();
			for (int i = 0; i < sources.length; i++) {
				final Object source = sources[i];
				if (source==null) {
					continue;
				}
				// Include the bean itself as a singleton
				beanFactory.registerSingleton("source:" + source.hashCode(), source);
				ReflectionUtils.doWithFields(source.getClass(), new ReflectionUtils.FieldCallback() {
					public void doWith(Field field) throws IllegalArgumentException, IllegalAccessException {
						field.setAccessible(true);
						Object value = field.get(source);
						if (value != null) {
							fields.put(field.getName(), value);
						}
					}
				});
			}
			for (Iterator iter = fields.keySet().iterator(); iter.hasNext();) {
				String key = (String) iter.next();
				beanFactory.registerSingleton(key, fields.get(key));
			}
		}

	}

}
