package org.springframework.mock.proxy;

import java.util.List;

import junit.framework.TestCase;

import org.easymock.EasyMock;

public class EasyMockTests extends TestCase {

	public void testRawProxy() throws Exception {
		List list = EasyMock.createNiceMock(List.class);
		EasyMock.expect(list.get(0)).andReturn("foo").anyTimes();
		EasyMock.replay(list);
		assertNotNull(list);
		assertNotNull(list.get(0));
		assertEquals("foo", list.get(0));
	}

}
