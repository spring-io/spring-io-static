package org.springframework.test.factory;

import junit.framework.TestCase;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;

public class BeanInitializerTests extends TestCase {

	int called = 0;

	// Properties with the same type as TestBean
	// (name of property is irrelevant if we are doing
	// autowire by type).
	TestBean bean = new TestBean();

	String eman = "spam";

	public void testBeanWithNoBeanFactory() throws Exception {
		try {
			Object bean = BeanInitializer.initialize("foo");
			assertEquals("foo", bean);
		}
		catch (BeansException e) {
			fail("Unexpected BeansException");
		}
	}

	public void testInitializingBeanWithNoBeanFactory() throws Exception {
		Object bean = BeanInitializer.initialize(new InitializingBean() {
			public void afterPropertiesSet() throws Exception {
				called++;
			}
		});
		assertNotNull(bean);
		assertEquals(1, called);
	}

	public void testInitializingBeanWithBeanFactory() throws Exception {
		DefaultListableBeanFactory beanFactory = new DefaultListableBeanFactory();
		TestBean child = new TestBean();
		beanFactory.registerSingleton("bar", child);
		BeanInitializer.initialize(bean, beanFactory);
		assertEquals(1, called);
		assertEquals(child, bean.child);
	}

	public void testBeanWithSimpleDependency() throws Exception {
		BeanInitializer.initialize(bean, "foo");
		// A String cannot be autowired (see BeanUtils.isSimpleProperty).
		assertEquals(null, bean.name);
		assertEquals(1, called);
	}

	public void testBeanWithSimpleDependencyOnThis() throws Exception {
		BeanInitializer.initialize(bean, this);
		// A String cannot be autowired (see BeanUtils.isSimpleProperty).
		assertEquals(null, bean.name);
		assertEquals(1, called);
	}

	public void testBeanWithDependencyOnThis() throws Exception {
		TestBean test = (TestBean) BeanInitializer.initialize(new TestBean(), this);
		assertEquals(bean, test.child);
		assertEquals(1, called);
	}

	public void testBeanWithDirectDependency() throws Exception {
		TestBean child = new TestBean();
		TestBean test = (TestBean) BeanInitializer.initialize(new TestBean(), child);
		assertEquals(child, test.child);
		assertEquals(1, called);
	}

	public void testBeanWithBeanFactoryAndThis() throws Exception {
		DefaultListableBeanFactory beanFactory = new DefaultListableBeanFactory();
		TestBean child = new TestBean();
		beanFactory.registerSingleton("bar", child);
		TestBean test = (TestBean) BeanInitializer.initialize(new TestBean(), this, beanFactory);
		// Should prefer dependencies satidfied from this (sources)...
		assertEquals(bean, test.child);
		assertNotSame(child, test.child);
		assertEquals(1, called);
	}

	class TestBean implements InitializingBean {
		String name;

		TestBean child;

		public void setChild(TestBean bean) {
			this.child = bean;
		}

		public void setName(String name) {
			this.name = name;
		}

		public void afterPropertiesSet() throws Exception {
			called++;
		}
	}
}
