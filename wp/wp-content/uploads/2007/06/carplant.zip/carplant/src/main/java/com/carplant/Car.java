package com.carplant;

public class Car {

	private CarModel model;
	
	public Car(CarModel model) {
		this.model = model;
	}

	public CarModel getModel() {
		return this.model;
	}

}
