package com.carplant;

import org.hibernate.SessionFactory;
import org.springframework.config.java.annotation.Bean;
import org.springframework.config.java.annotation.Configuration;
import org.springframework.config.java.annotation.ExternalBean;
import org.springframework.jdbc.core.JdbcTemplate;

import com.carplant.assembly.CarAssemblyLine;
import com.carplant.inventory.CarPartsInventory;
import com.carplant.inventory.HibernateCarPartsInventory;
import com.carplant.plant.CarPlant;
import com.carplant.plant.DefaultCarPlant;

/**
 * @author Alef Arendsen 
 */
@Configuration
public abstract class Config {
	
	@Bean public CarPlant carPlant() {
		return new DefaultCarPlant(carPartInventory(), carAssemblyLine());
	}

	@Bean public CarAssemblyLine carAssemblyLine() {
		return new CarAssemblyLine();
	}

	@Bean public CarPartsInventory carPartInventory() {
		return new HibernateCarPartsInventory(jdbcTemplate(), sessionFactory());
	}

	@ExternalBean public abstract SessionFactory sessionFactory();

	@ExternalBean public abstract JdbcTemplate jdbcTemplate();

}
