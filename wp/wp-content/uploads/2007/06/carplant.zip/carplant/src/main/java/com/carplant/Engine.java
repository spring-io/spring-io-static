package com.carplant;

/**
 * @author Alef Arendsen 
 */
public class Engine extends Part {
	
	private int cubicCentimeters;

	public Engine(String partNumber, CarModel carModel, int cubicCentimers) {
		super(partNumber, carModel);
		this.cubicCentimeters = cubicCentimers;
	}
	
	public int getCubicCentimers() {
		return cubicCentimeters;
	}
}
