package com.carplant;

/**
 * @author Alef Arendsen 
 */
@SuppressWarnings("serial")
public class InsufficientPartsInStockException extends RuntimeException {
	
	private String partNo;
		
	public InsufficientPartsInStockException(Part p) {
		this.partNo = p.getPartNumber();
	}
	
	public InsufficientPartsInStockException(String partNo) {
		this.partNo = partNo;
	}

	@Override
	public String getMessage() {
		return "There are not enough parts with number " + partNo;
	}
}
