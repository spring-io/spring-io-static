package com.carplant;

/**
 * @author Alef Arendsen 
 */
public class Windshield extends Part {

	private boolean safetyGlass;

	public Windshield(String partNumber, CarModel carModel, boolean safetyGlass) {
		super(partNumber, carModel);
		this.safetyGlass = safetyGlass;
	}
	
	public boolean isSafetyGlass() {
		return safetyGlass;
	}

}
