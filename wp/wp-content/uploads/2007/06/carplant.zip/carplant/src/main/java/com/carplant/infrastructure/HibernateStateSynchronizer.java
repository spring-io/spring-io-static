package com.carplant.infrastructure;

import org.hibernate.SessionFactory;

/**
 * Capable of flushing the Hibernate session using
 * an instance of the SessionFactory.
 * @author Alef Arendsen
 */
public class HibernateStateSynchronizer {
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/**
	 * Simply calls {@link org.hibernate.Session.flush()} to synchronize
	 * the Hibernate session state with the database.
	 */
	public void flush() {
		sessionFactory.getCurrentSession().flush();
	}
}
