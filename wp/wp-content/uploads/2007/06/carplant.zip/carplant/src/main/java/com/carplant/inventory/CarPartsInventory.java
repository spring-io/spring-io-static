package com.carplant.inventory;

import java.util.List;

import com.carplant.CarModel;
import com.carplant.Part;

/**
 * @author Alef Arendsen 
 */
public interface CarPartsInventory {

	List<Part> getPartsForModel(CarModel model);

	void updatePartStockForPartNumber(Part part, int i);

	void addPart(Part part);

}
