package com.carplant.plant;

import com.carplant.Car;
import com.carplant.CarModel;

/**
 * @author Alef Arendsen 
 */
public interface CarPlant {

	Car manufactureCar(CarModel model);

}