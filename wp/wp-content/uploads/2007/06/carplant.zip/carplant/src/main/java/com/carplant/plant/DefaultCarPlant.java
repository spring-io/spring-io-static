package com.carplant.plant;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.carplant.Car;
import com.carplant.CarModel;
import com.carplant.Part;
import com.carplant.assembly.CarAssemblyLine;
import com.carplant.inventory.CarPartsInventory;

/**
 * @author Alef Arendsen 
 */
@Transactional
@Component
public class DefaultCarPlant implements CarPlant {

	private CarPartsInventory inventory;
	private CarAssemblyLine assemblyLine;
	private Logger log = LogManager.getLogger(DefaultCarPlant.class);
	
	// default constructor for 
	DefaultCarPlant() { }

	@Autowired
	public DefaultCarPlant(CarPartsInventory inventory, CarAssemblyLine assemblyLine) {		
		this.inventory = inventory;
		this.assemblyLine = assemblyLine;
	}

	/* (non-Javadoc)
	 * @see com.carplant.plant.ICarPlant#manufactureCar(com.carplant.CarModel)
	 */
	public Car manufactureCar(CarModel model) {
		if (model == null) {
			throw new IllegalArgumentException("Model should not be null");
		}
		List<Part> parts = inventory.getPartsForModel(model);
		
		for (Part p : parts) {
			log.info("Updating stock for part " +  p.getPartNumber());
			inventory.updatePartStockForPartNumber(p, -1);
		}
		
		return assemblyLine.assembleCarFromParts(model, parts);
	
	}
}
