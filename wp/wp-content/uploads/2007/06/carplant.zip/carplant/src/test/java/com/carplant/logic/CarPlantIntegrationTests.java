package com.carplant.logic;

import org.hibernate.SessionFactory;
import org.springframework.test.AbstractTransactionalDataSourceSpringContextTests;

import com.carplant.Bolt;
import com.carplant.CarModel;
import com.carplant.Engine;
import com.carplant.Windshield;
import com.carplant.inventory.CarPartsInventory;
import com.carplant.plant.CarPlant;

/**
 * @author Alef Arendsen 
 */
public class CarPlantIntegrationTests extends AbstractTransactionalDataSourceSpringContextTests {
	
	private CarPlant carPlant;
	
	private SessionFactory sessionFactory;

	private CarPartsInventory inventory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void setInventory(CarPartsInventory inventory) {
		this.inventory = inventory;
	}
	
	public void setCarPlant(CarPlant carPlant) {
		this.carPlant = carPlant;
	}

	@Override
	protected String[] getConfigLocations() {
		return new String[] { "com/carplant/config.xml", "com/carplant/infrastructure.xml" };
	}

	public void testManufactureCar() {
		
		Bolt bolt24 = new Bolt("JHG-115a", new CarModel("MiniHummer"), 24);
		Bolt bolt22 = new Bolt("JHG-116a", new CarModel("MiniHummer"), 22);
		Bolt bolt17 = new Bolt("JHG-556", new CarModel("MaxiHummer"), 17);
		
		Engine engine1 = new Engine("ERR-90506", new CarModel("MiniHummer"), 700);
		Engine engine2 = new Engine("ERR-90507", new CarModel("MiniHummer"), 4200);
		
		Windshield wsNonSafe = new Windshield("WSH-4445", new CarModel("MiniHummer"), false);
		Windshield wsSafe = new Windshield("WSH-4447", new CarModel("MaxiHummer"), true);
		
		inventory.addPart(bolt24);		
		inventory.addPart(bolt22);
		inventory.addPart(bolt17);
		
		inventory.addPart(engine1);
		inventory.addPart(engine2);
		
		inventory.addPart(wsNonSafe);
		inventory.addPart(wsSafe);
		
		sessionFactory.getCurrentSession().flush();
		
		inventory.updatePartStockForPartNumber(bolt24, 10);		
		inventory.updatePartStockForPartNumber(bolt22, 10);
		inventory.updatePartStockForPartNumber(bolt17, 10);
		
		inventory.updatePartStockForPartNumber(engine1, 10);
		inventory.updatePartStockForPartNumber(engine2, 10);
		
		inventory.updatePartStockForPartNumber(wsNonSafe, 10);
		inventory.updatePartStockForPartNumber(wsSafe, 10);
		
		
		carPlant.manufactureCar(new CarModel("MiniHummer"));
		
		// count parts for MiniHummer
		assertEquals(9, countStock(bolt24.getPartNumber()));
		assertEquals(9, countStock(bolt22.getPartNumber()));
		// count parts for MaxiHummer
		assertEquals(10, countStock(bolt17.getPartNumber()));
		
		
	}
	
	private int countStock(String partNo) {
		return jdbcTemplate.queryForInt("select stock from t_part where part_number = ?", new Object[] {partNo});
	}

}
