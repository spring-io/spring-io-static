package com.carplant.logic;

import static org.easymock.EasyMock.*;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.carplant.Bolt;
import com.carplant.Car;
import com.carplant.CarModel;
import com.carplant.InsufficientPartsInStockException;
import com.carplant.Part;
import com.carplant.assembly.CarAssemblyLine;
import com.carplant.inventory.CarPartsInventory;
import com.carplant.plant.DefaultCarPlant;
import com.carplant.plant.CarPlant;

/**
 * @author Alef Arendsen 
 */
public class CarPlantTests extends TestCase {
	
	private CarPlant plant;
	private CarPartsInventory inventory;

	@Override
	protected void setUp() throws Exception {
		this.inventory = createMock(CarPartsInventory.class);
		this.plant = new DefaultCarPlant(inventory, new CarAssemblyLine());
	}
	
	/**
	 * CarPlants should be able to manufacture cars after having 
	 * successfully manufactured a car, for each part that is needed
	 * for the model that has just been manufactures, the plant
	 * should first have queried and updated an inventory before
	 * actually manufacturing the car.
	 */
	public void testCorrectlyUpdatingStock() {
		CarModel model = new CarModel("MiniHummer");
		
		// the list of parts to create a car with
		ArrayList<Part> parts = new ArrayList<Part>();
		Bolt bolt = new Bolt("FGH-0987", new CarModel("MiniHummer"), 24);
		parts.add(bolt);
		// the list shoul be retrieved from the inventory
		expect(inventory.getPartsForModel(model)).andReturn(parts);
		// and for each of the parts, the stock should be updated
		inventory.updatePartStockForPartNumber(bolt, -1);
		
		// start test scenario
		replay(inventory);
		
		// the car plant should not return null
		Car car = plant.manufactureCar(model);
		assertNotNull(car);
		
		assertEquals(model.getName(), car.getModel().getName());
	}
	
	/**
	 * CarPlants should not manufacture cars in case no car model
	 * was given. An IllegalArgumentException should be thrown
	 */
	public void testNullCarModel() {
		try {
			plant.manufactureCar(null);
			// this is wrong
			fail("An exception should have been thrown because of a null car model");
		} catch (IllegalArgumentException e) {
			// this okay
		}
	}
	
	/**
	 * CarPlants should not manufacture cars in case of a lack of
	 * parts for the given car model. An InsufficientPartsInStockException
	 * should be thrown
	 */
	public void testInsufficientParts() {
		CarModel model = new CarModel("MiniHummer");
		Part bolt = new Bolt("GJH-1234", new CarModel("MiniHummer"), 24);
		List<Part> parts = new ArrayList<Part>();
		parts.add(bolt);
		InsufficientPartsInStockException ipise = new InsufficientPartsInStockException(bolt);
		expect(inventory.getPartsForModel(model)).andReturn(parts);
		inventory.updatePartStockForPartNumber(bolt, -1);
		expectLastCall().andThrow(ipise);
		
		replay(inventory);
		
		try {
			plant.manufactureCar(model);
			// this is wrong
			fail("An exception should have been thrown because the parts are not available");
		} catch (InsufficientPartsInStockException e) {
			// this is okay!
		}
	}

}
