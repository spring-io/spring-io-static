drop table T_PART if exists;

create table T_PART (
	NUMBER varchar(64) primary key,
);