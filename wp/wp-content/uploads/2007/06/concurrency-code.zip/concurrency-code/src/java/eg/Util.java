package eg;

/**
 * @author Rob Harrop
 */
public class Util {
    public static void sleepFor(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
