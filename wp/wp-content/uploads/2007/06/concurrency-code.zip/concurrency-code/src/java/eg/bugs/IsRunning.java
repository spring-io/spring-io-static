package eg.bugs;

import static eg.Util.sleepFor;

/**
 * @author Rob Harrop
 */
public class IsRunning {

    public static void main(String[] args) {
        Task task = new Task();
        Thread thread = new Thread(task);
        thread.start();
        sleepFor(4000);
        task.stop();

    }

    private static class Task implements Runnable {
        private boolean running;

        public void run() {
            this.running = true;

            while (this.running) {
                doWork();
            }
            System.out.println("Done");
        }

        private void doWork() {
            System.out.println("Work");
            sleepFor(1000);
        }

        public void stop() {
            this.running = false;
        }
    }
}
