package eg.bugs;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Rob Harrop
 */
public class MisMatchedMonitors {

    private static class Cache {
        private final Map<String, Object> cache = new HashMap<String, Object>();
        private final Object readLock = new Object();
        private final Object writeLock = new Object();

        public void put(String key, Object value) {
            synchronized (this.writeLock) {
                this.cache.put(key, value);
            }
        }

        public Object get(String key) {
            synchronized (this.readLock) {
                return this.cache.get(key);
            }
        }
    }
}
