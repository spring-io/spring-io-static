package eg.bugs;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Rob Harrop
 */
public class OneSidedLocking {

    private static class Cache {
        private final Map<String, Object> cache = new HashMap<String, Object>();

        public void put(String key, Object value) {
            synchronized (this.cache) {
                this.cache.put(key, value);
            }
        }

        public Object get(String key) {
            return this.cache.get(key);
        }
    }
}
