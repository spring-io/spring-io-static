package eg.bugs;

import eg.Util;
import static eg.Util.*;

/**
 * @author Rob Harrop
 */
public class UseThreadGroup {

    public static void main(String[] args) {
        final int taskCount = 10;
        ThreadGroup tg = new ThreadGroup("foo");

        for (int x = 0; x < taskCount; x++) {
            Thread t = new Thread(tg, new TaskRunnable(x));
            t.start();
        }

        while (tg.activeCount() > 0) {
            sleepFor(1000);
        }

        System.out.println("Done");

    }

    private static class TaskRunnable implements Runnable {
        public TaskRunnable(int count) {
            this.count = count;
        }

        private final int count;

        public void run() {
            System.out.println(this.count);
            /*Thread t = new Thread(new Runnable() {
                public void run() {
                    while (true) {
                        sleepFor(3000);
                    }
                }
            });
            t.start();*/
        }
    }
}
