package eg.pnc;

/**
 * @author Rob Harrop
 */
public class Factorial {
    private final int n;
    private final long factorial;

    public Factorial(int n, long factorial) {
        this.n = n;
        this.factorial = factorial;
    }

    @Override
    public String toString() {
        return String.format("%d = %d", this.n, this.factorial);
    }
}
