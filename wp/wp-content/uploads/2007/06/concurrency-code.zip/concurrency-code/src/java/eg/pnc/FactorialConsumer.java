package eg.pnc;

import java.util.concurrent.BlockingQueue;

/**
 * @author Rob Harrop
 */
public class FactorialConsumer implements Runnable {

    private final BlockingQueue<Integer> queue;

    public FactorialConsumer(BlockingQueue<Integer> queue) {
        this.queue = queue;
    }

    public void run() {
        while (true) {
            try {
                Integer i = this.queue.take();
                System.out.println(i + " = " +factorial(i));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public long factorial(int n) {
        if (n < 0) {
            throw new RuntimeException("Underflow error in factorial");
        } else if (n > 20) {
            throw new RuntimeException("Overflow error in factorial");
        } else if (n == 0) {
            return 1;
        } else {
            return n * factorial(n - 1);
        }
    }
}
