package eg.pnc;

import java.util.concurrent.*;

/**
 * @author Rob Harrop
 */
public class Main {

    public static void main(String[] args) throws InterruptedException {
        BlockingQueue<Integer> queue = new LinkedBlockingQueue<Integer>(10);
        int threads = 3;
        Executor e = Executors.newFixedThreadPool(threads);
        for(int x = 0; x < threads; x++) {
            e.execute(new FactorialConsumer(queue));
        }

        for(int x = 0; x < 15; x++) {
            queue.offer(x, 10L, TimeUnit.SECONDS);
        }
    }
}
