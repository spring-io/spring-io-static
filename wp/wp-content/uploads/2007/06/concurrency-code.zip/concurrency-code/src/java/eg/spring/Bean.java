package eg.spring;

/**
 * @author Rob Harrop
 */
public class Bean {

    private int count = 100;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
