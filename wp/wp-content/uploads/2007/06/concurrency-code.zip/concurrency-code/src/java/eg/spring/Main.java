package eg.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Rob Harrop
 */
public class Main {
    static volatile ApplicationContext ctx;

    public static void main(String[] args) {
        Thread thread1 = new Thread(new Runnable() {
            public void run() {
                ctx = new ClassPathXmlApplicationContext("eg/spring/config.xml");
            }
        });

        thread1.start();
        Thread thread2 = new Thread(new Runnable() {
            public void run() {
                while (ctx == null) {

                }
                Bean bean = (Bean) ctx.getBean("bean");
                System.out.println(bean.getCount());
            }
        });
        thread2.start();
    }
}
