require 'java'

include_class 'org.springframework.web.servlet.ModelAndView'

class HelloController < org.springframework.web.servlet.mvc.Controller

    def handleRequest(request, response)
        writer = response.getWriter
        writer.write("Hello Manchester!")
        return
    end

end