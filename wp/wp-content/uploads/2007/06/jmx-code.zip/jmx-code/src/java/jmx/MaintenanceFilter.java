package jmx;

import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Rob Harrop
 */
public class MaintenanceFilter extends OncePerRequestFilter {

    private volatile boolean maintenanceMode;

    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        if (this.maintenanceMode) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/maintenance.jsp");
            dispatcher.forward(request, response);
        } else {
            filterChain.doFilter(request, response);
        }
    }

    public boolean isMaintenanceMode() {
        return maintenanceMode;
    }

    public void switchMode() {
        this.maintenanceMode = !this.maintenanceMode;
    }
}
