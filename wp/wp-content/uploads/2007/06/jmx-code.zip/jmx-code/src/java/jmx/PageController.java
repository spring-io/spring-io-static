package jmx;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Rob Harrop
 */
public class PageController extends MultiActionController {

    public ModelAndView hello(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String message = "Hello!";
        return createModelAndView(message);
    }

    public ModelAndView goodbye(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String message = "Goodbye!";
        return createModelAndView(message);
    }

    private ModelAndView createModelAndView(String message) {
        return new ModelAndView("message", "message", message);
    }
}
