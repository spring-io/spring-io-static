package jmx;

import org.springframework.jmx.export.notification.NotificationPublisher;
import org.springframework.jmx.export.notification.NotificationPublisherAware;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.management.Notification;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @author Rob Harrop
 */
public class StatisticsFilter extends OncePerRequestFilter implements NotificationPublisherAware, StatisticsFilterMXBean {

    private final AtomicLong requestCount = new AtomicLong();

    private final Map<String, AtomicLong> requestStatistics = new HashMap<String, AtomicLong>();

    private NotificationPublisher notificationPublisher;

    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        long count = this.requestCount.getAndIncrement();

        if (this.notificationPublisher != null) {
            Notification notification = new Notification("request.proceesed", this, count, request.getRequestURI());
            this.notificationPublisher.sendNotification(notification);
        }

        recordRequest(request);

        filterChain.doFilter(request, response);
    }

    private void recordRequest(HttpServletRequest request) {
        synchronized (this.requestStatistics) {
            String key = request.getRequestURI();
            AtomicLong value = this.requestStatistics.get(key);
            if (value == null) {
                value = new AtomicLong();
                this.requestStatistics.put(key, value);
            }
            value.incrementAndGet();
        }
    }

    public long getRequestCount() {
        return this.requestCount.longValue();
    }

    public void setNotificationPublisher(NotificationPublisher notificationPublisher) {
        this.notificationPublisher = notificationPublisher;
    }


    public Map<String, Long> getRequestStatistics() {
        Map<String, Long> result = new HashMap<String, Long>();
        synchronized (this.requestStatistics) {
            for (String uri : this.requestStatistics.keySet()) {
                result.put(uri, this.requestStatistics.get(uri).longValue());
            }
        }
        return Collections.unmodifiableMap(result);
    }
}
