package jmx;

import java.util.Map;

/**
 * @author Rob Harrop
 */
public interface StatisticsFilterMXBean {

    long getRequestCount();

    Map<String, Long> getRequestStatistics();
}
