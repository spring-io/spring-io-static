package com.interface21.sample.environment.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.interface21.sample.environment.service.SampleService;

/**
 * Servlet implementation class for Servlet: Servlet
 *
 */
 public class Servlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(this.getServletContext());
		SampleService service = (SampleService) ctx.getBean("sampleService");
		
		response.getWriter().println(
			    "Last name for Alef: " + service.getLastName("Alef") 
		  + "<br>Last name for Joris: " + service.getLastName("Joris")
		  + "<br>Last name for Arjen: " + service.getLastName("Arjen"));
	}
	
}