package com.interface21.sample.environment.dao;

import java.util.Properties;

import com.interface21.sample.environment.domain.Person;

public class DefaultSampleDao implements SampleDao {
	
	private Properties names;
	
	public Properties getNames() {
		return names;
	}
	
	public void setNames(Properties names) {
		this.names = names;
	}

	public Person findPersonByFirstName(String firstName) {
		return new Person(firstName, names.getProperty(firstName));
	}

}
