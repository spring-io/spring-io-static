package com.interface21.sample.environment.dao;

import com.interface21.sample.environment.domain.Person;

public interface SampleDao {

	Person findPersonByFirstName(String firstName);

}
