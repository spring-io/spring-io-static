package com.interface21.sample.environment.dao;

import com.interface21.sample.environment.domain.Person;

public class StaticSampleDao implements SampleDao {

	public Person findPersonByFirstName(String firstName) {
		return new Person("John", "Doe");
	}

}
