package com.interface21.sample.environment.service;

import com.interface21.sample.environment.dao.SampleDao;

public class DefaultSampleService implements SampleService {

	private SampleDao dao;
	
	public void setDao(SampleDao dao) {
		this.dao = dao;
	}
	
	public String getLastName(String firstName) {
		return dao.findPersonByFirstName(firstName).getLastName();
	}

}
