package com.interface21.sample.environment.service;

public interface SampleService {
	public String getLastName(String firstName);
}
