package com.interface21.sample.environment.util;

public class EnvironmentUtils {
	
	public static String[] getConfigLocations() {
		return new String[] {
			// our regular application context files
			"classpath:/base/*.xml",
			// our env. specific context files
			"classpath:/env/" + getEnvironment() + "/*.xml"
		};
	}
	
	public static Environment getEnvironment() {
		String envValue = System.getProperty("app.env");
		// alternatives: JNDI lookup, DB query, etc.
		Environment env = Environment.valueOf(envValue);
		System.out.println("We're running in environment " 
			+ env.getDescription());
		return env;
	}
}
