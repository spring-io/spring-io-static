package xml;
import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

import com.interface21.sample.environment.service.SampleService;
import com.interface21.sample.environment.util.EnvironmentUtils;


public abstract class AbstractIntegrationTest extends AbstractDependencyInjectionSpringContextTests {
	
	protected SampleService service;
	
	public void setSampleService(SampleService service) {
		this.service = service;
	}
	
	@Override
	protected String[] getConfigLocations() {
		System.setProperty("app.env", getEnvLetter());
		return EnvironmentUtils.getConfigLocations();
	}
	
	protected abstract String getEnvLetter();
}
