package com.interface21.sample.multiplecontexts.service;

public interface SampleService {
	String sayHello(String from);
}
