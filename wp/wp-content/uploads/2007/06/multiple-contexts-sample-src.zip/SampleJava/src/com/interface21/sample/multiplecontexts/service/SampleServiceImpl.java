package com.interface21.sample.multiplecontexts.service;

public class SampleServiceImpl implements SampleService {

	public String sayHello(String from) {
		return "Hello from " + from;
	}

}
