class ApplicationBootStrap {

     def init = { servletContext ->
     }
     def destroy = {
     }
} 