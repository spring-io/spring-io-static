package test;

import grails.spring.BeanBuilder;
import groovy.lang.Closure;
import groovy.lang.GroovyObject;
import groovy.lang.Script;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.scripting.groovy.GroovyObjectCustomizer;

/*
 * Copyright 2006-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @author Dave Syer
 * 
 */
public class BeanBuilderClosureCustomizer implements GroovyObjectCustomizer,
		ApplicationContextAware {

	def ApplicationContext applicationContext;

	/**
	 * Try to convert the GroovyObject into an ApplicationContext and load the
	 * bean definitions into the parent context.
	 * @see org.springframework.scripting.groovy.GroovyObjectCustomizer#customize(groovy.lang.GroovyObject)
	 */
	public void customize(GroovyObject goo) {
		if (!(goo instanceof Script)) {
			// TODO: add some indicator of the bean that is in error here...
			throw new BeanCreationException("Cannot configure application context from a bean - use a script in the form beans = {...}");
		}
		def value = goo.run();
		if (!(value instanceof Closure)) {
			// TODO: add some indicator of the bean that is in error here...
			throw new BeanCreationException("Cannot configure application context from a non-closure (found ...) - use a script in the form beans = {...}");
		}
		addBeanDefinitions(createApplicationContext(value))
	}
	
	private ApplicationContext createApplicationContext(Closure value) {
		BeanBuilder builder = new BeanBuilder(applicationContext)
		builder.beans(value)
		builder.createApplicationContext()
	}
	
	private void addBeanDefinitions(ApplicationContext context) {
		DefaultListableBeanFactory scriptBeanFactory = context.autowireCapableBeanFactory
		for (name in  scriptBeanFactory.getBeanDefinitionNames()) {
			BeanDefinition definition = scriptBeanFactory.getBeanDefinition(name)
			applicationContext.autowireCapableBeanFactory.registerBeanDefinition(name, definition)
		}
	}

}
