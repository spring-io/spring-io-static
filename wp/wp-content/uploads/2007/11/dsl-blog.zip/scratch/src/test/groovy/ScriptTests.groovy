package test;

import groovy.util.GroovyTestCase;
import groovy.lang.Script;

class Dog extends Script {
	def name = "fred"
	String bark() {
		println "woof!"
		name
	}
	Object run() {
		println "Running"
		name
	}
}

/**
 * @author Dave Syer
 * 
 */
public class ScriptTests extends GroovyTestCase {

	public void customize(GroovyObject goo) {
		if (!(goo instanceof Script)) {
			throw new Exception("Not a Script");
		}
		def emc = new ExpandoMetaClass( goo.class, false )
		emc.invokeMethod = { name, args ->
			println "called: "+name
			def result
			def metaMethod = emc.getMetaMethod(name, args)
			if (metaMethod) result = metaMethod.invoke(delegate,args)
			if (name == "run") {
				println "inside run: "+result
				result = doCustomize(result);
			}
			result
		}
		emc.initialize()
		goo.metaClass = emc
	}
	
	private void doCustomize(Closure value) {
		print "*** foo"
	}
	
	public void testSomething() {
		Dog dog = new Dog();
		customize(dog)
		println "run: " + dog.run()
	}

	public void testNameOverride() {
		Dog goo = new Dog();
		def emc = new ExpandoMetaClass( goo.class, false )
		emc.name = null
		emc.initialize()
		goo.metaClass = emc
		println "name: " + goo.name
	}

	public void testBarkOverride() {
		Dog goo = new Dog();
		def emc = new ExpandoMetaClass( goo.class, false )
		emc.invokeMethod = { name, args ->
			println "called: "+name
			def result
			def metaMethod = emc.getMetaMethod(name, args)
			if (metaMethod) result = metaMethod.invoke(delegate,args)
			if (name == "bark") {
				println "inside bark: "+result
				result = { println "hey " + result + "!"; "barked" }()
			} else {
			}
			result
		}
		emc.initialize()
		goo.metaClass = emc
		println goo.bark()
	}
	
	public void testFromGroovyDocs() {
		def test = "test"
		def gstr = "hello $test"     // this is a GString, which implements GroovyObject

		def emc = new ExpandoMetaClass( gstr.class, false )
		emc.test = { println "test"; "test" }
		emc.initialize()

		gstr.metaClass = emc
		assert gstr.test() == "test"    
	}
}
