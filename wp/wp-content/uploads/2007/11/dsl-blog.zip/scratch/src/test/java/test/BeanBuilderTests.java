package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Properties;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class BeanBuilderTests implements ApplicationContextAware {
	
	@Resource(name="properties")
	Properties properties;
	
	@Resource(name="foo")
	String foo;
	
	@Resource(name="bar")
	String bar;
	
	@Resource(name="sonOfFoo")
	String sonOfFoo;

	private ApplicationContext applicationContext;
	
	/**
	 * Public setter for the {@link ApplicationContext} property.
	 *
	 * @param applicationContext the applicationContext to set
	 */
	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	/* (non-Javadoc)
	 * @see org.springframework.test.AbstractSingleSpringContextTests#getConfigLocations()
	 */
	protected String[] getConfigLocations() {
		return new String[] {"/test/BeanBuilderTests-context.xml"};
	}

	@Test
	public void testBeanFactory() throws Exception {
		Object bean = applicationContext.getBean("childContext");
		assertNotNull(bean);
	}

	@Test
	public void testBeanFromParentContext() throws Exception {
		assertEquals("foo", foo);
	}

	@Test
	public void testBeanFromChildContext() throws Exception {
		assertEquals("bar", bar);
		assertEquals("foo", sonOfFoo);
	}

	@Test
	public void testPropertiesFromChildContext() throws Exception {
		assertEquals("b", properties.getProperty("a"));
	}
}
