package com.carplant.domain;

/**
 * @author Alef Arendsen 
 */
public abstract class Part {	

	private String partNumber;
	
	private String model;
	
	@SuppressWarnings("unused")
	private int stock;
	
	private Part() {}

	public Part(String partNumber, CarModel model) {
		this.partNumber = partNumber;
		this.model = model.getName();
	}
	
	public String getPartNumber() {
		return partNumber;
	}
	
	public CarModel getModel() {
		return new CarModel(model);
	}
	
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o instanceof Part) {
			Part other = (Part)o;
			if (other.partNumber.equals(this.partNumber)) {
				return true;
			}
		}
		return false;
	}
	
	public int hashCode() {
		return partNumber.hashCode() * 29;
	}

}
