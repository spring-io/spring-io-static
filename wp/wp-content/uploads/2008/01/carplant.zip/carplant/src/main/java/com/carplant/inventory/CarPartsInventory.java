package com.carplant.inventory;

import java.util.List;

import com.carplant.domain.CarModel;
import com.carplant.domain.Part;

/**
 * @author Alef Arendsen 
 */
public interface CarPartsInventory {

	List<Part> getPartsForModel(CarModel model);

	void updatePartStockForPartNumber(Part part, int i);

	void addPart(Part part);

}
