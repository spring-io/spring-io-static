
package com.carplant.inventory;

import org.hibernate.SessionFactory;
import org.springframework.test.AbstractTransactionalDataSourceSpringContextTests;

import com.carplant.domain.Bolt;
import com.carplant.domain.CarModel;
import com.carplant.domain.Part;

/**
 * The car parts inventory should maintain a persistent list of parts
 * @author Alef Arendsen 
 */
public class HibernateCarPartsInventoryTest extends
		AbstractTransactionalDataSourceSpringContextTests {

	@SuppressWarnings("unused")
	private CarPartsInventory inventory;

	@SuppressWarnings("unused")
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void setInventory(CarPartsInventory inventory) {
		this.inventory = inventory;
	} 
	 
	
	public void testAddPart() {
		
		int currentCount = jdbcTemplate.queryForInt("select count(*) from t_part");
		
		Part p = new Bolt("FGH-1232132", new CarModel("MiniHummer"), 24);
		inventory.addPart(p);
		
		int newCount = jdbcTemplate.queryForInt("select count(*) from t_part");
		assertEquals(currentCount + 1, newCount);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

	@Override
	protected String[] getConfigLocations() {
		return new String[] { "com/carplant/config.xml", "com/carplant/infrastructure.xml" };
	}

}
