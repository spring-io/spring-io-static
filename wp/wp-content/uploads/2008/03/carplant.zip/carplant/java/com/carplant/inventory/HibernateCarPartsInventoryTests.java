
package com.carplant.inventory;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.test.AbstractTransactionalDataSourceSpringContextTests;

import com.carplant.Bolt;
import com.carplant.CarModel;
import com.carplant.InsufficientPartsInStockException;
import com.carplant.Part;

/**
 * The car parts inventory should maintain a persistent list of parts
 * @author Alef Arendsen 
 */
public class HibernateCarPartsInventoryTests extends
		AbstractTransactionalDataSourceSpringContextTests {

	private CarPartsInventory inventory;

	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void setInventory(CarPartsInventory inventory) {
		this.inventory = inventory;
	}

	@Override
	protected String[] getConfigLocations() {
		return new String[] { "com/carplant/java-config.xml", "com/carplant/infrastructure.xml" };
	}

	public void testPolymorphism() {
		Part part = new Bolt("FGH-0011", new CarModel("MiniHummer"), 24);
		inventory.addPart(part);

		sessionFactory.getCurrentSession().flush();

		List<Part> parts = inventory
				.getPartsForModel(new CarModel("MiniHummer"));
		assertEquals(1, parts.size());
		assertTrue(parts.get(0) instanceof Bolt);
	}

	/**
	 * Adding new parts to the system should result in the part being persisted
	 * in the underlying data store.
	 */
	public void testAddPart() {

		int oldCount = countPartsForModel("MiniHummer");
		int oldBoltCount = jdbcTemplate
				.queryForInt("select count(*) from t_part");

		assertEquals(0, oldBoltCount);

		Part part = new Bolt("FGH-0011", new CarModel("MiniHummer"), 24);
		inventory.addPart(part);

		sessionFactory.getCurrentSession().flush();

		assertEquals(oldCount + 1, countPartsForModel("MiniHummer"));
		assertEquals(oldBoltCount + 1, jdbcTemplate
				.queryForInt("select count(*) from t_bolt"));
	}

	private int countPartsForModel(String model) {
		return jdbcTemplate.queryForInt(
				"select count(*) from t_part where model = ?",
				new Object[] { model });
	}

	public void testUpdateStock() {
		Part part = new Bolt("FGH-0011", new CarModel("MiniHummer"), 24);
		inventory.addPart(part);

//		sessionFactory.getCurrentSession().flush();

		inventory.updatePartStockForPartNumber(part, 1);
	}

	public void testUpdateStockNotSufficientStockException() {
		Part part = new Bolt("FGH-0011", new CarModel("MiniHummer"), 24);
		inventory.addPart(part);

//		sessionFactory.getCurrentSession().flush();

		try {
			inventory.updatePartStockForPartNumber(part, -1);
			fail("Should have thrown an InsufficientPartsInStockException");
		} catch (InsufficientPartsInStockException e) {
			// okay!
		}
	}

}
