package com.carplant.logic;

import static org.junit.Assert.*;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.carplant.Bolt;
import com.carplant.CarModel;
import com.carplant.Engine;
import com.carplant.Windshield;
import com.carplant.inventory.CarPartsInventory;
import com.carplant.plant.CarPlant;

/**
 * @author Alef Arendsen 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"/com/carplant/autowire-config.xml", "/com/carplant/infrastructure.xml"})
public class CarPlantIntegrationTests {
	
	@Autowired private CarPlant carPlant;
	
	@Autowired private SessionFactory sessionFactory;

	@Autowired private CarPartsInventory inventory;

	private JdbcTemplate jdbcTemplate;
	
	@Autowired public void createJdbcTemplate(DataSource ds) {
		this.jdbcTemplate = new JdbcTemplate(ds);
	}
	
	@Transactional @Test public void partsTakenFromInventoryWhenManufacturing() {
	
		Bolt bolt24 = new Bolt("JHG-115a", new CarModel("MiniHummer"), 24);
		Bolt bolt22 = new Bolt("JHG-116a", new CarModel("MiniHummer"), 22);
		Bolt bolt17 = new Bolt("JHG-556", new CarModel("MaxiHummer"), 17);
		
		Engine engine1 = new Engine("ERR-90506", new CarModel("MiniHummer"), 700);
		Engine engine2 = new Engine("ERR-90507", new CarModel("MiniHummer"), 4200);
		
		Windshield wsNonSafe = new Windshield("WSH-4445", new CarModel("MiniHummer"), false);
		Windshield wsSafe = new Windshield("WSH-4447", new CarModel("MaxiHummer"), true);
		
		inventory.addPart(bolt24);		
		inventory.addPart(bolt22);
		inventory.addPart(bolt17);
		
		inventory.addPart(engine1);
		inventory.addPart(engine2);
		
		inventory.addPart(wsNonSafe);
		inventory.addPart(wsSafe);
		
		sessionFactory.getCurrentSession().flush();
		
		inventory.updatePartStockForPartNumber(bolt24, 10);		
		inventory.updatePartStockForPartNumber(bolt22, 10);
		inventory.updatePartStockForPartNumber(bolt17, 10);
		
		inventory.updatePartStockForPartNumber(engine1, 10);
		inventory.updatePartStockForPartNumber(engine2, 10);
		
		inventory.updatePartStockForPartNumber(wsNonSafe, 10);
		inventory.updatePartStockForPartNumber(wsSafe, 10);
		
		
		carPlant.manufactureCar(new CarModel("MiniHummer"));
		
		// count parts for MiniHummer
		assertEquals(9, countStock(bolt24.getPartNumber()));
		assertEquals(9, countStock(bolt22.getPartNumber()));
		// count parts for MaxiHummer
		assertEquals(10, countStock(bolt17.getPartNumber()));
	}
	
	private int countStock(String partNo) {
		return jdbcTemplate.queryForInt("select stock from t_part where part_number = ?", new Object[] {partNo});
	}

}
