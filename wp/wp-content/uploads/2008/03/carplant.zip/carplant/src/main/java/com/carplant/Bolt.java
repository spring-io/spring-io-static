package com.carplant;

public class Bolt extends Part {

	private int diameter;

	public Bolt(String partNumber, CarModel carModel, int diameter) {
		super(partNumber, carModel);
		this.diameter = diameter;
	}
	
	public int getDiameter() {
		return diameter;
	}
}
