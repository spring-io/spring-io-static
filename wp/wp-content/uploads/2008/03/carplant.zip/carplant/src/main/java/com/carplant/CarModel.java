package com.carplant;

public class CarModel {

	private String name;

	public CarModel(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

}
