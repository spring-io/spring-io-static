package com.carplant;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.config.java.annotation.Bean;
import org.springframework.config.java.annotation.Configuration;
import org.springframework.config.java.annotation.ExternalBean;
import org.springframework.jdbc.core.JdbcTemplate;

import com.carplant.assembly.CarAssemblyLine;
import com.carplant.inventory.CarPartsInventory;
import com.carplant.inventory.HibernateCarPartsInventory;
import com.carplant.plant.CarPlant;
import com.carplant.plant.DefaultCarPlant;

@Configuration
public abstract class Config {
	
	public @Bean CarPlant plant() {
		return new DefaultCarPlant(inventory(), assemblyLine());
	}

	public @Bean CarAssemblyLine assemblyLine() {
		return new CarAssemblyLine();
	}

	public @Bean CarPartsInventory inventory() {
		return new HibernateCarPartsInventory(
				new JdbcTemplate(dataSource()),
				sessionFactory());
	}

	public abstract @ExternalBean SessionFactory sessionFactory();

	public abstract @ExternalBean DataSource dataSource();
	

}
