package com.carplant.assembly;

import java.util.List;

import org.springframework.stereotype.Component;

import com.carplant.Car;
import com.carplant.CarModel;
import com.carplant.Part;

/**
 * @author Alef Arendsen 
 */
@Component
public class CarAssemblyLine {
	
	public Car assembleCarFromParts(CarModel model, List<Part> parts) {
		return new Car(model);
	}

}
