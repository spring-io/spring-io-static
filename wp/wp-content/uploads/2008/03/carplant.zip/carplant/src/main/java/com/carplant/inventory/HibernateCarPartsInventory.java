package com.carplant.inventory;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.carplant.CarModel;
import com.carplant.InsufficientPartsInStockException;
import com.carplant.Part;

@Transactional @Component
public class HibernateCarPartsInventory implements CarPartsInventory {
	
	private final JdbcTemplate template;
	private final SessionFactory sessionFactory;
	
	@Autowired
	public HibernateCarPartsInventory(JdbcTemplate template, SessionFactory factory) {
		this.template = template;
		this.sessionFactory = factory;
	}
	
	@SuppressWarnings("unchecked")
	public List<Part> getPartsForModel(CarModel model) {
		return (List<Part>)sessionFactory.getCurrentSession().createQuery(
				"from Part p where p.model=?").setParameter(0, model.getName()).list();
	}

	public void updatePartStockForPartNumber(Part part, int i) {
		int currentStock = template.queryForInt("select stock from t_part where part_number=?", 
				new Object[] { part.getPartNumber() });
		if (currentStock < -i) {
			throw new InsufficientPartsInStockException(part);
		}
		template.update("update t_part set stock = ? where part_number = ?", new Object[] { currentStock + i, part.getPartNumber() });
	}

	public void addPart(Part part) {
		sessionFactory.getCurrentSession().save(part);
	}
	
	@SuppressWarnings("unchecked")
	public List<Part> getAllParts() {
		return (List<Part>)sessionFactory.getCurrentSession().createQuery("from Part p").list();
	}
}
