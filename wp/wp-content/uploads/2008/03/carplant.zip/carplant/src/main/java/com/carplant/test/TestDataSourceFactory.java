package com.carplant.test;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 * A factory that creates a data source fit for use in a system test environment. Creates a simple data source that
 * connects to an in-memory database pre-loaded with test data.
 * 
 * This factory returns a fully-initialized DataSource implementation. When the DataSource is returned, callers are
 * guaranteed that the database schema and test data will have been loaded by that time.
 * 
 * Is a FactoryBean, for exposing the fully-initialized test DataSource as a Spring bean. See {@link #getObject()}.
 */
public class TestDataSourceFactory implements FactoryBean {

	private static Log logger = LogFactory.getLog(TestDataSourceFactory.class);

	// configurable properties

	private String testDatabaseName;

	private Resource schemaLocation;

	private Resource testDataLocation;

	/**
	 * The object created by this factory.
	 */
	private DataSource dataSource;

	/**
	 * Sets the name of the test database to create.
	 * @param testDatabaseName the name of the test database, i.e. "rewards"
	 */
	public void setTestDatabaseName(String testDatabaseName) {
		this.testDatabaseName = testDatabaseName;
	}

	/**
	 * Sets the location of the file containing the schema DDL to export to the test database.
	 * @param schemaLocation the location of the database schema DDL
	 */
	public void setSchemaLocation(Resource schemaLocation) {
		this.schemaLocation = schemaLocation;
	}

	/**
	 * Sets the location of the file containing the test data to load into the database.
	 * @param testDataLocation the location of the test data file
	 */
	public void setTestDataLocation(Resource testDataLocation) {
		this.testDataLocation = testDataLocation;
	}

	// implementing FactoryBean

	// this method is called by Spring to expose the DataSource as a bean
	public Object getObject() throws Exception {
		if (dataSource == null) {
			initDataSource();
		}
		return dataSource;
	}

	@SuppressWarnings("unchecked")
	public Class getObjectType() {
		return DataSource.class;
	}

	public boolean isSingleton() {
		return true;
	}

	// internal helper methods

	// encapsulates the steps involved in initializing the data source: creating it, and populating it
	private void initDataSource() {
		// create the in-memory database source first
		this.dataSource = createDataSource();
		if (logger.isDebugEnabled()) {
			logger.debug("Created in-memory test database '" + testDatabaseName + "'");
		}
		// now populate the database by loading the schema and test data
		populateDataSource();
		if (logger.isDebugEnabled()) {
			logger.debug("Exported schema in " + schemaLocation);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Loaded test data in " + testDataLocation);
		}
	}

	private DataSource createDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		// use the HsqlDB JDBC driver
		dataSource.setDriverClassName("org.hsqldb.jdbcDriver");
		// have it create an in-memory database
		dataSource.setUrl("jdbc:hsqldb:mem:" + testDatabaseName);
		dataSource.setUsername("sa");
		dataSource.setPassword("");
		return dataSource;
	}

	private void populateDataSource() {
		TestDatabasePopulator populator = new TestDatabasePopulator(dataSource);
		populator.populate();
	}

	/**
	 * Populates a in memory data source with test data.
	 */
	private class TestDatabasePopulator {

		private DataSource dataSource;

		/**
		 * Creates a new test database populator.
		 * @param dataSource the test data source that will be populated.
		 */
		public TestDatabasePopulator(DataSource dataSource) {
			this.dataSource = dataSource;
		}

		/**
		 * Populate the test database by creating the database schema from 'schema.sql' and inserting the test data in
		 * 'testdata.sql'.
		 */
		public void populate() {			
			Connection connection = null;
			try {
				connection = dataSource.getConnection();
				if (schemaLocation != null) {
					createDatabaseSchema(connection);
				}
				if (testDataLocation != null) {
					insertTestData(connection);
				}
			} catch (SQLException e) {
				throw new RuntimeException("SQL exception occurred acquiring connection", e);
			} finally {
				if (connection != null) {
					try {
						connection.close();
					} catch (SQLException e) {
					}
				}
			}
			
		}

		// create the application's database schema (tables, indexes, etc.)
		private void createDatabaseSchema(Connection connection) {
			try {
				String sql = parseSqlIn(schemaLocation);
				executeSql(sql, connection);
			} catch (IOException e) {
				throw new RuntimeException("I/O exception occurred accessing the database schema file", e);
			} catch (SQLException e) {
				throw new RuntimeException("SQL exception occurred exporting database schema", e);
			}
		}

		// populate the tables with test data
		private void insertTestData(Connection connection) {
			try {
				String sql = parseSqlIn(testDataLocation);
				executeSql(sql, connection);
			} catch (IOException e) {
				throw new RuntimeException("I/O exception occurred accessing the test data file", e);
			} catch (SQLException e) {
				throw new RuntimeException("SQL exception occurred loading test data", e);
			}
		}

		// utility method to read a .sql txt input stream
		private String parseSqlIn(Resource resource) throws IOException {
			InputStream is = null;
			try {
				is = resource.getInputStream();
				Reader reader = new InputStreamReader(is);
				char[] cbuf = new char[4096];
				reader.read(cbuf);
				return new String(cbuf).trim();
			} finally {
				if (is != null) {
					is.close();
				}
			}
		}

		// utility method to run the parsed sql
		private void executeSql(String sql, Connection connection) throws SQLException {
			Statement statement = connection.createStatement();
			statement.execute(sql);
		}
	}
}