package com.springsource.consulting.datasource;

import static org.junit.Assert.assertEquals;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class ConfigurationTests {
	
	private static final Log logger = LogFactory
	.getLog(ConfigurationTests.class);
		
	@Autowired
	private DataSource dataSource;

	private SimpleJdbcTemplate jdbcTemplate;
	
	@Before
	public void setUp() {
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}
	
	@Test
	public void testBusinessSchema() throws Exception {
		logger.debug("Checking business schema");
		assertEquals(0, jdbcTemplate.queryForInt("SELECT COUNT(0) from MESSAGE"));
	}

}
