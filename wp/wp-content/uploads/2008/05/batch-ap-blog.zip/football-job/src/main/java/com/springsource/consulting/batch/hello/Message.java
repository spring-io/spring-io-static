package com.springsource.consulting.batch.hello;

public class Message {

	private String value;

	public Message(String value) {
		super();
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	
	@Override
	public String toString() {
		return "Message: ["+value+"]";
	}
}
