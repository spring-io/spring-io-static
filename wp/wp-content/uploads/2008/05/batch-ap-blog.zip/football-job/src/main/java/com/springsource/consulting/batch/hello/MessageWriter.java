package com.springsource.consulting.batch.hello;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.item.ClearFailedException;
import org.springframework.batch.item.FlushFailedException;
import org.springframework.batch.item.ItemWriter;

public class MessageWriter implements ItemWriter {

	private static final Log logger = LogFactory.getLog(MessageWriter.class);

	public void clear() throws ClearFailedException {
		// NO-OP
	}

	public void flush() throws FlushFailedException {
		// NO-OP
	}

	public void write(Object data) throws Exception {
		Message message = (Message) data;
		logger.info(message);
	}

}
