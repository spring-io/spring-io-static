package org.springframework.batch.sample.football;

import org.springframework.batch.sample.football.Player;

public interface PlayerDao {

	void savePlayer(Player player);
}
