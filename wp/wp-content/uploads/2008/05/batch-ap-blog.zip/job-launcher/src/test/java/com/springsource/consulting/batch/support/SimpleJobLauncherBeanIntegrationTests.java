package com.springsource.consulting.batch.support;

import static org.junit.Assert.assertNotNull;

import java.util.Properties;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.converter.DefaultJobParametersConverter;
import org.springframework.batch.core.converter.JobParametersConverter;
import org.springframework.batch.core.repository.dao.JobInstanceDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class SimpleJobLauncherBeanIntegrationTests {

	@Autowired
	private JobInstanceDao jobInstanceDao;

	@Autowired
	private Properties parameters;

	@Autowired
	@Qualifier("helloWorld")
	private Job job;

	private JobParametersConverter converter = new DefaultJobParametersConverter();

	@Test
	public void testLaunchJob() throws Exception {
		assertNotNull(jobInstanceDao.getJobInstance(job, converter
				.getJobParameters(parameters)));
	}

}
