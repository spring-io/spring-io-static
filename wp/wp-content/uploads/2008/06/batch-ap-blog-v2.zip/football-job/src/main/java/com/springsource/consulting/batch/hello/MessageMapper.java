package com.springsource.consulting.batch.hello;

import org.springframework.batch.item.file.mapping.FieldSet;
import org.springframework.batch.item.file.mapping.FieldSetMapper;

public class MessageMapper implements FieldSetMapper {
	
	public Object mapLine(FieldSet fieldSet) {
		return new Message(fieldSet.readString(0));
	}

}
