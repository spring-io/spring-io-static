package com.springsource.consulting.batch.support;

import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.converter.DefaultJobParametersConverter;
import org.springframework.batch.core.converter.JobParametersConverter;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.osgi.context.BundleContextAware;

/**
 * @author Dave Syer
 * 
 */
public class SimpleJobLauncherBean implements ApplicationListener,
		BundleContextAware {

	private static final Log logger = LogFactory
			.getLog(SimpleJobLauncherBean.class);

	private final JobLauncher jobLauncher;
	private final Job job;
	private Properties parameters = new Properties();
	private JobParametersConverter converter = new DefaultJobParametersConverter();
	private BundleContext bundle;

	public void setBundleContext(BundleContext bundle) {
		this.bundle = bundle;
	}

	public SimpleJobLauncherBean(JobLauncher jobLauncher, Job job) {
		super();
		this.jobLauncher = jobLauncher;
		this.job = job;
	}

	public void setParameters(Properties parameters) {
		this.parameters = parameters;
	}

	public void onApplicationEvent(final ApplicationEvent event) {

		if (event instanceof ContextRefreshedEvent) {

			logger.info("Launching job in ContextRefreshedEvent: " + event);

			try {
				jobLauncher.run(job, converter.getJobParameters(parameters));
			} catch (JobExecutionAlreadyRunningException e) {
				logger.error("This job is already running", e);
			} catch (JobInstanceAlreadyCompleteException e) {
				logger.info("This job is already complete.  "
						+ "Maybe you need to change the input parameters?", e);
			} catch (JobRestartException e) {
				logger.error("Unspecified restart exception", e);
			} finally {

				if (bundle != null
						&& bundle.getBundle().getState() == Bundle.ACTIVE) {
					new Thread(new Runnable() {
						public void run() {
							try {
								logger.info("Stopping bundle...");
								bundle.getBundle().stop();
							} catch (BundleException e) {
								logger.error("Bundle Exception on stop", e);
							}
						}
					}).start();
				}

			}

		}

	}

}
