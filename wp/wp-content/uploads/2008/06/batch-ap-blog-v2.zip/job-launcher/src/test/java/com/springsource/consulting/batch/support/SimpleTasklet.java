package com.springsource.consulting.batch.support;

import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.ExitStatus;

public class SimpleTasklet implements Tasklet {

	public ExitStatus execute() throws Exception {
		return ExitStatus.FINISHED;
	}

}
