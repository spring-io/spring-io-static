#!/usr/bin/env bash
if [ -z $DMS_HOME ]
then
 echo "Must set DMS_HOME environment variable"
 exit -1
fi

JARS=`find $DMS_HOME -iname "com.springsource.org.h2*"`

for JAR in $JARS
do
	CLASSPATH=$CLASSPATH:$JAR
done

if [ -z $CLASSPATH ]
then
	echo "Cannot find H2 jars in dm Server repository"
	exit -1
fi