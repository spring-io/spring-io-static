#!/usr/bin/env bash
. ./h2.sh

java -cp $CLASSPATH org.h2.tools.Server

