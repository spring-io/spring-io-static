package greenpages;

import java.util.List;

public interface Directory {

	List<Listing> search(String term);
	
	Listing findListing(int id);
}
