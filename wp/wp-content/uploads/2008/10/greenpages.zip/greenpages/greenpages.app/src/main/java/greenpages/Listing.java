package greenpages;

public interface Listing {

	Integer getListingNumber();
	
	String getFirstName();
	
	String getLastName();
	
	String getEmailAddress();
}
