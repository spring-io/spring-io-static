package greenpages.internal;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

import greenpages.Directory;
import greenpages.Listing;

@Component("directory")
public class DirectoryImpl implements Directory {

	private static final Listing ROD_JOHNSON = new ImmutableListing(1, "Rod", "Johnson", "rod.johnson@springsource.com");

	public List<Listing> search(String term) {
		if(ROD_JOHNSON.getLastName().equalsIgnoreCase(term)) {
			Listing l = ROD_JOHNSON;
			
			return Collections.singletonList(l);
		} else {
			return Collections.emptyList();
		}
	}

	public Listing findListing(int id) {
		if(id == ROD_JOHNSON.getListingNumber()) {
			return ROD_JOHNSON;
		} else {
			return null;
		}
	}

}
