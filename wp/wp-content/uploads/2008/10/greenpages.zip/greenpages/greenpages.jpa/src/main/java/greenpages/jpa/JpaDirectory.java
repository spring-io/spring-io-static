package greenpages.jpa;

import greenpages.Directory;
import greenpages.Listing;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.Transactional;

@Transactional
final class JpaDirectory implements Directory {

	private static final String SEARCH_QUERY = "select l from Listing l where upper(l.lastName) like :term";
	
	@PersistenceContext
	private EntityManager em;
	
	public Listing findListing(int id) {
		return em.find(JpaListing.class, id);
	}

	@SuppressWarnings("unchecked")
	public List<Listing> search(String term) {
		return em.createQuery(SEARCH_QUERY)
		         .setParameter("term", "%" + term.toUpperCase() + "%")
		         .getResultList();
	}

}
