package greenpages.web;

import greenpages.Directory;
import greenpages.Listing;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class GreenPagesController {

	@Autowired
	private Directory directory;
	
	@RequestMapping("/home.htm")
	public void home() {
		System.out.println("hello!");
	}
	
	@RequestMapping("/search.htm")
	public List<Listing> search(@RequestParam("query") String query) {
		return this.directory.search(query);
	}
	
	@RequestMapping("/entry.htm")
	public Listing entry(@RequestParam("id") int id) {
		return this.directory.findListing(id);
	}
}
