package com.google.gwt.sample.stockwatcher.client.api;

import com.google.gwt.user.client.rpc.IsSerializable;

public class DelistedException extends Exception implements IsSerializable {

	private static final long serialVersionUID = 4791859977056922470L;
	private String symbol;

	public DelistedException() {
	}
	
	public DelistedException(String s) {
		this.symbol = s;
	}

	public String getSymbol() {
		return this.symbol;
	}
}
