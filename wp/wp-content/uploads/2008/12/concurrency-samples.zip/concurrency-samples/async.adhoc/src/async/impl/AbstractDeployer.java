package async.impl;

import org.osgi.framework.BundleContext;

import async.Deployer;

abstract class AbstractDeployer implements Deployer {

	protected final BundleContext context;

	public AbstractDeployer(BundleContext context) {
		this.context = context;
	}
	
	
}
