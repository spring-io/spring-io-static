package async.impl;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import async.Deployer;

public class Activator implements BundleActivator {

	public void start(BundleContext context) throws Exception {
//		Deployer d = new SyncDeployer(context);
//		Deployer d = new AdhocDeployer(context);
		Deployer d = new ExecutorDeployer(context);
//		Deployer d = new ProcessDeployer(context);
//		Deployer d = new ScalaDeployer(context);
		context.registerService(Deployer.class.getName(), d, null);
	}

	public void stop(BundleContext context) throws Exception {
	}

}
