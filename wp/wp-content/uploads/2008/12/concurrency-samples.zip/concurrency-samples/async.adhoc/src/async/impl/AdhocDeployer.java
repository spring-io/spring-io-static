package async.impl;

import java.lang.reflect.UndeclaredThrowableException;
import java.util.concurrent.atomic.AtomicReference;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;

import async.Deployer;

public class AdhocDeployer implements Deployer {

	private final BundleContext context; 
	
	public AdhocDeployer(BundleContext context) {
		this.context = context;
	}

	public void deploy(String bundlePath) throws BundleException {
		final Bundle bundle = this.context.installBundle(bundlePath);
		final AtomicReference<BundleException> ref = new AtomicReference<BundleException>();
		Thread t = new Thread(new Runnable() {

			public void run() {
				try {
					bundle.start();
				} catch (BundleException e) {
					ref.set(e);
				}
			}
			
		});
		t.start();
		try {
			t.join();
		} catch (InterruptedException e) {
			throw new BundleException("interrupted", e);
		}
		if(ref.get() != null) {
			throw ref.get();
		}
	}
}
