package async.impl;

import static async.impl.Utils.handleThrowable;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;
import org.springframework.context.ApplicationContext;
import org.springframework.osgi.context.event.OsgiBundleApplicationContextEvent;
import org.springframework.osgi.context.event.OsgiBundleApplicationContextListener;
import org.springframework.osgi.context.event.OsgiBundleContextFailedEvent;
import org.springframework.osgi.context.event.OsgiBundleContextRefreshedEvent;

public class ExecutorDeployer extends AbstractDeployer {

	private final ExecutorService executor = Executors.newCachedThreadPool();

	public ExecutorDeployer(BundleContext context) {
		super(context);
	}

	public void deploy(String bundlePath) throws BundleException {
		Bundle b = this.context.installBundle(bundlePath);
		Listener listener = new Listener(b);
		this.context.registerService(OsgiBundleApplicationContextListener.class.getName(), listener, null);
		startBundle(b);
		ApplicationContext ac = listener.await();
	}

	private void startBundle(Bundle b) throws BundleException {
		Future<Void> future = this.executor.submit(new BundleStartTask(b));
		try {
			future.get(10, TimeUnit.SECONDS);
		} catch (Exception e) {
			handleThrowable(e);
		} 
	}

	private static class BundleStartTask implements Callable<Void> {

		private final Bundle b;

		public BundleStartTask(Bundle b) {
			this.b = b;
		}

		public Void call() throws Exception {
			this.b.start();
			return null;
		}

	}

	private static class Listener implements OsgiBundleApplicationContextListener {

		private final Bundle bundle;

		private final CountDownLatch latch;
		
		private volatile boolean finished = false;

		private volatile ApplicationContext context;

		private volatile Throwable throwable;
		
		public Listener(Bundle bundle) {
			this.bundle = bundle;
			this.latch =  new CountDownLatch(1);
		}

		public void onOsgiApplicationEvent(OsgiBundleApplicationContextEvent event) {
			if(!finished && event.getBundle() == bundle) {
				this.finished = true;
				if(event instanceof OsgiBundleContextRefreshedEvent) {
					this.context = event.getApplicationContext();
				} else {
					this.throwable = ((OsgiBundleContextFailedEvent)event).getFailureCause();
				}
				this.latch.countDown();
			}
		}
		
		public ApplicationContext await() throws BundleException {
			if(!Utils.isSpringOsgiPoweredBundle(this.bundle)) {
				return null;
			}
			try {
				if(!this.latch.await(500, TimeUnit.SECONDS)) {
					throw new BundleException("timeout");
				}
				if(this.throwable != null) {
					handleThrowable(this.throwable);
				} else {
					return context;
				}
			} catch (InterruptedException e) {
				handleThrowable(e);
			}
			return null; 
		}

	}
}
