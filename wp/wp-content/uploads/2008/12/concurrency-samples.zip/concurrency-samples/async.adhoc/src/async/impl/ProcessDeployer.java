package async.impl;

import java.lang.reflect.UndeclaredThrowableException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;
import org.springframework.context.ApplicationContext;

import async.impl.process.ApplicationContextStarter;
import async.impl.process.BundleStarter;

public class ProcessDeployer extends AbstractDeployer {

	private final ExecutorService executor = Executors.newCachedThreadPool();

	private final BundleStarter bundleStarter;

	private final ApplicationContextStarter applicationContextStarter;

	public ProcessDeployer(BundleContext context) {
		super(context);
		this.bundleStarter = new BundleStarter(this.executor);
		this.applicationContextStarter = new ApplicationContextStarter(context);
	}

	public void deploy(String bundlePath) throws BundleException {
		Bundle bundle = this.context.installBundle(bundlePath);
		Future<Void> bundleFuture = this.bundleStarter.startBundle(bundle);
		get(bundleFuture);
		Future<ApplicationContext> contextFuture = this.applicationContextStarter.startApplicationContext(bundle);
		get(contextFuture);
	}

	private static <T> T get(Future<T> future) throws BundleException {
		try {
			return future.get(5, TimeUnit.SECONDS);
		} catch (Exception e) {
			handleThrowable(e);
			throw new IllegalStateException("hmmm....");
		}
	}

	private static void handleThrowable(Throwable t) throws BundleException {
		if (t instanceof RuntimeException) {
			throw (RuntimeException) t;
		} else if (t instanceof Error) {
			throw (Error) t;
		} else if (t instanceof InterruptedException) {
			throw new BundleException("Interrupted during bundle start.", t);
		} else if (t instanceof TimeoutException) {
			throw new BundleException("Timeout during bundle start.", t);
		} else if (t instanceof ExecutionException) {
			handleThrowable(t.getCause());
		} else if (t instanceof BundleException) {
			throw (BundleException) t;
		} else {
			throw new UndeclaredThrowableException(t);
		}
	}

}
