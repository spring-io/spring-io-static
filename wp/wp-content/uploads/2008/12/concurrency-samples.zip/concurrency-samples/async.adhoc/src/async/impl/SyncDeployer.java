package async.impl;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;

public class SyncDeployer extends AbstractDeployer {

	public SyncDeployer(BundleContext context) {
		super(context);
	}

	public void deploy(String bundlePath) throws BundleException {
		Bundle bundle = this.context.installBundle(bundlePath);
		bundle.start();
	}

}
