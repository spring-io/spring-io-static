package async.impl;

import java.lang.reflect.UndeclaredThrowableException;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleException;

public final class Utils {

    private static final String CONTEXT_DIR = "/META-INF/spring/";

    private static final String CONTEXT_FILES = "*.xml";

    private static final String SPRING_CONTEXT_HEADER = "Spring-Context";


    /**
     * Queries whether the supplied {@link Bundle} is Spring-DM powered.
     * 
     * @param bundle the <code>Bundle</code>.
     * @return <code>true</code> if the <code>Bundle</code> is Spring-DM powered, otherwise <code>false</code>.
     */
    public static boolean isSpringOsgiPoweredBundle(Bundle bundle) {
        // look first for Spring-Context entry
        if (getSpringContextHeader(bundle.getHeaders()) != null) {
            return true;
        }

        // check the default locations if the manifest doesn't give any info
        Enumeration<?> defaultConfig = bundle.findEntries(CONTEXT_DIR, CONTEXT_FILES, false);
        return defaultConfig != null && defaultConfig.hasMoreElements();
    }
    
    private static String getSpringContextHeader(Dictionary<?, ?> headers) {
        Object header = null;
        if (headers != null) {
            header = headers.get(SPRING_CONTEXT_HEADER);
        }
        return header != null ? header.toString() : null;
    }
    
	public static void handleThrowable(Throwable t) throws BundleException {
		if(t instanceof RuntimeException) {
			throw (RuntimeException)t;
		} else if(t instanceof Error) {
			throw (Error)t;
		} else if(t instanceof InterruptedException) {
			throw new BundleException("Interrupted during bundle start.", t);
		} else if(t instanceof TimeoutException) {
			throw new BundleException("Timeout during bundle start.", t);
		} else if(t instanceof ExecutionException) {
			handleThrowable(t.getCause());
		} else if(t instanceof BundleException) {
			throw (BundleException)t;
		} else {
			throw new UndeclaredThrowableException(t);
		}
	}

}

