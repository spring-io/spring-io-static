package async.impl.process;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;

import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleEvent;
import org.osgi.framework.BundleException;
import org.osgi.framework.BundleListener;
import org.osgi.framework.ServiceRegistration;
import org.springframework.context.ApplicationContext;
import org.springframework.osgi.context.event.OsgiBundleApplicationContextEvent;
import org.springframework.osgi.context.event.OsgiBundleApplicationContextListener;
import org.springframework.osgi.context.event.OsgiBundleContextFailedEvent;
import org.springframework.osgi.context.event.OsgiBundleContextRefreshedEvent;

import async.impl.Utils;

public class ApplicationContextStarter {

	private final Object monitor = new Object();

	private final ServiceRegistration listenerRegistration;
	
	private final Map<Bundle, SettableFuture<ApplicationContext>> futures = new HashMap<Bundle, SettableFuture<ApplicationContext>>();

	public ApplicationContextStarter(BundleContext bundleContext) {
		this.listenerRegistration = bundleContext.registerService(OsgiBundleApplicationContextListener.class.getName(), new BundleMonitorApplicationContextListener(), null);
		bundleContext.addBundleListener(new BundleStarterBundleListener());
	}

	public Future<ApplicationContext> startApplicationContext(Bundle bundle) throws BundleException {
		if(bundle.getState() != Bundle.ACTIVE) {
			throw new IllegalStateException("Bundle must be in active state to create application context.");
		}
		
		if(!Utils.isSpringOsgiPoweredBundle(bundle)) {
			return new StaticFuture<ApplicationContext>(null);
		}
		
		synchronized(this.monitor) {
			return getFuture(bundle);
		}
	}

	private SettableFuture<ApplicationContext> getFuture(Bundle bundle) {
		assert Thread.holdsLock(this.monitor);
		SettableFuture<ApplicationContext> future = this.futures.get(bundle);
		
		if(future == null) {
			future = new SettableFuture<ApplicationContext>();
			this.futures.put(bundle, future);
		}
		
		return future;
	}

	public void destroy() throws Exception {
		if (this.listenerRegistration != null) {
			this.listenerRegistration.unregister();
		}
	}

	final class BundleMonitorApplicationContextListener implements OsgiBundleApplicationContextListener {

		/**
		 * {@inheritDoc}
		 */
		public void onOsgiApplicationEvent(OsgiBundleApplicationContextEvent event) {
			synchronized (monitor) {
				SettableFuture<ApplicationContext> future = getFuture(event.getBundle());
				
				if(!future.isDone()) {
					if (event instanceof OsgiBundleContextFailedEvent) {
						future.handOff(((OsgiBundleContextFailedEvent) event).getFailureCause());
					} else if (event instanceof OsgiBundleContextRefreshedEvent) {
						future.handOff(event.getApplicationContext());
					}					
				}
			}
		}

	}

	final class BundleStarterBundleListener implements BundleListener {

		/**
		 * {@inheritDoc}
		 */
		public void bundleChanged(BundleEvent event) {
			if (event.getType() == BundleEvent.STOPPED) {
				synchronized (monitor) {
					futures.remove(event.getBundle());
				}
			}
		}

	}
}
