package async.impl.process;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import org.osgi.framework.Bundle;

public class BundleStarter {

	private final ExecutorService executor;
	
	public BundleStarter(ExecutorService executor) {
		this.executor = executor;
	}

	public Future<Void> startBundle(Bundle bundle) {
		return this.executor.submit(new BundleStarterTask(bundle));
	}
	
	private static class BundleStarterTask implements Callable<Void> {

		private final Bundle bundle;
		
		public BundleStarterTask(Bundle bundle) {
			this.bundle = bundle;
		}

		public Void call() throws Exception {
			this.bundle.start();
			return null;
		}
		
	}
}
