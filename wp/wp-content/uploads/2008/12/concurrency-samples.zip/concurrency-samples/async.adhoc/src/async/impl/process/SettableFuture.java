package async.impl.process;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.context.ApplicationContext;

final class SettableFuture<T> implements Future<T> {

	private final ReentrantLock lock = new ReentrantLock();

	private final Condition available = this.lock.newCondition();

	private T value;

	private Throwable throwable;

	/**
	 * Signals successful completion of the {@link ApplicationContext}
	 * construction.
	 * 
	 * @param context
	 *            the created <code>ApplicationContext</code>.
	 */
	public void handOff(T context) {
		this.lock.lock();
		assertNotDone();
		try {
			this.value = context;
			this.throwable = null;
			this.available.signalAll();
		} finally {
			this.lock.unlock();
		}
	}

	/**
	 * Signals failed {@link T} construction.
	 * 
	 * @param throwable
	 *            the error that occurred.
	 */
	public void handOff(Throwable throwable) {
		this.lock.lock();
		assertNotDone();
		try {
			this.value = null;
			this.throwable = throwable;
			this.available.signalAll();
		} finally {
			this.lock.unlock();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean cancel(boolean mayInterruptIfRunning) {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public T get() throws InterruptedException, ExecutionException {
		this.lock.lock();
		try {
			if (isDone()) {
				return processResult();
			}
			this.available.await();
			return processResult();
		} finally {
			this.lock.unlock();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public T get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
		this.lock.lock();
		try {
			if (isDone()) {
				return processResult();
			}
			if (this.available.await(timeout, unit)) {
				return processResult();
			} else {
				throw new TimeoutException("Timeout while waiting.");
			}
		} finally {
			this.lock.unlock();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isCancelled() {
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isDone() {
		this.lock.lock();
		try {
			return this.value != null || this.throwable != null;
		} finally {
			this.lock.unlock();
		}
	}

	private T processResult() throws ExecutionException {
		if (this.value != null) {
			return this.value;
		} else {
			throw new ExecutionException(this.throwable);
		}
	}
	

	private void assertNotDone() {
		if(isDone()) {
			throw new IllegalStateException("Future result already set");
		}
	}
}
