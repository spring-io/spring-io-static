package async.impl.process;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

final class StaticFuture<T> implements Future<T> {

    private final T value;

    /**
     * Creates a new <code>StaticFuture</code>.
     * 
     * @param value the value to return.
     */
    public StaticFuture(T value) {
        this.value = value;
    }

    /**
     * {@inheritDoc}
     */
    public boolean cancel(boolean mayInterruptIfRunning) {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    public T get() throws InterruptedException, ExecutionException {
        return this.value;
    }

    /**
     * {@inheritDoc}
     */
    public T get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
        return this.value;
    }

    /**
     * {@inheritDoc}
     */
    public boolean isCancelled() {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    public boolean isDone() {
        return true;
    }

}
