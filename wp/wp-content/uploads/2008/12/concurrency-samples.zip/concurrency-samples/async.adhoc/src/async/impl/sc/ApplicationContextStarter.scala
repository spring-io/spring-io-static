package async.impl.sc

import org.springframework.context.ApplicationContext;
import org.springframework.osgi.context.event.OsgiBundleApplicationContextListener;
import org.springframework.osgi.context.event.OsgiBundleApplicationContextEvent;
import org.springframework.osgi.context.event.OsgiBundleContextFailedEvent;
import org.springframework.osgi.context.event.OsgiBundleContextRefreshedEvent;

import org.osgi.framework.BundleContext
import org.osgi.framework.Bundle
import org.osgi.framework.BundleException
import scala.actors.Actor
import scala.actors.Actor._
import scala.actors.OutputChannel

import java.util.concurrent.ConcurrentHashMap;

class ApplicationContextStarter(bundleContext: BundleContext) extends Actor {

  val waiting = new ConcurrentHashMap[Bundle, OutputChannel[Any]]();
  
  val messages = new ConcurrentHashMap[Bundle, ApplicationContextMessage]();
  
  override def start(): Actor = {
    bundleContext.registerService("org.springframework.osgi.context.event.OsgiBundleApplicationContextListener", new ListenerAdapter(this), null);
    return super.start();
  }
  
  def act() {
    loop {
      react {
        case bundle: Bundle => {
          val msg = messages.get(bundle);
          if(msg != null) {
            reply(msg);
          } else {
            waiting.put(bundle, sender);
          }
        }
        case event: OsgiBundleContextRefreshedEvent => {
          val msg = new ApplicationContextStartSuccess(event.getBundle(), event.getApplicationContext());
          recordMessage(event.getBundle(), msg);
        } 
        case event: OsgiBundleContextFailedEvent => {
          val msg = new ApplicationContextStartFailure(event.getBundle(), event.getFailureCause());
          recordMessage(event.getBundle(), msg);
        }
      }
     }
  }
  
	def recordMessage(bundle: Bundle, message: ApplicationContextMessage) {
	  messages.put(bundle, message);
	  val waiter = waiting.get(bundle);
	  if(waiter != null) {
	    waiter ! message;
	  }
	}
    
  
  class ListenerAdapter(actor: Actor) extends OsgiBundleApplicationContextListener {
    
    def onOsgiApplicationEvent(event: OsgiBundleApplicationContextEvent) {
      actor ! event;
    }
  }
}

abstract case class ApplicationContextMessage;
case class ApplicationContextStartSuccess(bundle: Bundle, context: ApplicationContext) extends ApplicationContextMessage;
case class ApplicationContextStartFailure(bundle: Bundle, throwable: Throwable) extends ApplicationContextMessage;
