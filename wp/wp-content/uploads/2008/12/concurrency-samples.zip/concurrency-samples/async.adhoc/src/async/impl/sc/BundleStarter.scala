package async.impl.sc

import org.osgi.framework.BundleContext
import org.osgi.framework.Bundle
import org.osgi.framework.BundleException
import scala.actors.Actor
import scala.actors.Actor._

class BundleStarter(bundleContext: BundleContext) extends Actor {

  def act() {
    loop {
      react {
        case bundle: Bundle => {
          try {
             bundle.start();
             reply(BundleStartSuccess(bundle));
          } catch {
            case t: Throwable => {
              reply(BundleStartFailed(bundle, t));
            }
          }
        }
      }
    }
  }
  
}

  case class BundleStartFailed(bundle: Bundle, cause: Throwable);
  case class BundleStartSuccess(bundle: Bundle);