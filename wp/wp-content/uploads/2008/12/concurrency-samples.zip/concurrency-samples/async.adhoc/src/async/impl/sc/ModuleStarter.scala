package async.impl.sc

import org.springframework.context.ApplicationContext;

import org.osgi.framework.BundleContext
import org.osgi.framework.Bundle
import org.osgi.framework.BundleException
import scala.actors.Actor
import scala.actors.Actor._

class ModuleStarter(bundleStarter: BundleStarter, acStarter: ApplicationContextStarter) extends Actor {

  
  def act() {
    loop {
      react {
        case bundle: Bundle => {
          val resp = bundleStarter !? bundle;
          resp match {
            case BundleStartFailed(bundle, t) => {
              reply(ModuleStartFailed(bundle, t));
            }
            case BundleStartSuccess(bundle) => {
              val resp = acStarter !? bundle;
              resp match {
                case ApplicationContextStartSuccess(bundle, context) => {
                  reply(ModuleStartSuccess(bundle, context));
                }
                case ApplicationContextStartFailure(bundle, cause) => {
                  reply(ModuleStartFailed(bundle, cause))
                }
              }
              System.out.println("Module starter" + resp);
            }
          }
        }
      }
    }
  }
}

case class ModuleStartFailed(bundle: Bundle, cause: Throwable);
case class ModuleStartSuccess(bundle: Bundle, context: ApplicationContext);
