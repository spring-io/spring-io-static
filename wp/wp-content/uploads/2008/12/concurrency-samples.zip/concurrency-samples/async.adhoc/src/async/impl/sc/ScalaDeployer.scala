package async.impl.sc

import org.springframework.context.ApplicationContext;

import org.osgi.framework.BundleContext
import org.osgi.framework.Bundle
import scala.actors.Actor
import scala.actors.Future
import scala.actors.Actor._
import async.Deployer
import async.impl.Utils._

class ScalaDeployer(bundleContext: BundleContext) extends Deployer {

  val bundleStarter = new BundleStarter(bundleContext);
  bundleStarter.start();
  
  val acStarter = new ApplicationContextStarter(bundleContext);
  acStarter.start();
  
  val moduleStarter = new ModuleStarter(bundleStarter, acStarter);
  moduleStarter.start();
  
  def deploy(path: String) {
    val bundle = bundleContext.installBundle(path);
    val future = moduleStarter !! bundle;
    
    future.apply() match {
      case ModuleStartFailed(bundle, cause) => {
        handleThrowable(cause);
      } 
      case ModuleStartSuccess(bundle, context) => {
        System.out.println("Success: " + bundle);
      }
    }
  }
}
