package async.bundle;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class Activator implements BundleActivator{

	public void start(BundleContext context) throws Exception {
//		Thread.sleep(Long.MAX_VALUE);
//		throw new IllegalStateException("I'm a baaad bundle!");
	}

	public void stop(BundleContext context) throws Exception {
		
	}

}
