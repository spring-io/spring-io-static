package async.bundle;

public class Bean {

	public void start() throws InterruptedException {
		Thread.sleep(Long.MAX_VALUE);
	}
}
