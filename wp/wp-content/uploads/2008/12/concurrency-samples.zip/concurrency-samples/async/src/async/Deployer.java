package async;

import org.osgi.framework.BundleException;

public interface Deployer {

	void deploy(String bundlePath) throws BundleException; 
}
