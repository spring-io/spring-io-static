package async;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.adaptor.LocationManager;
import org.eclipse.osgi.baseadaptor.BaseAdaptor;
import org.eclipse.osgi.framework.internal.core.Constants;
import org.eclipse.osgi.framework.internal.core.FrameworkConsole;
import org.eclipse.osgi.framework.internal.core.FrameworkProperties;
import org.eclipse.osgi.framework.internal.core.OSGi;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;
import org.osgi.framework.ServiceReference;

public class Launcher {

	public static void main(String[] args) throws Exception {
		BundleContext context = launchOsgi();
		installAndStartBaseBundles(context);
		Deployer d = startDeployerBundle(context);
		
		try {
			d.deploy("reference:file:" + new File("../async.bundle/bin").getAbsolutePath());
			System.out.println("Deployment successful");
		} catch (Exception e) {
			System.out.println("Deployment failed");
			e.printStackTrace(System.out);
		}

		System.exit(0);
	}

	private static Deployer startDeployerBundle(BundleContext context) throws BundleException {
		Bundle deployerImplBundle = installBundle(context, new File("../async.adhoc/bin"));
		deployerImplBundle.start();

		ServiceReference ref = context.getServiceReference(Deployer.class.getName());
		Deployer d = (Deployer) context.getService(ref);
		return d;
	}

	private static BundleContext launchOsgi() {
		FrameworkProperties.setProperty(LocationManager.PROP_CONFIG_AREA, "bin/config");
		FrameworkProperties.setProperty(LocationManager.PROP_INSTALL_AREA, "bin/config");
		FrameworkProperties.setProperty(Constants.OSGI_JAVA_PROFILE, "file:"
				+ new File("test.profile").getAbsolutePath());
		FrameworkProperties.setProperty("osgi.clean", "true");

		OSGi osgi = new OSGi(new BaseAdaptor(null));
		osgi.launch();

		FrameworkConsole console = new FrameworkConsole(osgi, 2402, null);
		Thread t = new Thread(console, "console-thread");
		t.start();

		BundleContext context = osgi.getBundleContext();
		return context;
	}

	private static void installAndStartBaseBundles(BundleContext context) throws BundleException {
		File f = new File("bundles");
		File[] files = f.listFiles();
		List<Bundle> bundles = new ArrayList<Bundle>();
		for (File file : files) {
			if (!file.getName().startsWith(".")) {
				Bundle bundle = installBundle(context, file);
				bundles.add(bundle);
			}
		}
		for (Bundle bundle : bundles) {
			bundle.start();
		}
	}

	private static Bundle installBundle(BundleContext context, File file) throws BundleException {
		String installPath = "reference:file:" + file.getAbsolutePath();
		Bundle bundle = context.installBundle(installPath);
		return bundle;
	}
}
