package deadlock;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class Activator implements BundleActivator{

	public void start(BundleContext context) throws Exception {
		DeadlockCreator dc = new DeadlockCreator();
		dc.createDeadlock(4, 3);
	}

	public void stop(BundleContext context) throws Exception {
		
	}

}
