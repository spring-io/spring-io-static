package deadlock;

import java.lang.Thread.State;
import java.util.concurrent.CountDownLatch;

public class DeadlockCreator {

	public Thread[] createDeadlock(int threadCount, int extraneousCount) {
		CountDownLatch latch = new CountDownLatch(threadCount);
		Object[] monitors = new Object[threadCount];

		for (int x = 0; x < threadCount; x++) {
			monitors[x] = new Object();
		}

		Thread[] threads = new Thread[threadCount];
		for (int x = 0; x < threadCount; x++) {
			int f = x;
			int s = (x == threadCount - 1 ? 0 : x + 1);
			threads[x] = new Thread(new DeadlockRunnable(latch, monitors[f], monitors[s]), "main-" + x);
			threads[x].start();
		}
		try {
			latch.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		awaitBlocking(threads);

		Thread[] extraneous = new Thread[extraneousCount];
		for (int x = 0; x < extraneousCount; x++) {
			extraneous[x] = new Thread(new ExtraneousRunnable(monitors[0]), "extraneous-" + x);
			extraneous[x].start();
		}
		awaitBlocking(extraneous);
		return threads;
	}

	private void awaitBlocking(Thread[] threads) {
		for (Thread thread : threads) {
			while (thread.getState() != State.BLOCKED) {
				try {
					Thread.sleep(30);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private static final class DeadlockRunnable implements Runnable {

		private final CountDownLatch latch;

		private final Object first;

		private final Object second;

		/**
		 * @param latch
		 * @param first
		 * @param second
		 */
		public DeadlockRunnable(CountDownLatch latch, Object first, Object second) {
			this.latch = latch;
			this.first = first;
			this.second = second;
		}

		/**
		 * @inheritDoc
		 */
		public void run() {
			synchronized (this.first) {
				this.latch.countDown();
				try {
					this.latch.await();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				synchronized (this.second) {

				}
			}
		}

	}

	private static final class ExtraneousRunnable implements Runnable {

		private final Object monitor;

		/**
		 * @param monitor
		 */
		public ExtraneousRunnable(Object monitor) {
			this.monitor = monitor;
		}

		/**
		 * @inheritDoc
		 */
		public void run() {
			synchronized (this.monitor) {

			}
		}

	}

}