package deadlock;

public class Main {

	public static void main(String[] args) {
		DeadlockCreator dc = new DeadlockCreator();
		dc.createDeadlock(4, 2);
	}
}
