package phasers;

import java.util.concurrent.CountDownLatch;

public class DubiousPerfTest {

	
	public static void main(String[] args) throws InterruptedException {
		int fibs = 43;
		
		PerfRunnableDecorator[] decorators = new PerfRunnableDecorator[fibs];
		CountDownLatch start = new CountDownLatch(1);
		CountDownLatch complete = new CountDownLatch(fibs);
		
		for(int x = 0; x < fibs; x++) {
			FibRunnable fib = new FibRunnable(x);

			PerfRunnableDecorator runnable = new PerfRunnableDecorator(start, complete, fib);
			decorators[x] = runnable;
			Thread t = new Thread(runnable);
			t.start();
		}
		
		long before = System.currentTimeMillis();
		start.countDown();
		complete.await();
		long after = System.currentTimeMillis();
		
		long result = after - before;
		
		System.out.println("done in " + result + " ms.");
	}
	
	private static final class PerfRunnableDecorator implements Runnable {

		private final CountDownLatch start;
		
		private final Runnable runnable;
		
		private final CountDownLatch complete;
		
		
		public PerfRunnableDecorator(CountDownLatch start, CountDownLatch complete, Runnable runnable) {
			this.start = start;
			this.complete = complete;
			this.runnable = runnable;
		}


		public void run() {
			try {
				this.start.await();
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
			this.runnable.run();
			this.complete.countDown();
		}
		
	}
}
