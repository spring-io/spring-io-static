/**
 * 
 */
package phasers;

final class FibRunnable implements Runnable {

	private final int n;

	public FibRunnable(int n) {
		this.n = n;
	}

	public void run() {
		System.out.println(n + "\t=\t" + PerfTest.fib(n));
	}

}