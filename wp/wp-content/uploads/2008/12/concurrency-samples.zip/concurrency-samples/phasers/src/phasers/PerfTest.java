package phasers;

import jsr166y.Phaser;

public class PerfTest {

	public static void main(String[] args) {
		Phaser p = new Phaser();
		int fibs = 43;
		
		p.register(); // register self
		for(int x = 0; x < fibs; x++) {
			FibRunnable fib = new FibRunnable(x);
			p.register(); // register each of the parties that are participating
			Thread t = new Thread(new PerfRunnableDecorator(p, fib));
			t.start();
		}
		
		long before = System.currentTimeMillis();
		p.arriveAndAwaitAdvance();
		int currentPhase = p.arriveAndDeregister();
		currentPhase = p.awaitAdvance(currentPhase);
		long after = System.currentTimeMillis();
		
		System.out.println("done in " + (after -before) + " ms.");
	}

	private static void dumpPhaser(Phaser p) {
		System.out.println("---");
		System.out.println("arrived: " + p.getArrivedParties());
		System.out.println("registered: " + p.getRegisteredParties());
		System.out.println("unarrived: " + p.getUnarrivedParties());
		System.out.println("phase: " + p.getPhase());
		System.out.println("---");
	}

	static long fib(int n) {
		if (n <= 1)
			return n;
		else
			return fib(n - 1) + fib(n - 2);
	}

	private static final class PerfRunnableDecorator implements Runnable {

		private final Phaser phaser;
		private final Runnable runnable;
		
		
		public PerfRunnableDecorator(Phaser phaser, Runnable runnable) {
			this.phaser = phaser;
			this.runnable = runnable;
		}


		public void run() {
			this.phaser.arriveAndAwaitAdvance();
			this.runnable.run();
			this.phaser.arriveAndDeregister();
		}
		
	}
}
