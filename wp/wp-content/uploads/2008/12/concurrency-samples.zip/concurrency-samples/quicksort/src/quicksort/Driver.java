package quicksort;

import static quicksort.QuicksortUtils.array;
import jsr166y.forkjoin.ForkJoinPool;

public class Driver {

	private static final int TEST_SIZE = 1000000;
	
	private static ForkJoinPool pool = new ForkJoinPool(5);
	
	public static void main(String[] args) {
		for(int x = 0; x < 10000; x++) {
			sequential(array(100));
			parallel(array(100));
		}
		long before = System.currentTimeMillis();
		sequential(array(TEST_SIZE));
		System.out.println("\n\nsequential: \t\t" + (System.currentTimeMillis() - before));

		before = System.currentTimeMillis();
		int[] array = array(TEST_SIZE);
		parallel(array);
		System.out.println("\n\nparallel: \t\t" + (System.currentTimeMillis() - before));
	}

	private static void parallel(int[] array) {
		ParallelQuicksort p = new ParallelQuicksort(array);
		pool.invoke(p);
	}

	private static void sequential(int[] array) {
		Quicksort q = new Quicksort();
		q.quicksort(array);
	}
}
