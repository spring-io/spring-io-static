package quicksort;

import static quicksort.QuicksortUtils.*;
import jsr166y.forkjoin.RecursiveAction;

public class ParallelQuicksort extends RecursiveAction {

	private static final int SEQUENTIAL_SEGMENT_SIZE = 10000;

	private static final long serialVersionUID = -3722975956802430306L;

	private final int[] array;
	private int left;
	private int right;

	public ParallelQuicksort(int[] array) {
		this(array, 0, array.length - 1);
	}

	private ParallelQuicksort(int[] array, int left, int right) {
		this.array = array;
		this.left = left;
		this.right = right;
	}

	@Override
	protected void compute() {
		if (right - left > SEQUENTIAL_SEGMENT_SIZE) {
			int p = partition(this.array, this.left, this.right);
			forkJoin(new ParallelQuicksort(this.array, left, p - 1), 
					 new ParallelQuicksort(this.array, p + 1, right));
		} else {
			quicksort(array, left, right);
		}
	}
	
	private void quicksort(int[] array, int left, int right) {
		if (right > left) {
			int p = partition(array, left, right);
			quicksort(array, left, p - 1);
			quicksort(array, p + 1, right);
		}
	}
}
