package quicksort;

import static quicksort.QuicksortUtils.*;

public class Quicksort  {

	public void quicksort(int[] array) {
		quicksort(array, 0, array.length - 1);
	}

	private void quicksort(int[] array, int left, int right) {
		if (right > left) {
			int p = partition(array, left, right);
			quicksort(array, left, p - 1);
			quicksort(array, p + 1, right);
		}
	}
}
