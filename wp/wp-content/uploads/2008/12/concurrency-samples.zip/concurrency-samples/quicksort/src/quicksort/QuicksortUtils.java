package quicksort;

import java.util.Random;

public class QuicksortUtils {

	public static int partition(int[] array, int left, int right) {
		int pivotIndex = left;
		int pivotValue = array[pivotIndex];
		swap(array, pivotIndex, right);

		int storeIndex = left;
		for (int x = left; x < right; x++) {
			if (array[x] < pivotValue) {
				swap(array, x, storeIndex);
				storeIndex++;
			}
		}

		swap(array, storeIndex, right);
		return storeIndex;
	}

	private static void swap(int[] a, int i, int j) {
		int swap = a[i];
		a[i] = a[j];
		a[j] = swap;
	}
	
	public static int[] array() {
		return array(200000);
	}
	
	public static int[] array(int length) {
		Random r = new Random();
		int[] array = new int[length];
		for (int x = 0; x < length; x++) {
			array[x] = Math.abs(r.nextInt() % (length * 5));
		}

		return array;
	}
	
	public static void dumpArray(int[] array) {
		for (int i : array) {
			System.out.println(i + " ");
		}
	}
	
}
