package transfer;

import jsr166y.LinkedTransferQueue;
import jsr166y.TransferQueue;

public class Queuing {
	
	public static void main(String[] args) throws Exception {
		final TransferQueue<String> tq = new LinkedTransferQueue<String>();
		Thread t = new Thread(new Runnable() {

			public void run() {
				try {
					Thread.sleep(1000);
					System.out.println("taken: " + tq.take());
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		});
		t.start();
		System.out.println("transeferring");
		tq.offer("foo");
		System.out.println("given");
	}
}
