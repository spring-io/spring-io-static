package com.ben;

import org.springframework.osgi.test.AbstractConfigurableBundleCreatorTests;
import org.springframework.osgi.test.platform.OsgiPlatform;

import com.google.gwt.sample.stockwatcher.client.api.StockPrice;
import com.google.gwt.sample.stockwatcher.client.api.StockPriceService;

public abstract class StockWatcherServiceTest extends AbstractConfigurableBundleCreatorTests {
	StockPriceService service;
	String serviceBundleName;
	int maxStockPrice;
	
	StockWatcherServiceTest(String serviceBundleName, int maxStockPrice) {
		this.serviceBundleName = serviceBundleName;
		this.maxStockPrice = maxStockPrice;
	}
	
	@Override
	protected String getRootPath() {
		return "file:./target/classes";
	}

	@Override
	protected OsgiPlatform createPlatform() { 
//		System.setProperty("osgi.console", "9000"); 	/* Uncomment to enable OSGi console */
		return super.createPlatform(); 
	} 
	
	/* Called automatically by Spring */
	public void setStockPriceService(StockPriceService service) {
		this.service = service;
	}
	
	@Override
	protected String[] getTestBundlesNames() {
		return new String[] { 
			"javax.servlet, com.springsource.javax.servlet, 2.5.0",
			"com.google.gwt, com.google.gwt, 1.5.3",
			"com.google.gwt, com.google.gwt.sample.stockwatcher.client.api, 1.0.0",
			serviceBundleName
	};
	}
	
	@Override
	protected String[] getConfigLocations() {
		return new String[] { "osgi-config.xml" };
	}
		
	public void testStockPriceService() throws Exception {
		final String symbol = "foo";
		
		assertNotNull(service);
		
		StockPrice[] prices = service.getPrices(new String[]{symbol});
		assertEquals(prices.length, 1);
		assertEquals(prices[0].getSymbol(), symbol);
		assertTrue(prices[0].getPrice() > 0);
		assertTrue(prices[0].getPrice() <= maxStockPrice);
	}
}
