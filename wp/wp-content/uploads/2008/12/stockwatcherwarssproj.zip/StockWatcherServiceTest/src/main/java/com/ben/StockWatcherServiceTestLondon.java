package com.ben;

public class StockWatcherServiceTestLondon extends StockWatcherServiceTest {
	public StockWatcherServiceTestLondon(){
		super("com.google.gwt, com.google.gwt.sample.stockwatcher.service.london, 1.0.0", 100);
	}
}
