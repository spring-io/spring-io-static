package com.ben;

public class StockWatcherServiceTestNewYork extends StockWatcherServiceTest {
	public StockWatcherServiceTestNewYork(){
		super("com.google.gwt, com.google.gwt.sample.stockwatcher.service.newyork, 1.0.0", 600);
	}
}