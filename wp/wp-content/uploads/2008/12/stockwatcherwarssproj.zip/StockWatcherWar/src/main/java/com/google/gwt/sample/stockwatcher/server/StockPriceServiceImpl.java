package com.google.gwt.sample.stockwatcher.server;

import com.google.gwt.sample.stockwatcher.client.api.DelistedException;
import com.google.gwt.sample.stockwatcher.client.api.StockPrice;
import com.google.gwt.sample.stockwatcher.client.api.StockPriceService;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class StockPriceServiceImpl extends RemoteServiceServlet implements
		StockPriceService {
	
	private static final long serialVersionUID = 4890928537350765189L;
	private StockPriceService sps;
	
	@Override
	public void init(javax.servlet.ServletConfig config) throws javax.servlet.ServletException {
		super.init(config);
		sps = (StockPriceService)config.getServletContext().
			getAttribute(StockPriceServiceFilter.SPS_ATTRIBUTE_NAME);
	}
	
	public StockPrice[] getPrices(String[] symbols) throws DelistedException {
		if (sps != null) {
			return sps.getPrices(symbols);
		}
		return null;
	}
}