package com.ben.consumer;

import com.google.gwt.sample.stockwatcher.client.api.DelistedException;
import com.google.gwt.sample.stockwatcher.client.api.StockPrice;
import com.google.gwt.sample.stockwatcher.client.api.StockPriceService;

public class Consumer implements Runnable {
	StockPriceService service;
	
	public Consumer(StockPriceService service) {
		this.service = service;
		new Thread(this).start();
	}
	
	public void run() {
		while (true) {
			try {
				Thread.sleep(5000);
				String[] priceNames = new String[]{"foo", "bar"};
				StockPrice[] prices = service.getPrices(priceNames);
				if (prices != null && (prices.length == priceNames.length)) {
					System.err.println("Successfully got prices: "+prices[0].getPrice()+", "+prices[1].getPrice());
				} else {
					System.err.println("Oh dear! Prices were null");
				}
			} catch (DelistedException e) {
				System.err.println("Stock is delisted");
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (RuntimeException e) {
				System.err.println("Got a RuntimeException "+e);
			}
		}
	}
}
