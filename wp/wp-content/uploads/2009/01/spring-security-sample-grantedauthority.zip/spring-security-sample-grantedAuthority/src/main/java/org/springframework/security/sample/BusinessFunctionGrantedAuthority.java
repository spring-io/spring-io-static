/**
 * 
 */
package org.springframework.security.sample;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.GrantedAuthority;
import org.springframework.security.GrantedAuthorityImpl;

/**
 * Simple extension to GrantedAuthorityImpl which only adds a List of
 * parent (owning) granted authorities.
 * 
 * @author oleg.zhurakousky@springsource.com
 */
public class BusinessFunctionGrantedAuthority extends GrantedAuthorityImpl {

	private List<GrantedAuthority> parentAuthorities = new ArrayList<GrantedAuthority>();
	/**
	 * 
	 * @param role
	 * @param businessFunctions
	 */
	public BusinessFunctionGrantedAuthority(String role) {
		super(role);
	}
	/**
	 * 
	 * @param authority
	 */
	protected void addParentAuthority(GrantedAuthority authority){
		parentAuthorities.add(authority);
	}
	/**
	 * 
	 * @return
	 */
	public List<GrantedAuthority> getParentAuthorities() {
		return parentAuthorities;
	}
	/**
	 * 
	 */
	public String toString(){
		return super.toString()  + parentAuthorities;
	}
}
