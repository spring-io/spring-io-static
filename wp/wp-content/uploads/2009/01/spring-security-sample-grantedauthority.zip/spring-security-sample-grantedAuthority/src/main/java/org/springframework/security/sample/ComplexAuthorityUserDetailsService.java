/**
 * 
 */
package org.springframework.security.sample;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.security.GrantedAuthority;
import org.springframework.security.annotation.Secured;
import org.springframework.security.userdetails.User;
import org.springframework.security.userdetails.UserDetails;
import org.springframework.security.userdetails.UserDetailsService;
import org.springframework.security.userdetails.UsernameNotFoundException;
import org.springframework.security.userdetails.memory.UserAttribute;
import org.springframework.security.userdetails.memory.UserAttributeEditor;
import org.springframework.util.StringUtils;

/**
 * Custom implementation of UserDetailsService. 
 * 
 * @author oleg.zhurakousky@springsource.com
 */
public class ComplexAuthorityUserDetailsService implements  UserDetailsService {
	private Properties businessFunctions;
	private Properties userProperties;

	/** 
	 * Will create an implementation of UserDetails object populating it with 
	 * custom GrantedAuthorities
	 */
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException, DataAccessException {
		
		/*
		 * Create UserAttribute object based on the properties specified in
		 * users'properties file.
		 */
		String userPropsValue = userProperties.getProperty(username);
		UserAttributeEditor configAttribEd = new UserAttributeEditor();
		configAttribEd.setAsText(userPropsValue);
		UserAttribute userAttributes = (UserAttribute) configAttribEd.getValue(); 
		
		/*
		 * Extract current list of GratedAuthorities (based on the roles specified in users.property file).
		 * For each GrantedAuthority extract the list of business functions, create additional GrantedAuthority and 
		 * add it to the overall list of GrantedAuthorities.
		 */
		GrantedAuthority[] temporaryAuthorities = userAttributes.getAuthorities();
		List<GrantedAuthority> newAuthorityList = new ArrayList<GrantedAuthority>();
		for (GrantedAuthority grantedAuthority : temporaryAuthorities) {
			String role = grantedAuthority.getAuthority();
			Set<String> aditionalAuthorities = StringUtils.commaDelimitedListToSet(businessFunctions.getProperty(role));
			/*
			 * Create GrantedAuthority for each business function and add it to the list of
			 * GrantedAuthorities representing roles
			 */
			for (String aditionalAuthority : aditionalAuthorities) {
				BusinessFunctionGrantedAuthority authority = new BusinessFunctionGrantedAuthority(aditionalAuthority);
				if (ArrayUtils.contains(userAttributes.getAuthorities(), authority)){
					int index = ArrayUtils.indexOf(userAttributes.getAuthorities(), authority);
					authority = (BusinessFunctionGrantedAuthority) userAttributes.getAuthorities()[index];
				} else {
					userAttributes.addAuthority(authority);
				}	
				/*
				 * Add parent (role) GrantedAuthority
				 */
				authority.addParentAuthority(grantedAuthority);			
			}
		}
		/*
		 * Create a final implementation of UserDetails object which will contain a 
		 * complete list of GrantedAuthorities
		 */
		UserDetails user = new User(username, 
									userAttributes.getPassword(), 
									userAttributes.isEnabled(), 
									true, 
									true, 
									true, 
									userAttributes.getAuthorities());

		return user;
	}
	/**
	 * 
	 * @return
	 */
	public Properties getBusinessFunctions() {
		return businessFunctions;
	}
	/**
	 * 
	 * @param businessFunctions
	 */
	public void setBusinessFunctions(Properties businessFunctions) {
		this.businessFunctions = businessFunctions;
	}
	/**
	 * 
	 * @return
	 */
	public Properties getUserProperties() {
		return userProperties;
	}
	/**
	 * 
	 * @param userProperties
	 */
	public void setUserProperties(Properties userProperties) {
		this.userProperties = userProperties;
	}
}
