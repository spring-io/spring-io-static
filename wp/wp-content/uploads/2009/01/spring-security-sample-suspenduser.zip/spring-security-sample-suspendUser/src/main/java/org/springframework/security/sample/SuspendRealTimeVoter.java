/**
 * 
 */
package org.springframework.security.sample;

import java.util.HashSet;
import java.util.Set;

import org.springframework.security.Authentication;
import org.springframework.security.ConfigAttribute;
import org.springframework.security.ConfigAttributeDefinition;
import org.springframework.security.vote.AccessDecisionVoter;

/**
 * @author oleg.zhurakousky@springsource.com
 *
 */
public class SuspendRealTimeVoter implements AccessDecisionVoter {
	
	private Set<String> revokedUsers = new HashSet<String>();

	/**
	 * 
	 */
	public boolean supports(ConfigAttribute attribute) {
		return true;
	}
	/**
	 * 
	 */
	public boolean supports(Class clazz) {
		return true;
	}
	/**
	 * 
	 * @param user
	 */
	public void suspend(String user){
		revokedUsers.add(user);
	}
	/**
	 * 
	 * @param user
	 * @return
	 */
	public boolean isSuspended(String user){
		return revokedUsers.contains(user);
	}
	
	public void grant(String user){
		revokedUsers.remove(user);
	}
	/**
	 * Will vote based on existence of a particular user 
	 * in the "revokedUsers" set;
	 */
	public int vote(Authentication authentication, Object object,
			ConfigAttributeDefinition config) {
		String userName = authentication.getName();
		return revokedUsers.contains(userName) ? ACCESS_DENIED : ACCESS_GRANTED;
	}
}
