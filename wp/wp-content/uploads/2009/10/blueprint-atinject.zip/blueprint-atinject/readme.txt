=======================================
== Blueprint / JSR 250/ JSR 330 Demo ==
=======================================

1. MOTIVATION

This demo displays a basic project combining Blueprint, JSR-250 and JSR-330 annotations
through Spring DM.
See http://blog.springsource.com/2009/10/08/drawing-spring�-the-blueprint/
for more information.

2. BUILD AND DEPLOYMENT

This directory contains the source files.
For building, Maven 2 and JDK 1.5+ are required.
To build the demo run

# mvn clean install

To deploy the project either install the bundles and Spring DM 2.0.x into an OSGi 4.2
platform or use the supplied Pax Runner setup (runner.bundles).