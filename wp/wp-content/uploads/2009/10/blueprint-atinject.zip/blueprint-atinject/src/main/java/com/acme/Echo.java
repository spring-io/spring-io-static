package com.acme;

public interface Echo {
	String echo(String m);
}
