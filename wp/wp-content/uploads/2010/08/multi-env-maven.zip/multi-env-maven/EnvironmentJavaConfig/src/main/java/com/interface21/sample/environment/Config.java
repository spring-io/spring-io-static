package com.interface21.sample.environment;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
 

import com.interface21.sample.environment.dao.DefaultSampleDao;
import com.interface21.sample.environment.dao.SampleDao;
import com.interface21.sample.environment.dao.StaticSampleDao;
import com.interface21.sample.environment.service.DefaultSampleService;
import com.interface21.sample.environment.service.SampleService;
import com.interface21.sample.environment.util.Environment;
import com.interface21.sample.environment.util.EnvironmentUtils;

@Configuration
public class Config {
	
	@Bean
	public SampleService sampleService() {
		DefaultSampleService service = new DefaultSampleService();
		service.setDao(sampleDao());
		return service;
	}
	
	@Bean
	public SampleDao sampleDao() {
		Environment env = EnvironmentUtils.getEnvironment();
		if (env == Environment.D) {
			return new StaticSampleDao();
		}
		DefaultSampleDao dao = new DefaultSampleDao();
		Properties props = new Properties();
		props.setProperty("Joris", "Kuipers");
		props.setProperty("Alef", "Arendsen");
		if (env == Environment.A) {
			props.setProperty("Arjen", "Poutsma");
		}
		dao.setNames(props);
		return dao;
	}
	
}
