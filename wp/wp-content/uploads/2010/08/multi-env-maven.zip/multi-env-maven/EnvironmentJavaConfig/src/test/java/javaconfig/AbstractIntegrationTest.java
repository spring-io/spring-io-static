package javaconfig;
import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

import com.interface21.sample.environment.service.SampleService;


public abstract class AbstractIntegrationTest extends AbstractDependencyInjectionSpringContextTests {
	
	protected SampleService service;
	
	public void setSampleService(SampleService service) {
		this.service = service;
	}
	
	@Override
	protected String[] getConfigLocations() {
		System.setProperty("app.env", getEnvLetter());
		return new String[] { "java-config.xml" };
	}
	
	@Override
	protected void onTearDown() throws Exception {
		// make sure we create a new ApplicationContext for the next test
		setDirty();
	}
	
	protected abstract String getEnvLetter();
}
