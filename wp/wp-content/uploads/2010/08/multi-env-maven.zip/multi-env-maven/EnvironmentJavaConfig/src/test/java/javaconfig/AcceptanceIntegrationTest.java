package javaconfig;

public class AcceptanceIntegrationTest extends AbstractIntegrationTest {

	@Override
	protected String getEnvLetter() {
		return "A";
	}
	
	public void testExtraPeopleInAcceptance() {
		assertEquals("Poutsma", service.getLastName("Arjen"));
	}

}
