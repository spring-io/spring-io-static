package com.interface21.sample.environment;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.interface21.sample.environment.dao.DefaultSampleDao;
import com.interface21.sample.environment.dao.SampleDao;

@Configuration
public class A_Config extends BaseConfig {
	
	@Override
	@Bean
	public SampleDao sampleDao() {
		DefaultSampleDao dao = (DefaultSampleDao) super.sampleDao();
		dao.getNames().put("Arjen", "Poutsma");
		return dao;
	}
}
