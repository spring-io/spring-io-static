package com.interface21.sample.environment;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.interface21.sample.environment.dao.DefaultSampleDao;
import com.interface21.sample.environment.dao.SampleDao;
import com.interface21.sample.environment.service.DefaultSampleService;
import com.interface21.sample.environment.service.SampleService;

@Configuration
public class BaseConfig {
	
	@Bean
	public SampleService sampleService() {
		DefaultSampleService service = new DefaultSampleService();
		service.setDao(sampleDao());
		return service;
	}
	
	@Bean
	public SampleDao sampleDao() {
		DefaultSampleDao dao = new DefaultSampleDao();
		Properties props = new Properties();
		props.setProperty("Joris", "Kuipers");
		props.setProperty("Alef", "Arendsen");
		dao.setNames(props);
		return dao;
	}
	
}
