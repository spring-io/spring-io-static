package com.interface21.sample.environment;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.interface21.sample.environment.dao.SampleDao;
import com.interface21.sample.environment.dao.StaticSampleDao;

@Configuration
public class D_Config extends BaseConfig {
	
	@Override
	@Bean
	public SampleDao sampleDao() {
		return new StaticSampleDao();
	}
}
