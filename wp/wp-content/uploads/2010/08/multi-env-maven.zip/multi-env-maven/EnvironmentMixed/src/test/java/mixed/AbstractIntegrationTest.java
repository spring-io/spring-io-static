package mixed;
import org.springframework.test.AbstractDependencyInjectionSpringContextTests;

import com.interface21.sample.environment.service.SampleService;
import com.interface21.sample.environment.util.Environment;
import com.interface21.sample.environment.util.EnvironmentUtils;


public abstract class AbstractIntegrationTest extends AbstractDependencyInjectionSpringContextTests {
	
	protected SampleService service;
	
	public void setSampleService(SampleService service) {
		this.service = service;
	}
	
	@Override
	protected String[] getConfigLocations() {
		System.setProperty("app.env", getEnvLetter());
		Environment env = EnvironmentUtils.getEnvironment();
		return new String[] { 
			"base/java-config.xml", 
			"env/" + env + "/java-config.xml" 
		};
	}
	
	protected abstract String getEnvLetter();
}
