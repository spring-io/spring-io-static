package mixed;

public class DevelopmentIntegrationTest extends AbstractIntegrationTest {

	@Override
	protected String getEnvLetter() {
		return "D";
	}
	
	public void testStaticDaoConfigured() {
		assertEquals("Doe", service.getLastName("ignored"));
	}

}
