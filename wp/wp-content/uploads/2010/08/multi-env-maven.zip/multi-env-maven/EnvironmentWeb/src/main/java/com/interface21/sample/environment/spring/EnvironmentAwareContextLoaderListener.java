package com.interface21.sample.environment.spring;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.ContextLoaderListener;

public class EnvironmentAwareContextLoaderListener extends ContextLoaderListener {

	@Override
	protected ContextLoader createContextLoader() {
		return new EnvironmentAwareContextLoader();
	}

}
