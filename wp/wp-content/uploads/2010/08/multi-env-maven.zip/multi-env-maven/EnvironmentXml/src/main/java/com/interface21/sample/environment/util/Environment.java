package com.interface21.sample.environment.util;

public enum Environment {
	D("DEVELOPMENT"),
	T("TESTING"),
	A("ACCEPTANCE"),
	P("PRODUCTION");
	
	private final String description;
	
	Environment(String description) {
		this.description = description;
	}
	
	public String getDescription() {
		return description;
	}
}
