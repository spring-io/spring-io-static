package xml;

public class ProductionIntegrationTest extends AbstractIntegrationTest {

	@Override
	protected String getEnvLetter() {
		return "P";
	}
	
	public void testRegularDaoInProduction() {
		assertEquals("Kuipers", service.getLastName("Joris"));
		assertEquals("Arendsen", service.getLastName("Alef"));
		assertNull(service.getLastName("Arjen"));
	}

}
